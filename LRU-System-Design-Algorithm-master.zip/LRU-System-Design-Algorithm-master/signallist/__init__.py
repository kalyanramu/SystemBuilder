"""
The Signal List Package includes tools for generating and reading signalList.csv files for the LRU System Design Tool.
"""

import csv
import os
import sqlite3


class SignalList:
    def __init__(self, db_filepath: str=None) -> None:
        """
        Creates a new signal list document object.
        :param db_filepath: the database file to use for available signal types. If none is provided, the
        default is loaded.
        """
        self.signal_types = []
        if db_filepath:
            self._load_signal_types(db_filepath)
        else:
            self._load_signal_types(os.path.join(os.path.dirname(__file__), '..\LRUTesterComponents.db'))
        self.signals = {}

    def _load_signal_types(self, db_filepath: str) -> None:
        """
        loads the signal_types file and assigns it to self.signal_types
        :param db_filepath: the database file to load the signal types from
        :return: None
        """
        conn = sqlite3.connect(db_filepath)
        for s in conn.execute("SELECT Name FROM eSignalTypes").fetchall():
            self.signal_types.append((s[0]))
        conn.close()

    def add(self, base_name: str, signal_type: str, connector: str, faulting: bool,
            real_connector: str= "", base_name_separator: str = "", start_index: int = 0, qty: int=1) -> None:
        """
        Adds multiple copies of the same signal.
        :param qty: The number of signals to add
        :param base_name: the base signal name to use
        :param signal_type: The signal type for this signal. This MUST exist in the signal_types file that this class
        was initialized with
        :param connector: The connector to assign this signal to.
        :param faulting: Boolean value for whether this signal should be faultable
        :param real_connector: Optional parameter for the RealConnector value
        :param base_name_separator: The string value to use when formatting the base string.
        :param start_index: The index to start numbering the base string names
        :return: None
        """
        indices = list(range(start_index, start_index+qty))
        for index in indices:
            name = base_name_separator.join([base_name, str(index)])
            try:
                self.signal_types.index(signal_type)
                bool(faulting)
            except ValueError as e:
                raise e
            if name not in self.signals:
                self.signals[name] = {'signal_type': signal_type, 'connector': connector,
                                      'real_connector': real_connector, 'faulting': bool(faulting)}
            else:
                raise KeyError(
                    "A signal with the name '{}' already exists and signal names must be unique.".format(name))

    def remove_attr_value(self, attribute_id: str, value: str) -> [str]:
        """
        Remove all signals where a given attribute equals a given value
        :param attribute_id: the attribute to filter by. Valid values are 'signal_type', 'connector', 'real_connector',
        and 'faulting'.
        :param value: the attribute value to match.
        :return: a list of removed signals
        """
        signal_list = self.filter(attribute_id, value)
        for s in signal_list:
            self.remove(s)
        return signal_list

    def remove(self, name: str) -> None:
        """
        Removes a signal from the SignalListDocument
        :param name: the name of the signal to remove
        :return: None
        """
        del self.signals[name]

    def save(self, filepath: str) -> None:
        """
        Writes the SignalList to a file
        :param filepath:
        :return:
        """
        with open(filepath, 'w') as f:
            csvwriter = csv.writer(f, delimiter=',', lineterminator='\n')
            csvwriter.writerow(["SignalName", "SignalType", "Connector", "RealConnector", "Faulting"])
            for s in self.signals:
                row = [s, self[s]['signal_type'], self[s]['connector'], self[s]['real_connector'], self[s]['faulting']]
                csvwriter.writerow(row)

    def filter(self, attribute_id: str, value: str):
        """
        Returns a list of signal names with the given attribute value
        :param attribute_id: the attribute to filter by. Valid values are 'signal_type', 'connector', 'real_connector',
        and 'faulting'.
        :param value: the attribute value to match
        :return: a list of matching signals
        """
        signal_list = []
        for s in self.signals:
            if self.signals[s][attribute_id] == value:
                signal_list.append(s)
        return signal_list

    @staticmethod
    def load(filepath: str):
        """
        Creates a new SignalList object from a saved signal list
        :param filepath: the signal list to load
        :return: SignalList
        """
        with open(filepath, 'r') as f:
            csvreader = csv.reader(f, delimiter=',')
            next(csvreader, None)
            sldoc = SignalList()
            for row in csvreader:
                sldoc.add(row[0], row[1], row[2], row[3], row[4])
        return sldoc

    def __getitem__(self, item: str) -> {}:
        """
        Operator override for []. Given an item name, this will return information about a signal.
        :param item: the signal name
        :return: Dictionary of signal properties
        """
        return self.signals[item]
