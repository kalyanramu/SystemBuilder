'''
Created on Jul 26, 2017

@author: bsnover

Generic PXI functionality that isn't specific to a signal type.
'''
import racks, cables, logging, LRUconstants
logger = logging.getLogger(__name__)

def insert_pxi_chassis_into_rack(conn, rackID, eChassisTypeID = None): 
    '''Adds a new pxi chassis to a rack'''
    '''Default chassis type is the 1085'''
    instrumentChassiseID = conn.execute("SELECT ID FROM ePXIChassisTypes WHERE Model == ?", (LRUconstants.PXI_INSTRUMENT_CHASSIS_EID,)).fetchone()[0]    
    if eChassisTypeID is None:
        eChassisTypeID = conn.execute("SELECT ID From ePXIChassisTypes WHERE Model == ?", ("PXIe-1085",)).fetchone()[0]
    
    '''Ensure there is room in rack'''
    pxiRackUnits = conn.execute('''SELECT RackUnits FROM eRackUnits WHERE ItemType == ?''', ('PXI Chassis',)).fetchone()[0]
    if (racks.upgrade_rack_if_needed(conn, rackID, pxiRackUnits, racks.RackSpaceType.INTERNAL) > -1):
    
        newChassisID = conn.execute("INSERT INTO PXIChassis (ePXIChassisTypeID, RackID) VALUES (?, ?)", (eChassisTypeID, rackID)).lastrowid
        logger.info('Added new PXIChassis %s', newChassisID)
        '''Don't add any extra HW to the instrument chassis'''
        if eChassisTypeID is not instrumentChassiseID: 
            numNonInstrumentChassis = conn.execute("SELECT count(*) FROM PXIChassis WHERE ePXIChassisTypeID IS NOT ?", (instrumentChassiseID,)).fetchone()[0]
            '''The first chassis gets a MXI card if set to windows only. Otherwise it gets a controller based on performance'''
            if numNonInstrumentChassis == 1:
                if LRUconstants.COMPUTE_REQUIREMENTS == LRUconstants.ComputeRequirements.Windows_Only:
                    '''TODO lookup the MXI ID instead of hard-coding'''
                    add_PXI_insert(conn, 7, rackID, newChassisID)             
                elif LRUconstants.ALL_CHANNELS_ONE_CONTROLLER:
                    '''Add an extra MXI now assuming there are multiple PXI. Can remove it during disassembly'''
                    add_PXI_insert(conn, 4, rackID, newChassisID)                 
                if LRUconstants.COMPUTE_REQUIREMENTS == LRUconstants.ComputeRequirements.RT_Med_Performance:
                    '''TODO don't hardcode'''
                    add_PXI_insert(conn, 3, rackID, newChassisID) 
                elif LRUconstants.COMPUTE_REQUIREMENTS == LRUconstants.ComputeRequirements.RT_High_Performance:
                    '''TODO don't hardcode'''
                    add_PXI_insert(conn, 6, rackID, newChassisID) 
                else:
                    return -1
            if numNonInstrumentChassis > 1:
                if LRUconstants.ALL_CHANNELS_ONE_CONTROLLER:
                    '''If all channels to one controller, add a MXI card to the new chassis AND the first chassis'''
                    add_PXI_insert(conn, 7, rackID, newChassisID) 
                else:
                    if LRUconstants.COMPUTE_REQUIREMENTS == LRUconstants.ComputeRequirements.RT_Med_Performance:
                        '''TODO don't hardcode'''
                        add_PXI_insert(conn, 3, rackID, newChassisID)
                    elif LRUconstants.COMPUTE_REQUIREMENTS == LRUconstants.ComputeRequirements.RT_High_Performance:
                        '''TODO don't hardcode'''
                        add_PXI_insert(conn, 6, rackID, newChassisID)           
        conn.commit()
        
        return newChassisID
    else:
        logger.error("Failed to insert PXI Chassis into rack.")
        return -1

def delete_chassis(conn, chassisID):
    if (conn.execute("SELECT ID FROM PXIChassisInserts WHERE PXIChassisID == ?", (chassisID,)).fetchall()):
        logger.error("Chassis must be empty to be deleted.")
        return -1
    conn.execute("DELETE FROM PXIChassis WHERE ID == ?", (chassisID,))
    conn.commit()
    return 0
    
def add_PXI_insert (conn, ePXITypeID, rackID, selectedChassisID = None, slotNumber = None):
    '''Find a PXI chassis in the rack with a slot available''' 
    if selectedChassisID is None:
        '''Exclude the instrument chassis from the search'''
        instrumentChassiseID = conn.execute("SELECT ID FROM ePXIChassisTypes WHERE Model == ?", (LRUconstants.PXI_INSTRUMENT_CHASSIS_EID,)).fetchone()[0]
        chassisIDs = conn.execute("SELECT ID, ePXIChassisTypeID FROM PXIChassis WHERE RackID == ? AND ePXIChassisTypeID IS NOT ?", (rackID,instrumentChassiseID)).fetchall()
        selectedChassisID = -1
        for chassisID in chassisIDs:
            totalSlots = conn.execute("SELECT NumSlots FROM ePXIChassisTypes WHERE ID == ?", (chassisID[1],)).fetchone()[0]
            usedSlots = conn.execute("SELECT count(*) FROM PXIChassisInserts WHERE PXIChassisID == ?", (chassisID[1],)).fetchone()[0]
            if (totalSlots - usedSlots):
                selectedChassisID = chassisID[0]
                break      
    if selectedChassisID < 0:
        '''No chassis was found so we need to add a new one'''
        selectedChassisID = insert_pxi_chassis_into_rack(conn, rackID)
    
    if selectedChassisID < 0:
        '''If error was returned, return error'''
        return -1
    '''Add the module to the PXIInsert List'''
    PXIInsertID = conn.execute('''INSERT INTO PXIChassisInserts (ePXIInsertTypeID) VALUES (?)''', (ePXITypeID,)).lastrowid
    conn.commit()
    if (move_PXI_insert(conn, PXIInsertID, selectedChassisID, slotNumber) > -1):
        '''Get a list of connectors associated with the module'''
        ePXIConnectorIDs = conn.execute("SELECT ePXIConnectorID FROM ePXIConnectorInformation WHERE ePXIInsertTypeID == ?", (ePXITypeID,)).fetchall()
        '''Add a connector to the connector list for each connector on that module'''
        for connector in ePXIConnectorIDs:
            conn.execute('''INSERT INTO PXIConnectors (eConnectorID, PXICardID) VALUES (?,?)''', (connector[0], PXIInsertID)) 
    
        logger.info('Added new PXI element of type %s into chassis %s slot %s', ePXITypeID, selectedChassisID, slotNumber)    
        conn.commit()
        return PXIInsertID
    else:
        conn.execute("DELETE FROM PXIChassisInserts WHERE ID == ?", (PXIInsertID,))
        conn.commit()
        return -1

def delete_PXI_insert(conn, PXIInsertID):
    '''Get a list of connectors associated with that ID'''
    connectors = conn.execute("SELECT ID FROM PXIConnectors WHERE PXICardID == ?", (PXIInsertID,)).fetchall()
    '''Disconnect all cables associated with those connectors'''
    for connector in connectors:
        cableJunctionIDs = conn.execute("SELECT ID FROM PXICableConJunct WHERE PXIConID == ?", (connector[0],)).fetchall()
        for junctID in cableJunctionIDs:
            conn.execute("DELETE FROM PXICableConJunct WHERE ID == ?", (junctID[0],))
        '''Remove that connector'''
        conn.execute("DELETE FROM PXIConnectors WHERE ID == ?", (connector[0],))
    '''Remove the card'''
    conn.execute("DELETE FROM PXIChassisInserts WHERE ID == ?", (PXIInsertID,))
    conn.commit()

def move_PXI_insert(conn, cardID, chassisID, slotNumber=None):
    ePXITypeID = conn.execute("SELECT ePXIInsertTypeID FROM PXIChassisInserts WHERE ID == ?", (cardID,)).fetchone()[0]
    
    '''Calculate the slot number to add it'''
    insertCategory = conn.execute("SELECT Category FROM ePXIInsertTypes WHERE ID == ?", (ePXITypeID,)).fetchone()[0]
    if insertCategory == 'Controller':
        if (slotNumber is not None and slotNumber is not 1):
            logger.error("Controllers must be placed in slot 1")
            return -1
        slotNumber = 1
    else:
        if slotNumber is 1:
            logger.error("Only a controller can go in the first slot")
            return -1
    if slotNumber is None:
        slots = conn.execute("SELECT SlotNumber FROM PXIChassisInserts WHERE PXIChassisID == ? ORDER BY SlotNumber", (chassisID,)).fetchall()
        slotNumber = 2
        for slot in slots:
            if slot[0] is not None and slot[0] is not 1:
                '''Break on first available slot in chassis'''
                if slot[0] is not slotNumber:
                    break
                slotNumber += 1
    '''Make sure nothing is in that slot already'''
    if (conn.execute("SELECT ID FROM PXIChassisInserts WHERE PXIChassisID == ? AND SlotNumber == ?", (chassisID, slotNumber)).fetchone()):
        logger.error("Already a card in chassis %s and slot %s", chassisID, slotNumber)
        return -1        
    '''Add the module to the right location'''
    conn.execute('''UPDATE PXIChassisInserts SET PXIChassisID = ?, SlotNumber = ? WHERE ID == ?''', (chassisID, slotNumber, cardID)).lastrowid
    conn.commit()
    return 0
    
def check_for_open_PXI_connector(conn, cardTypeID, rackID, crossRacks):
    '''Checks for a card with a connector of that type without a cable connected. If found, returns that card's ID. If not, returns -1, crossRacks broadens the search'''
    '''TODO consider changing this to use a list of connectorTypeIDs instead of a cardTypeID'''
    '''First search for a connector within the rack'''
    connInfo = conn.execute("SELECT ID, PXICardID FROM UnassignedPXIConnectors WHERE ePXIInsertTypeID == ? AND RackID == ?", (cardTypeID,rackID)).fetchone()
    if connInfo:
        logger.debug("Found open connector")
        return connInfo[0]
    if crossRacks:
        '''Try again without filtering by rackID'''
        connInfo = conn.execute("SELECT ID, PXICardID FROM UnassignedPXIConnectors WHERE ePXIInsertTypeID == ?", (cardTypeID,)).fetchone()
    if connInfo:
        print("CrossRacks Found!")
        logger.debug("Found open connector in a different rack")
        return connInfo[0]  
    else:
        return None

def check_for_open_cable_connectors(conn, cardTypeID, rackID, crossRacks, eCableTypeID = None):
    '''Check each PXI connector of the specified card type for an attached cable. If cable is attached, return connectors on the other end that are available'''
    if eCableTypeID:
        '''Filter connectors to make sure they are of the right cable type'''
        potentialPXISideCableConIDs = conn.execute("SELECT CableConID FROM PXIConnectorInformation WHERE ePXIInsertTypeID == ? AND RackID == ? AND CableID IS NOT ?", (cardTypeID, rackID, None)).fetchall()
        PXISideCableConIDs = []
        for cableConID in potentialPXISideCableConIDs:
            if conn.execute("SELECT eCableTypeID FROM CableConnectorInformation WHERE ID == ?", (cableConID[0],)).fetchone()[0] == eCableTypeID:
                PXISideCableConIDs.append(cableConID[0])
    else:
        PXISideCableConIDs = conn.execute("SELECT CableConID FROM PXIConnectorInformation WHERE ePXIInsertTypeID == ? AND RackID == ? AND CableID IS NOT ?", (cardTypeID, rackID, None)).fetchall()        
        PXISideCableConIDs = [x[0] for x in PXISideCableConIDs]
    cableConIDs = []
    for PXISideCableConID in PXISideCableConIDs:
        cableConIDs = cableConIDs + cables.get_disconnected_opposite_side_connectors(conn, PXISideCableConID)
    return cableConIDs

def get_all_open_PXI_connectors(conn):
    return conn.execute("SELECT ID, PXICardID, ConnectorLabel FROM UnassignedPXIConnectors").fetchall()

def cleanup_extras(conn):
    '''Remove MXI expansion card if only one PXI chassis other than the Instrument chassis'''
    numPXIChassis = conn.execute("SELECT ID FROM PXIChassis").fetchall()
    if len(numPXIChassis) == 2:
        conn.execute("DELETE FROM PXIChassisInserts WHERE ePXIInsertTypeID == ?", (4,))
        conn.commit() 

def get_card_replacement_options(conn, cardID):
    '''Returns an array of ePXIInsertTypeIDs that can safely act as a replacement for the card specified by cardID'''
    eCardTypeID = conn.execute("SELECT ePXIInsertTypeID FROM PXIChassisInserts WHERE ID == ?", (cardID,)).fetchone()[0]
    allConnectors = conn.execute("SELECT ePXIConnectorID FROM ePXIConnectorInformation WHERE ePXIInsertTypeID == ?", (eCardTypeID,)).fetchall()
    allConnectors = [x[0] for x in allConnectors]    
    unassignedCons = conn.execute("SELECT eConnectorID FROM UnassignedPXIConnectors WHERE PXICardID == ? AND ePXIInsertTypeID == ?", (cardID, eCardTypeID)).fetchall()
    unassignedCons = [x[0] for x in unassignedCons]
    assignedCons = []
    for connector in allConnectors:
        if connector not in unassignedCons:
            assignedCons.append(connector)
    if allConnectors == []:
        return None
    elif assignedCons == []:
        compatibleInsertTypeIDs = conn.execute("SELECT DISTINCT ePXIInsertTypeID FROM ePXIConnectorInformation WHERE ePXIConnectorID == ? AND ePXIInsertTypeID IS NOT ?", (allConnectors[0], eCardTypeID)).fetchall()
        compatibleInsertTypeIDs = [x[0] for x in compatibleInsertTypeIDs]
    else:
        compatibleInsertTypeIDs = []
        '''Next see if there is anything else in ePXIConnectorInformation with the same connectors minus those unattached'''
        altCardTypeIDs = conn.execute("SELECT DISTINCT ePXIInsertTypeID FROM ePXIConnectorInformation WHERE ePXIInsertTypeID IS NOT ? AND ePXIConnectorID IN (%s)" % ','.join('?'*len(assignedCons)), ([eCardTypeID]+assignedCons)).fetchall()
        '''Remove cards that don't have a connector for each type that is connected'''
        for altCardTypeID in altCardTypeIDs:
            altConnectors = conn.execute("SELECT ePXIConnectorID FROM ePXIConnectorInformation WHERE ePXIInsertTypeID == ?", (altCardTypeID[0],)).fetchall()
            altConnectors = [x[0] for x in altConnectors]
            match = True
            for assignedCon in assignedCons:
                if assignedCon not in altConnectors:
                    match = False
                    break
            if match:
                compatibleInsertTypeIDs.append(altCardTypeID[0])
    return compatibleInsertTypeIDs

def get_downsizeable_chassis(conn, PXIChassisID):
    '''Check how many open PXI slots are available and see if a chassis can be downsized'''
    ePXIChassisTypeID = conn.execute("SELECT ePXIChassisTypeID FROM PXIChassis WHERE ID == ?", (PXIChassisID,)).fetchone()[0]
    numSlots = conn.execute("SELECT NumSlots FROM ePXIChassisTypes WHERE ID ==?", (ePXIChassisTypeID,)).fetchone()[0]
    slotsUsed = conn.execute("SELECT COUNT(*) FROM PXIChassisInserts WHERE PXIChassisID == ?", (PXIChassisID,)).fetchone()[0]
    downsizeOptions = conn.execute("SELECT ID, Model FROM ePXIChassisTypes WHERE NumSlots <= ? AND NumSlots >= ? AND ID IS NOT ?", (numSlots, slotsUsed, ePXIChassisTypeID)).fetchall()

    return downsizeOptions

def replace_PXI_insert_type (conn, PXIInsertID, replacementePXITypeID):
    replacementeConnectorTypeIDs = conn.execute("SELECT ePXIConnectorID FROM ePXIConnectorInformation WHERE ePXIInsertTypeID == ?", (replacementePXITypeID,)).fetchall()
    replacementeConnectorTypeIDs = [x[0] for x in replacementeConnectorTypeIDs]
    originalConnectors = conn.execute("SELECT ID, eConnectorID FROM PXIConnectors WHERE PXICardID == ?", (PXIInsertID,)).fetchall()
    '''remove extra connectors'''
    for ogConnector in originalConnectors:
        if ogConnector[1] not in replacementeConnectorTypeIDs:
            conn.execute("DELETE FROM PXIConnectors WHERE ID == ?", (ogConnector[0],))
    '''change the card type'''
    conn.execute("UPDATE PXIChassisInserts SET ePXIInsertTypeID = ? WHERE ID == ?", (replacementePXITypeID, PXIInsertID))
    conn.commit()