'''
Created on Jul 28, 2017

@author: bsnover
'''
from enum import IntEnum

CUSTOMER_PROVIDED_SOFTWARE = False
PINS_PER_BANK = 8

class ComputeRequirements(IntEnum):
    RT_High_Performance = 1
    RT_Med_Performance = 2
    Windows_Only = 3

ALL_CHANNELS_ONE_CONTROLLER = True
COMPUTE_REQUIREMENTS = ComputeRequirements.RT_High_Performance

RACK_INTERNAL_HEADROOM = 0

ROUTING_CARD_NAME = "Low Power Signal Routing"
INSTRUMENT_DAUGHTER_CARD_NAME = "Routing Instrument"
SIGNAL_PANEL_NAME = "ThroughPoint Interface Panel"
BULKHEAD_PANEL_NAME = "Bulkhead"

AI_10V_NAME = "Input Voltage +/-10V"
AO_10V_NAME = "Output Voltage +/-10V"
AO_30V_NAME = "Output Voltage +/- 30V"
AO_60V_NAME = "Output Voltage +/- 60V"
A0_20mA_NAME = "Output Current +/- 20mA"
A0_XmA_NAME = "Output Current +/- XmA (Precision Resistor)"
FOUR_WIRE_IVDT_NAME = "Input 4-wire xVDT (400Hz, 10Vrms)"
SIX_WIRE_IVDT_NAME = "Input 5/6-wire xVDT (3KHz,7Vrms)"
SIX_WIRE_OVDT_NAME = "Output 5/6-wire xVDT (3KHz,7Vrms)"
DI_28V_NAME = "Input Discrete 28V/Open"
DI_GND_OPEN_NAME = "Input Discrete GND/Open"
DI_TTL_NAME = "Input Discrete TTL"
DO_GND_OPEN_NAME = "Output Discrete GND/Open"
DO_28V_OPEN_NAME = "Output Discrete 28V/Open"
ARINC_429_TX_NAME = "ARINC 429 TX"
ARINC_429_RX_NAME = "ARINC 429 RX"
SPI_NAME = "SPI"
DIO_DAQ_NAME = "DAQ DIO"
RS422_NAME = "RS-422"
RS485_NAME = "RS-485"
PWM_INPUT_32V_FPGA = "Input FPGA PWM (32V, 50mA)"
PWM_INPUT_32V = "Input PWM (32V, 50mA)"
AI_16V_NAME = "Input Voltage +/-16V"
AI_32V_NAME = "Input Voltage +/-32V"
AI_20mA_NAME = "Input Current  +/- 20mA"
AI_40mA_NAME = "Input Current  +/- 40mA"
MIL_STD_1553_NAME = "MIL-STD 1553"
INPUT_RTD_NAME = "Input 2/3/4-wire RTD"
ONE_WATT_RES_NAME = "Input Variable Resistor 1W"
AI_THERMOCOUPLE_NAME = "Input Thermocouple"
AO_THERMOCOUPLE_NAME = "Output Thermocouple"
INPUT_SYNCHRO_NAME = "Input Synchro (400Hz,10Vrms) Position"
INPUT_SMALL_LOAD_NAME = "Input Fixed Small Load ( < 5W, < 2A and 1in )"
INPUT_LARGE_LOAD_NAME = "Input Fixed Large Load ( > 2A and > 5W or > 1in)"
DI_OPEN_CLOSED_NAME = "Input Discrete Open/Closed"
CUSTOM_BASE_NAME = "Other/Custom"
CUSTOM_2WIRE_INPUT_NAME = "Other/Custom Input 2-wire"
CUSTOM_2WIRE_OUTPUT_NAME = "Other/Custom Output 2-wire"
CUSTOM_4WIRE_INPUT_NAME = "Other/Custom Input 4-wire"
CUSTOM_4WIRE_OUTPUT_NAME = "Other/Custom Output 4-wire"
CUSTOM_8WIRE_INPUT_NAME = "Other/Custom Input 6/8 wire"
CUSTOM_8WIRE_OUTPUT_NAME = "Other/Custom Output 6/8 wire"
POWER_28V_NAME = "28V Power"

INTEGRATOR_MANUFACTURER_NAME = "Integrator"

HD44_HD44_CABLE_NAME = "HD44<->HD44"
HD44_DB9_CABLE_NAME = "HD44<->D9-D9-D9-D9"
HD44_NANOFIT_CABLE_NAME = "HD44<->4NanoFit"
AO_VHDCI_NANOFIT_CABLE_NAME = "AOVHDCI<->8NanoFit"
AI_VHDCI_NANOFIT_CABLE_NAME = "AIVHDCI<->8NanoFit"
HUNDREDPIN_12NANOFIT_CABLE_NAME = "100Pin<->12NanoFit"
AI_THERMOCOUPLE_CABLE_NAME = "Thermocouple<->4NanoFit"
AI30V_CABLE_NAME = "AI30V<->2NanoFit"
AO20mA_CABLE_NAME = "AI20mA<->2NanoFit"

HD44_RTI_MODEL = "RTI-12305"
FOURBANK_RTI_MODEL = "RTI-12303"

PXI_INSTRUMENT_CHASSIS_EID = "PXIe-1078"

