'''
Created on Jul 26, 2017

@author: bsnover

This module handles all functionality related to panels.
'''
import math, racks
from operator import itemgetter
import logging
logger = logging.getLogger(__name__)

def insert_panel_into_rack(conn, rackID, ePanelTypeID, referencePanelID = None): 
    '''Adds a new panel to a rack'''
    #banksOnPanel = conn.execute("SELECT SUM(SupportedBanks) FROM ePanelConnectorList WHERE ePanelTypeID == ?", (panelTypeID,)).fetchone()[0]            
    '''Ensure there is room in rack'''
    panelRackUnits = conn.execute('''SELECT RackUnits FROM ePanelTypes WHERE ID == ?''', (ePanelTypeID,)).fetchone()[0]
    if (racks.upgrade_rack_if_needed(conn, rackID, panelRackUnits, racks.RackSpaceType.FRONT) > -1):
    
        insertPanelID = conn.execute("INSERT INTO Panels (ePanelTypeID, RackID, ReferencePanelID) VALUES (?,?,?)", (ePanelTypeID, rackID, referencePanelID)).lastrowid
        logger.info('Added new panel %s', insertPanelID)
        conn.commit()
        
        '''Add connectors to the connector list in ascending order'''
        ePanelConnectors = conn.execute("SELECT ID FROM ePanelConnectorList WHERE ePanelTypeID == ?", (ePanelTypeID,)).fetchall()
        ePanelConnectors = sorted(ePanelConnectors, key=itemgetter(0), reverse = False)  
        for ePanelConnector in ePanelConnectors:
            conn.execute("INSERT INTO PanelConnectors (ePanelConnectorID, PanelID) VALUES (?,?)", (ePanelConnector[0],insertPanelID))
        conn.commit()
        return insertPanelID
    else:
        logger.error("Failed to insert panel into rack.")
        return -1

def get_DUTCon_panel_assignment_order(conn):
    '''Determine optimal DUTconnector assignment order. For each signal type in the signal list for each DUTconnector, count how many banks are needed'''
    totalBanksNeeded = 0
    DUTCons = {}
    DUTConnectors = conn.execute("SELECT DISTINCT DUTConnector FROM Signals")
    for DUTConnector in DUTConnectors:
        '''For Signal Types not assinged to Bulkhead'''
        signalTypes = conn.execute("SELECT DISTINCT SignalType FROM SignalsInformation WHERE Bulkhead == ?", (False,)).fetchall() #Rerun the query to reset the cursor object to the top
        for signalType in signalTypes:        
            '''Count the number of signals of a specific type'''
            totalSignalsOfTypeOnCon = conn.execute("SELECT count(*) FROM Signals WHERE SignalType == ? AND DUTConnector == ?", (signalType[0],DUTConnector[0])).fetchone()[0]
            
            '''Find how many of those signals fit into a Bank'''
            signalsPerBank = conn.execute("SELECT SignalsPerBank FROM eSignalTypes WHERE Name == ?", (signalType[0],)).fetchone()[0]
            
            '''Calculate the number of banks needed for that signal type'''
            banksNeeded = int(math.ceil((totalSignalsOfTypeOnCon/signalsPerBank)))
            logger.debug('DUTConn:%s SignalType:%s SignalTotal:%s SignalsPerBank:%s BanksNeeded:%s', DUTConnector[0], signalType[0], totalSignalsOfTypeOnCon, signalsPerBank, banksNeeded)
            
            if (banksNeeded):
                if DUTConnector[0] in DUTCons:
                    DUTCons[DUTConnector[0]] += banksNeeded
                else:
                    DUTCons[DUTConnector[0]] = banksNeeded
            totalBanksNeeded = totalBanksNeeded + banksNeeded
    
    sortedDUTCons = sorted(DUTCons.items(), key=itemgetter(1), reverse = True)  

    logger.info('Total Banks Needed:%s', totalBanksNeeded)
    return sortedDUTCons

def get_unassigned_panel_banks (conn, rackID):
    '''Returns a list of available banks on each panel within a rack. Signal direction is either input (0) or output (1)'''
    unassignedConnectorIDs = conn.execute("SELECT PanelID, ePanelConnectorID FROM UnassignedPanelConnectors WHERE RackID == ?", (rackID,)).fetchall()
    logger.debug('Unassigned connector IDs %s', unassignedConnectorIDs)
    unassignedBanksOnPanels = {} #create a dictionary using panel ID as the key
    for panelConnector in unassignedConnectorIDs:
        unassignedBanks = conn.execute("SELECT SupportedBanks from ePanelConnectorList WHERE ID == ?",(panelConnector[1],)).fetchone()[0]
        if panelConnector[0] in unassignedBanksOnPanels:
                unassignedBanksOnPanels[panelConnector[0]] += unassignedBanks
        else:
                unassignedBanksOnPanels[panelConnector[0]] = unassignedBanks
    sortedUnassignedBanksOnPanels = sorted(unassignedBanksOnPanels.items(), key=itemgetter(1)) #return smallest to largest for efficiency
    return sortedUnassignedBanksOnPanels

def get_unassigned_connectors_with_direction (conn, panelID, signalDirection):
    '''Returns a list of available banks on each panel within a rack. Signal direction is either input (0) or output (1)'''
    unassignedConnectorIDs = conn.execute("SELECT ID, ePanelConnectorID FROM UnassignedPanelConnectors WHERE PanelID == ?", (panelID,)).fetchall()
    logger.debug('Unassigned connectors ID, eID %s', unassignedConnectorIDs)
    unassignedBanksOnPanels = {} #create a dictionary using panel ID as the key
    for panelConnector in unassignedConnectorIDs:
        unassignedBanks = conn.execute("SELECT SupportedBanks from ePanelConnectorList WHERE ID == ?",(panelConnector[1],)).fetchone()[0]
        if panelConnector[0] in unassignedBanksOnPanels:
            unassignedBanksOnPanels[panelConnector[0]] += unassignedBanks
        else:
            unassignedBanksOnPanels[panelConnector[0]] = unassignedBanks
    sortedUnassignedConnectorsOnPanel = sorted(unassignedBanksOnPanels.items(), key=itemgetter(1)) #return smallest to largest for efficiency
    '''See if there are any signals assigned of the opposite signal type, if so, remove those from the list of what is available'''
    sortedUnassignedConnectorsOnPanel = [x[0] for x in sortedUnassignedConnectorsOnPanel]
    '''Get a list of panel connectors in the rack'''
    connectorIDs = conn.execute("SELECT ID FROM PanelConnectorInformation WHERE PanelID == ?", (panelID,)).fetchall() 
    '''Get a list of connectors with signals assigned of the opposite signal direction'''
    '''Create a blacklist'''
    blackTypeList = []
    for connectorID in connectorIDs:
        if (conn.execute("SELECT ID FROM SignalsInformation WHERE PanelConID == ? AND Output == ?", (connectorID[0], not signalDirection)).fetchone()):
            '''Remove any additional signals from the list that share the same 4-bank group'''
            '''Get the e-Type ID'''
            eConnectorTypeID = conn.execute("SELECT ePanelConnectorID FROM PanelConnectors WHERE ID == ?", (connectorID[0],)).fetchone()[0]
            if eConnectorTypeID not in blackTypeList:
                if eConnectorTypeID in [1,2,3,4]:
                    blackTypeList += [1,2,3,4]
                elif eConnectorTypeID in [5,6,7,8]:
                    blackTypeList += [5,6,7,8]
                elif eConnectorTypeID in [9,10,11,12]:
                    blackTypeList += [9,10,11,12]
                elif eConnectorTypeID in [13,14,15,16]:
                    blackTypeList += [13,14,15,16]
                elif eConnectorTypeID in [17,18,19,20]:
                    blackTypeList += [17,18,19,20]                    
    sortedDirectionalUnassignedConnectorsOnPanel = []
    if blackTypeList:
        for item in sortedUnassignedConnectorsOnPanel:
            ePanelConID = conn.execute("SELECT ePanelConnectorID FROM PanelConnectors WHERE ID == ?", (item,)).fetchone()[0]
            if ePanelConID not in blackTypeList:
                sortedDirectionalUnassignedConnectorsOnPanel.append(item)  
            else:
                logger.debug("Removing connector %s because its opposite input/output direction", item)   
        return sortedDirectionalUnassignedConnectorsOnPanel
    else:
        return sortedUnassignedConnectorsOnPanel
    
def list_of_assigned_panel_connectors(conn, panelList):
    '''Returns a list of all panel connectors that have already been assigned to signals for the provided list of panels'''
    connectorsOnPanels = conn.execute("SELECT ID, ePanelConnectorID FROM PanelConnectors WHERE PanelID IN (%s)" % ','.join('?'*len(panelList)), panelList).fetchall()
    assignedConnectors = conn.execute("SELECT Distinct PanelConID FROM SignalPanelConJunct").fetchall()
    connectorList = [x[0] for x in assignedConnectors]
    assignedConnectorsInPanels = []
    for connector in connectorsOnPanels:
        if connector[0] in connectorList:
            assignedConnectorsInPanels.append(connector[0])
    
    logger.debug('List of assigned connectors in panels %s', assignedConnectorsInPanels)
    return assignedConnectorsInPanels  

def assign_DUTConnector_signals_to_panels(conn, DUTCon, rackID, signalAlgorithmDict, eSignalPanelType): #DUTCon is a list of DUTConID and banks needed
    '''Assigns all signals on a list of DUT connectors provided by DUTCon to panels and adds new panels as needed.'''
    '''Add panels and assign DUTConnector signals to panel banks'''
    logger.info('%s to be assigned to panels with %s banks needed', DUTCon[0], DUTCon[1])
    
    '''First assign bulkheads. Pass in all signals at once because there is only one bulkhead panel on the first rack.'''
    bulkheadSignalTypes = conn.execute("SELECT DISTINCT SignalType, AssignmentPriority FROM SignalsInformation WHERE Bulkhead == ?", (True,)).fetchall()     
    bulkheadSignalTypes = sorted(bulkheadSignalTypes, key=itemgetter(1))
    for signalType in bulkheadSignalTypes:
        bulkheadSignalsToAssign = conn.execute("SELECT t1.ID, t1.SignalName FROM SignalsInformation t1 LEFT JOIN SignalPanelConJunct t2 on t1.ID == t2.SignalID WHERE t2.SignalID IS NULL AND t1.Bulkhead == ? AND t1.signalType == ?", (True, signalType[0])).fetchall()
        algorithm = signalAlgorithmDict[signalType[0]]
        algorithm.assignToPanel(conn, None, bulkheadSignalsToAssign)
            
    '''See if an existing panel has enough space and can be reused for all of the signals on a DUTConnector.'''
    panelSelected = []
    reuse = None
    panelsWithUnassignedBanks = get_unassigned_panel_banks(conn, rackID)
    logger.debug('Searching for DUTCon match through panels with unassigned banks: %s', panelsWithUnassignedBanks)
    for panelBanks in panelsWithUnassignedBanks:
        panelConnectors = conn.execute("SELECT ID FROM PanelConnectors WHERE PanelID == ?", (panelBanks[0],)).fetchall()
        panelConnectors = [x[0] for x in panelConnectors]    
        reuseTestPanelConnectors = list(panelConnectors)    
        '''Go through each signal type on the panel and make sure they would all fit'''
        signalTypes = conn.execute("SELECT DISTINCT SignalType, AssignmentPriority FROM SignalsInformation WHERE Bulkhead == ? AND DUTConnector == ? ORDER BY AssignmentPriority", (False,DUTCon[0])).fetchall() #Rerun the query to reset the cursor object to the top
        for signalType in signalTypes:
            signalsToAssign = conn.execute("SELECT t1.ID, t1.SignalName FROM SignalsInformation t1 LEFT JOIN SignalPanelConJunct t2 on t1.ID == t2.SignalID WHERE t2.SignalID IS NULL AND t1.DUTConnector == ? AND t1.Bulkhead == ? AND t1.SignalType == ?", (DUTCon[0], False, signalType[0])).fetchall()
            logger.debug('Next signal type to check for a fit is %s', signalType[0])            
            if (signalsToAssign):
                if signalType[0] in signalAlgorithmDict:
                    algorithm = signalAlgorithmDict[signalType[0]]
                    '''Test the algorithm to see if things fit'''
                    reuseTestPanelConnectors = algorithm.assignToPanel(conn, reuseTestPanelConnectors, (signalsToAssign), commit=False)   
                    if reuseTestPanelConnectors == -1:
                        '''This means that the algorithm ran out of room on that panel'''
                        logger.debug("Panel ID %s is full, continuing with new panel", panelBanks[0])
                        panelSelected = []
                        reuse = False
                        break      
                else:
                    logger.error("No assignment algorithm class is associated with signal type %s", signalType[0])
                    return -1       
        '''If the search didn't stop because of a mismatch, then this panel is compatible.'''
        if reuse == False:
            '''Reset to none to try on the next one'''
            reuse = None
        elif reuse is None:
            reuse = True
            logger.debug("Reusing panel %s", panelBanks[0])
            panelSelected.append(panelBanks[0])
            break
    '''This occurs if there are not existing panels to choose from'''
    if reuse == None:
        reuse = False
    if reuse == False:    
        logger.debug("No reusable panel found")
        panelSelected = []    
    '''Either a panel was selected to fit the DUTCon, or a new panel needs to be added'''
    
    '''Make sure there are signals that still need to be assigned'''
    signalsToAssign = conn.execute("SELECT t1.ID FROM SignalsInformation t1 LEFT JOIN SignalPanelConJunct t2 on t1.ID == t2.SignalID WHERE t2.SignalID IS NULL AND t1.DUTConnector == ? AND t1.Bulkhead == ?", (DUTCon[0], False)).fetchall()
    logger.debug("Assigning signals to panel")
    while len(signalsToAssign):
        '''If no existing panels work, add new Panels to assign signals to'''    
        if panelSelected == [] and reuse == False:
            #rackID = racks.get_rack_with_most_space(conn, [rackID], racks.RackSpaceType.FRONT)
            newPanelID = insert_panel_into_rack(conn, rackID, eSignalPanelType)
            if newPanelID > -1:
                panelSelected.append(newPanelID)
                panelConnectors = conn.execute("SELECT ID FROM PanelConnectors WHERE PanelID == ?", (panelSelected[0],)).fetchall()
                panelConnectors = [x[0] for x in panelConnectors]
            else:
                logger.debug("Failed to assign DUT to panel in rack %s", rackID)
                return newPanelID
        
        logger.debug('Assigning DUT signals to panel banks...')
        #sortedPanelConnectors = sorted(conn.execute("SELECT ID, SupportedBanks FROM UnassignedPanelConnectors WHERE PanelID == ?", (panelSelected.pop(0),)).fetchall(), key=itemgetter(1))     
        
        signalTypes = conn.execute("SELECT DISTINCT SignalType, AssignmentPriority FROM SignalsInformation WHERE Bulkhead == ? AND DUTConnector == ? ORDER BY AssignmentPriority", (False,DUTCon[0])).fetchall() #Rerun the query to reset the cursor object to the top
        for signalType in signalTypes:
            logger.debug('Next signal type to assign %s', signalType[0])
            '''Get a list of unassigned signals to assign for panel assignment'''
            faultSignalsToAssign = conn.execute("SELECT t1.ID, t1.SignalName FROM Signals t1 LEFT JOIN SignalPanelConJunct t2 on t1.ID == t2.SignalID WHERE t2.SignalID IS NULL AND t1.SignalType == ? AND t1.DUTConnector == ? AND t1.LineFault == ? ORDER BY t1.ID", (signalType[0], DUTCon[0], True)).fetchall()
            remainingSignalsToAssign = conn.execute("SELECT t1.ID, t1.SignalName FROM Signals t1 LEFT JOIN SignalPanelConJunct t2 on t1.ID == t2.SignalID WHERE t2.SignalID IS NULL AND t1.SignalType == ? AND t1.DUTConnector == ? AND t1.LineFault == ? ORDER BY t1.ID", (signalType[0], DUTCon[0], False)).fetchall() 
            if (len(faultSignalsToAssign) + len(remainingSignalsToAssign)):
                if signalType[0] in signalAlgorithmDict:
                    algorithm = signalAlgorithmDict[signalType[0]]
                    if reuse == True:
                        '''If reuse is true, that means that everything should fit on this panel because we already tested it'''
                        panelConnectors = algorithm.assignToPanel(conn, panelConnectors, (faultSignalsToAssign + remainingSignalsToAssign), commit=True)   
                        if panelConnectors == -1:
                            '''This means that the algorithm ran out of room on that panel'''
                            logger.error("Panel ID %s is full even though it previously had enough space", panelSelected[0])
                            return -1
                        elif panelConnectors == -2:
                            '''This means to skip this signal type'''
                            logger.debug("Skipping panel assignment for signalType %s", signalType[0])
                        elif panelConnectors == -3:
                            '''This means something went wrong and the program should stop'''
                            logger.error("Failed to assign signal type %s to panel", signalType[0])
                            return -3
                    else:
                        '''Check if this signal type uses more than 20 banks'''
                        signalsPerBank = conn.execute("SELECT SignalsPerBank FROM eSignalTypes WHERE Name == ?", (signalType[0],)).fetchone()[0]
                        multiplePanels = False
                        skipSignalType = False                 
                        if (len(faultSignalsToAssign + remainingSignalsToAssign))/signalsPerBank > 20:
                            '''check if any of the other remaining signal types have less than 20 banks that can be tried'''
                            multiplePanels = True
                            logger.info("This signal type requires more than 20 banks %s", signalType[0])
                            '''If this is a fresh panel then use it, otherwise see if any other signal types can'''
                            signalDirection = conn.execute("SELECT Output FROM eSignalTypes WHERE Name == ?", (signalType[0],)).fetchone()[0]
                            compatiblePanelConnectors = get_unassigned_connectors_with_direction(conn, panelSelected[0], signalDirection)                            
                            allPanelConnectors = conn.execute("SELECT ID FROM PanelConnectors WHERE PanelID == ?", (panelSelected[0],)).fetchall()
                            allPanelConnectors = [x[0] for x in allPanelConnectors]
                            if compatiblePanelConnectors != allPanelConnectors:
                                indexFound = False
                                for item in signalTypes:
                                    if indexFound:
                                        numSignals = conn.execute("SELECT COUNT(*) FROM Signals t1 LEFT JOIN SignalPanelConJunct t2 on t1.ID == t2.SignalID WHERE t2.SignalID IS NULL AND  t1.SignalType == ? AND t1.DUTConnector == ?", (item[0], DUTCon[0])).fetchone()[0]                                       
                                        '''If there are unassigned signals of that type'''
                                        if numSignals is not 0:
                                            signalsPerBank = conn.execute("SELECT SignalsPerBank FROM eSignalTypes WHERE Name == ?", (signalType[0],)).fetchone()[0]
                                            '''If a signalType has less than 20 banks, skip this one to try that one'''
                                            if ((numSignals/signalsPerBank) < 20):
                                                logger.debug("SignalType %s has less than 20 banks so trying that instead", item[0])
                                                skipSignalType = True
                                    else:
                                        if item[0] == signalType[0]:
                                            indexFound = True
                            else:
                                logger.info("Assigning 20 banks to fresh panel")
                                break
                        '''If it can fit on one panel, check to see if it fits before assigning. If it doesn't then skip it.'''
                        if multiplePanels == False:
                            fitTestPanelConnectors = list(panelConnectors)
                            test = algorithm.assignToPanel(conn, fitTestPanelConnectors, (faultSignalsToAssign + remainingSignalsToAssign), commit=False)
                            if test == -1:
                                logger.debug("Signal type %s doesn't fit on panel. Skipping it for now to see if others fit.", signalType[0])
                                skipSignalType = True                        
                        if skipSignalType is False:
                            panelConnectors = algorithm.assignToPanel(conn, panelConnectors, (faultSignalsToAssign + remainingSignalsToAssign), commit=True)                             
                            if panelConnectors == -1:
                                '''Already checked for this. Return error'''
                                logger.error("Signal type %s doesn't fit on panel even though it was tested to work.", signalType[0])
                                if multiplePanels == True:
                                    logger.info("Ran out of room on this panel, assigning the remaining signals on the next")
                                    break
                                if multiplePanels == False:
                                    '''This is expected if that signalType spans multiple panels'''
                                    return -1
                            elif panelConnectors == -2:
                                '''This means to skip this signal type'''
                                logger.debug("Skipping panel assignment for signalType %s", signalType[0])
                            elif panelConnectors == -3:
                                '''This means something went wrong and the program should stop'''
                                logger.error("Failed to assign signal type %s to panel", signalType[0])
                                return -3                                
                else:
                    logger.error("No assignment algorithm class is associated with signal type %s", signalType[0])
                    return -1
        '''Reset selected panel to empty as we are done with the last one'''
        panelSelected = []
        '''Check which non-bulkhead signals for that DUTCon still haven't been assigned'''
        signalsToAssign = conn.execute("SELECT t1.ID, t1.SignalName FROM SignalsInformation t1 LEFT JOIN SignalPanelConJunct t2 on t1.ID == t2.SignalID WHERE t2.SignalID IS NULL AND t1.DUTConnector == ? AND t1.Bulkhead == ?", (DUTCon[0], False)).fetchall()           
    return 0
 