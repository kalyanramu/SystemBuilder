'''
Created on Jul 26, 2017

@author: bsnover

All functions relating to signals and the algorithms required to assign specific signal types.
'''

import pandas as pd
from operator import itemgetter
import math, LRUconstants, signals, panels, racks, routing, slsc, pxi, cables, inspect, logging
logger = logging.getLogger(__name__) 

def import_signals_from_csv(path, conn, algorithmDict):
    '''Imports a CSV file in a specific format and inserts all of its information into the Signals table of a database'''
    func = inspect.stack()[1][4]
    '''Read in a CSV with all test signals and print the results'''
    df = pd.read_csv(path)
    logger.debug('%s \n %s', func, df)
    #===========================================================================
    # '''Find constants needed for support of custom signal types'''
    # integratorID = conn.execute("SELECT ID FROM eManufacturers WHERE Name == ?", (LRUconstants.INTEGRATOR_MANUFACTURER_NAME,)).fetchone()[0]
    # HD44ConnectorTypeID = conn.execute("SELECT ID FROM eConnectorTypes WHERE Name == ?", ('HD44',)).fetchone()[0]
    # RTIConnectorTypeID = conn.execute("SELECT ID FROM eConnectorTypes WHERE Name == ?", ('RTI',)).fetchone()[0]
    #===========================================================================
                    
    '''Add all signals from the CSV into the new Database'''
    cursor = conn.cursor()
    for index, row in df.iterrows():
        '''Check for any custom signal names and add additional hardware to the database to support them as needed.'''
        if row[1].find(LRUconstants.CUSTOM_2WIRE_INPUT_NAME) > -1 or row[1].find(LRUconstants.CUSTOM_2WIRE_OUTPUT_NAME) > -1 or row[1].find(LRUconstants.CUSTOM_4WIRE_INPUT_NAME) > -1 or row[1].find(LRUconstants.CUSTOM_4WIRE_OUTPUT_NAME) > -1 or row[1].find(LRUconstants.CUSTOM_8WIRE_INPUT_NAME) > -1 or row[1].find(LRUconstants.CUSTOM_8WIRE_OUTPUT_NAME) > -1:
            '''Check to see if a signal of that type has already been added to the list of signal types'''
            if conn.execute("SELECT Name FROM eSignalTypes WHERE Name == ?", (row[1],)).fetchone() is None:
                '''If not, add it to the list of signal types'''
                if row[1].find(LRUconstants.CUSTOM_2WIRE_INPUT_NAME) > -1:
                    numPins = 2
                    signalsPerBank = 4
                    output = False
                elif row[1].find(LRUconstants.CUSTOM_2WIRE_OUTPUT_NAME) > -1:
                    numPins = 2
                    signalsPerBank = 4
                    output = True
                elif row[1].find(LRUconstants.CUSTOM_4WIRE_INPUT_NAME) > -1:
                    numPins = 4
                    signalsPerBank = 2
                    output = False
                elif row[1].find(LRUconstants.CUSTOM_4WIRE_OUTPUT_NAME) > -1:
                    numPins = 4
                    signalsPerBank = 2
                    output = True
                elif row[1].find(LRUconstants.CUSTOM_8WIRE_INPUT_NAME) > -1:
                    numPins = 8
                    signalsPerBank = 1
                    output = False
                elif row[1].find(LRUconstants.CUSTOM_8WIRE_OUTPUT_NAME) > -1:
                    numPins = 8
                    signalsPerBank = 1
                    output = True    
                conn.execute("INSERT INTO eSignalTypes (Name, NumPins, SignalsPerBank, Output, Bulkhead) VALUES (?,?,?,?,?)", (row[1], numPins, signalsPerBank, output, 0))
                #===============================================================
                # '''Add a new card of that type'''
                # cardTypeID = conn.execute("INSERT INTO eSLSCCardTypes (Model, ManufacturerID, ListPrice, NIChannel) VALUES (?,?,?,?)", (row[1], integratorID, 1000, 0)).lastrowid
                # conn.commit()
                # '''Add J1, J2, and XJ2 connectors'''
                # conn.execute("INSERT INTO eSLSCConnectorList (eSLSCCardTypeID, ConnectorLabel, eConnectorTypeID, eEndTypeID) VALUES (?,?,?,?)", (cardTypeID, 'J1', HD44ConnectorTypeID, 1))
                # conn.execute("INSERT INTO eSLSCConnectorList (eSLSCCardTypeID, ConnectorLabel, eConnectorTypeID, eEndTypeID) VALUES (?,?,?,?)", (cardTypeID, 'J2', HD44ConnectorTypeID, 1))
                # conn.execute("INSERT INTO eSLSCConnectorList (eSLSCCardTypeID, ConnectorLabel, eConnectorTypeID, eEndTypeID) VALUES (?,?,?,?)", (cardTypeID, 'XJ2', RTIConnectorTypeID, 1))                              
                # conn.commit()
                #===============================================================
                '''Add signals to the signal assignment dictionary'''
                algorithmDict[row[1]] = signals.CUSTOMXWIRE(conn, row[1])   
        try:
            cursor.execute('''INSERT INTO Signals (SignalName, SignalType, DUTConnector, RealConnector, LineFault) VALUES(?,?,?,?,?)''', (row[0], row[1], row[2], row[3], (row[4] == 'Yes')))
        except:
            logger.error("Error inserting into Signals Table. Error is likely that signal type %s is typed wrong or unsupported at line %s. Check the LRUconstants module for correct strings.", row[1], index+2)
            raise  
    conn.commit()
    '''Print all data from the Signals table in the database'''    
    #cursor = conn.execute("SELECT SignalName, SignalType from Signals")
    #for row in cursor:
        #print ("SignalName = ", row[0], "SignalType = ", row[1])  
    return algorithmDict

def assign_signal_path_HW(conn, rackID, signalAlgorithmDict, DUTConRackAssignment, crossRacks):
    '''Assigns hardware for the full signal path of a signal AFTER the panel. This includes routing.'''
    '''Only assign bulkead signals to first rack'''
    '''TODO figure out a more elegant way to assign all bulkheads to a single rack'''
    numRacks = conn.execute("SELECT COUNT(*) FROM Racks").fetchone()[0]
    if numRacks == 1:
        signalTypes = conn.execute("SELECT DISTINCT SignalType, AssignmentPriority FROM SignalsInformation WHERE RackID == ? OR Bulkhead == ?", (rackID, True)).fetchall()
    else:
        signalTypes = conn.execute("SELECT DISTINCT SignalType, AssignmentPriority FROM SignalsInformation WHERE RackID == ?", (rackID,)).fetchall()        
    sortedSignalTypes = sorted(signalTypes, key=itemgetter(1))
    logger.debug("Sorted signal types on rack %s", sortedSignalTypes)
    '''Calls each class routing card assignment algorithm for each signal type'''
    logger.debug("Assigning after routing SLSC cards for all signals in rack")  
    for signalType in sortedSignalTypes:
        if signalType[0] in signalAlgorithmDict:
            algorithm = signalAlgorithmDict[signalType[0]]
            error = algorithm.connectRouting(conn, rackID)     
        else:
            logger.error("No assignment algorithm class is associated with signal type %s", signalType[0])
    if error < 0:
        return error
    '''Calls each class signal assignment algorithm for each signal type'''
    logger.debug("Assigning after routing SLSC cards for all signals in rack")  
    '''For each signal type, pick an SLSC card (if any) to operate on that signal'''
    for signalType in sortedSignalTypes:
        if signalType[0] in signalAlgorithmDict:
            logger.info("Assigning HW for Signal Type %s", signalType[0])
            algorithm = signalAlgorithmDict[signalType[0]]
            error = algorithm.assignToHW(conn, rackID, crossRacks)
            if error is not None:
                if error < 0:
                    logger.error("Error %s occurred during signal assignment", error)
                    return error       
        else:
            logger.error("No assignment algorithm class is associated with signal type %s", signalType[0])
    for signalType in sortedSignalTypes:        
        algorithm = signalAlgorithmDict[signalType[0]]        
        error = algorithm.connectPanelForRealSignals(conn, rackID, DUTConRackAssignment)
        if error < 0:
            logger.error("Error %s occurred during real signal to panel assignment", error)
            return error
    for signalType in sortedSignalTypes:         
        algorithm = signalAlgorithmDict[signalType[0]]
        error = algorithm.connectInstrumentRouting(conn, rackID)
        if error < 0:
            logger.error("Error %s occurred assigning instrument routing", error)                
            return error 
    return 0

class SignalAssignment:
    '''Parent class for algorithms that assign hardware for a signal type. One algorithm can work on multiple signals. The parent implementation does nothing.'''
    def __init__(self, conn, signalType):
        self.signalType = signalType
        self.bulkhead = conn.execute("SELECT Bulkhead FROM eSignalTypes WHERE Name == ?", (self.signalType,)).fetchone()[0]
        self.routingCardTypeID = conn.execute("SELECT ID FROM eSLSCCardTypes WHERE Model == ?", (LRUconstants.ROUTING_CARD_NAME,)).fetchone()[0]
        self.routingConnIDs = [conn.execute("SELECT ID FROM eSLSCConnectorList WHERE eSLSCCardTypeID == ? AND ConnectorLabel == ?", (self.routingCardTypeID, 'J1')).fetchone()[0]]
        self.calConnIDs = [conn.execute("SELECT ID FROM eSLSCConnectorList WHERE eSLSCCardTypeID == ? AND ConnectorLabel == ?", (self.routingCardTypeID, 'J2')).fetchone()[0]]
        '''Child implementations will generally need to save the signalType as private data. They may also want to look up what hardware to use here so it only happens once.'''
    
    def assignToPanel(self, conn, inputPanelConnectors, signalListTuple, commit = True):
        '''Generic panel assignment algorithm for all non-bulkhead signals. Calling function passes in a list of connectors to use and the list of signals to assign'''
        '''inputPanelConnectors is a list of all potentially available connectors on a single panel, some may already have signals assigned'''
        '''When commit is false, this function should simply check to see there is room on the panel for those signals and return -1 if not'''
        '''Return the inputPanelConectors minus those that were assigned, Return -1 if the available connectors runs out before the signal list'''
        if not inputPanelConnectors:
            return -1
        '''Find how many of those signals fit into a Bank'''
        signalsPerBank = conn.execute("SELECT SignalsPerBank FROM eSignalTypes WHERE Name == ?", (self.signalType,)).fetchone()[0]
        '''Only use connectors with no signals assigned'''
        signalDirection = conn.execute("SELECT Output FROM eSignalTypes WHERE Name == ?", (self.signalType,)).fetchone()[0]
        panelID = conn.execute("SELECT PanelID FROM PanelConnectors WHERE ID == ?", (inputPanelConnectors[0],)).fetchone()[0]
        compatiblePanelConnectors = panels.get_unassigned_connectors_with_direction(conn, panelID, signalDirection)
        assignablePanelConnectors = []
        for connector in compatiblePanelConnectors:
            if connector in inputPanelConnectors:
                assignablePanelConnectors.append(connector)       
        '''Assign signals to panel connectors'''
        while (len(signalListTuple)):
            if (len(assignablePanelConnectors) == 0):
                '''Return -1 when out of connectors that can be used'''
                return -1
            banksNeeded = int(math.ceil((len(signalListTuple))/signalsPerBank))
            logger.debug('%s banks are needed with number of signals %s and signals per bank %s', banksNeeded, (len(signalListTuple)), signalsPerBank)
            logger.debug('Panel cons to assign with number of banks %s', assignablePanelConnectors)
                
    #===============================================================================
    #             '''Select the best fitting connector, pick the smallest connector that will fit all signals or else pick the largest connector'''           
    #             index = -1
    #             for i in range (len(sortedPanelConnectors)):
    #                 if banksNeeded <= sortedPanelConnectors[i][1]:
    #                     index = i
    #                     break
    #             
    #             '''get the element at the found index or grab the last index'''
    #             if index > -1:
    #                 selectedCon = sortedPanelConnectors.pop(index)
    # 
    #             else:
    #                 selectedCon = sortedPanelConnectors.pop()
    #             logger.debug('Selected connector %s new list %s', selectedCon[0], sortedPanelConnectors)
    #===============================================================================
            selectedCon = assignablePanelConnectors.pop(0)
            inputPanelConnectors.remove(selectedCon)
            '''Assign signals needing line faulting first, then assign those that don't'''
            numPinsPerSignal = conn.execute("SELECT NumPins FROM eSignalTypes WHERE NAME == ?", (self.signalType,)).fetchone()[0]
            signalsAssigned = 0            
            bank = 0
            '''bankPins are 1-indexed'''
            bankPin = 1
            while (signalsAssigned < signalsPerBank):
                if signalListTuple:
                    signalToAssign = signalListTuple.pop(0)[0]
                    if commit:
                        conn.execute("INSERT INTO SignalPanelConJunct (SignalID, PanelConID, Real) VALUES (?,?,?)", (signalToAssign,selectedCon,False))
                    for i in range (numPinsPerSignal):
                        if commit:
                            conn.execute("INSERT INTO SignalPanelPinJunct (SignalID, PanelConID, ConnectorBank, BankPin) VALUES (?,?,?,?)", (signalToAssign,selectedCon, bank, bankPin))
                        if bankPin == LRUconstants.PINS_PER_BANK:
                            bankPin = 1
                            bank += 1
                        bankPin += 1                   
                    signalsAssigned += 1
                else:
                    break
            if commit:
                conn.commit()        
        return inputPanelConnectors
    
    def getFreeRoutingFrontCableDB9IDs(self, conn, rackID):
        '''Returns a dictionary of unused DB9 cable connectors from cables connected to the front of a routing card'''
        '''First find compatible panel connectors'''
        panelConnIDs = conn.execute("SELECT DISTINCT PanelConID FROM SignalsInformation WHERE RackID == ? ORDER BY PanelConID", (rackID,)).fetchall()
        '''Next find the HD44 cable routing card connectors they are connected to'''
        openDB9IDs = {}
        for panelConnID in panelConnIDs:
            '''TODO only return connectors for compatible signal types here. Input don't match with output for example'''
            DB9ID = conn.execute("SELECT CableConID FROM PanelCableConJunct WHERE PanelConID == ?", (panelConnID[0],)).fetchone()
            if DB9ID:
                cableID = conn.execute("SELECT CableID, eEndTypeID  FROM CableConnectorInformation WHERE ID == ?", (DB9ID[0],)).fetchone()
                DB9ConnIDs = conn.execute("SELECT ID FROM CableConnectorInformation WHERE CableID == ? AND eEndTypeID == ?", (cableID[0], cableID[1])).fetchall()
                for DB9ConnID in DB9ConnIDs:
                    found = conn.execute("SELECT ID FROM PanelCableConJunct WHERE CableConID == ?", (DB9ConnID[0],)).fetchone()
                    if not found:
                        openDB9IDs[DB9ConnID[0]] = cableID[0]
        return openDB9IDs 
    
    def getPanelSignalConnectors(self, conn, panelList, cableCon=False, realOnly=False):
        assignedConnectorsInPanels = panels.list_of_assigned_panel_connectors(conn, panelList)
        '''Find which panel connectors have that signal type assigned based on input parameters'''
        if cableCon:
            if realOnly:
                connIDs = conn.execute("SELECT DISTINCT PanelConID FROM SignalsInformation WHERE SignalType == ? AND CableConID IS NOT ? AND RealConnector IS NOT ? AND Real IS ? ORDER BY PanelConID", (self.signalType, None, None, False)).fetchall()
            else:
                connIDs = conn.execute("SELECT DISTINCT PanelConID FROM SignalsInformation WHERE SignalType == ? AND CableConID IS NOT ? AND Real IS ? ORDER BY PanelConID", (self.signalType, None, False)).fetchall()                
        else:
            if realOnly:
                connIDs = conn.execute("SELECT DISTINCT PanelConID FROM SignalsInformation WHERE SignalType == ? AND CableConID IS ? AND RealConnector IS NOT ? AND Real IS ? ORDER BY PanelConID", (self.signalType, None, None, False)).fetchall()                
            else:
                connIDs = conn.execute("SELECT DISTINCT PanelConID FROM SignalsInformation WHERE SignalType == ? AND CableConID IS ? AND Real IS ? ORDER BY PanelConID", (self.signalType, None, False)).fetchall()                 
        connIDs = [x[0] for x in connIDs]
        connIDs = list(set(connIDs) & set(assignedConnectorsInPanels))
        logger.debug('Panel connector IDs without attached cables %s', connIDs)
        '''Sometimes a null ID is included. Try to remove it and ignore the error if one wasn't found.'''
        try:
            connIDs.remove(None,)
        except:
            pass
        return connIDs
    
    def connectRouting(self, conn, rackID):
        '''This function does most of the work of connecting routing cards for each signal type for all panels on a specific rack'''
        '''TODO: select routing card...assume only one type for now'''
        '''Get D9-D9-D9-D9<->HD44 CableTypeID'''
        eCableTypeID = conn.execute("SELECT ID FROM eCableTypes WHERE Name == ?", (LRUconstants.HD44_DB9_CABLE_NAME,)).fetchone()[0]
        logger.debug('Adding routing cards for signal type %s for panels in rackID %s', self.signalType, rackID)
        routingCardTypeID = conn.execute("SELECT ID FROM eSLSCCardTypes WHERE Model == ?", (LRUconstants.ROUTING_CARD_NAME,)).fetchone()[0]
        J1ID = conn.execute("SELECT ID FROM eSLSCConnectorList WHERE eSLSCCardTypeID == ? AND ConnectorLabel == ?", (routingCardTypeID, 'J1')).fetchone()[0]
        '''Find every connector with signals assigned for every panel in that rack'''    
        panelIDsInRack = conn.execute("SELECT ID FROM Panels WHERE RackID = ?", (rackID,)).fetchall()
        panelList = [x[0] for x in panelIDsInRack]
        connIDs = self.getPanelSignalConnectors(conn, panelList, cableCon=None, realOnly=False)
        connInfo = conn.execute("SELECT ID, ConnectorType FROM PanelConnectorInformation WHERE ID IN (%s)" % ','.join('?'*len(connIDs)), connIDs).fetchall()
        connInfo = [x for x in connInfo]
        fullConnInfo = []
        '''Identify which connectors have signals requiring line faulting'''
        for connector in connInfo:
            lineFaultSignals = conn.execute("SELECT LineFault FROM SignalsInformation WHERE PanelConID == ?", (connector[0],)).fetchall()
            if (1,) in lineFaultSignals:
                fullConnInfo.append(connector + (1,))
            else:
                fullConnInfo.append(connector + (0,))
        sortedConnInfo = sorted(fullConnInfo, key=lambda tup: tup[2])
        '''TODO Prioritize connectors on the same panel first, then connect straglers across panels'''
        '''While there are more than 4 DB9s, just add a routing card and connect.'''
        '''Once less than 4, check if there are enough compatible cables available and connect to those if so, otherwise add a new card again'''
        openDB9IDs = self.getFreeRoutingFrontCableDB9IDs(conn, rackID)
        
        while len(sortedConnInfo):
            #numPanelBanksToAssign = conn.execute("SELECT sum(t2.SupportedBanks) FROM PanelConnectors t1 LEFT JOIN ePanelConnectorList t2 ON t1.ePanelConnectorID == t2.ID WHERE t1.ID IN (%s)" % ','.join('?'*len(connIDs)), connIDs).fetchone()[0]
            '''If number of panel connectors is greater than the number of open DB9s, we may need to add more cards to have more open DB9s'''
            if (len(sortedConnInfo) > len(openDB9IDs)):
                "Find an unused routing card, and add a new card if needed"
                connInfo = slsc.check_for_an_open_SLSC_connector(conn, [J1ID], rackID, False)              
                if (connInfo is None):
                    SLSCCardID = slsc.insert_SLSC_card_into_chassis(conn, routingCardTypeID, rackID)
                    if SLSCCardID < 0:
                        return SLSCCardID 
                else:
                    SLSCCardID = connInfo[1]           
                cableID = cables.add_new_cable(conn, eCableTypeID)               
                '''Attach the SLSC end of the cable. TODO lookup the value for 4 instead of hardcoding'''
                SLSCCableConID = conn.execute("SELECT ID FROM CableConnectorInformation WHERE ConnectorTypeName == ? AND CableID == ?", ('HD44', cableID)).fetchone()[0]
                SLSCConID = conn.execute("SELECT ID FROM SLSCConnectors WHERE SLSCCardID == ? AND eSLSCConnectorID == ?", (SLSCCardID, 4)).fetchone()[0]
                conn.execute("INSERT INTO SLSCCableConJunct (SLSCConID, CableConID) VALUES (?,?)", (SLSCConID, SLSCCableConID)) 
                panelCableConIDs = conn.execute("SELECT ID FROM CableConnectorInformation WHERE ConnectorTypeName == ? AND CableID == ?", ('DB9', cableID))               
                faulting = 0
                for i in range(4):
                    if sortedConnInfo:
                        panelCableConID = panelCableConIDs.fetchone()[0]
                        conn.execute("INSERT INTO PanelCableConJunct (PanelConID, CableConID) VALUES (?,?)", (sortedConnInfo[0][0], panelCableConID))
                        faulting = faulting | sortedConnInfo[0][2]
                        sortedConnInfo.pop(0)
                    else:
                        break
                '''Add faulting hardware if required'''
                if faulting:
                    '''Section 0 is the top half, Section 1 being bottom. TODO fix hardcoded value here'''
                    routing.add_daughter_card_to_section(conn, SLSCCardID, eDaughterCardTypeID=1, section= 0)               
                conn.commit()
            else:
                faulting = 0
                while (sortedConnInfo):
                    DB9ID = openDB9IDs.popitem()
                    conn.execute("INSERT INTO PanelCableConJunct (PanelConID, CableConID) VALUES (?,?)", (sortedConnInfo[0][0], DB9ID[0]))
                    conn.commit()
                    faulting = faulting | sortedConnInfo[0][2]
                    sortedConnInfo.pop(0)
                    if faulting:
                        '''Find the routing card ID that DB9 came from and add a fault daughter card'''
                        SLSCCardID = conn.execute("SELECT SLSCCardID FROM SignalsInformation WHERE CableConID == ? AND Real == ?", (DB9ID[0], 0)).fetchone()[0]
                        routing.add_daughter_card_to_section(conn, SLSCCardID, eDaughterCardTypeID=1, section= 0)
        logger.debug("Signal Routing Complete")
        return 0
    
    def connectPanelForRealSignals(self, conn, rackID, DUTConRackAssignment):
        '''Adds panels, other hardware, and connections needed for any signals that require a real counterpart'''
        '''Attempt to assign panel connectors in the same order for ease of DUT wiring'''
        ePanelTypeID = conn.execute("SELECT ID FROM ePanelTypes WHERE ModelNumber == ?", (LRUconstants.SIGNAL_PANEL_NAME,)).fetchone()[0]
        signals = conn.execute("SELECT ID, RealConnector FROM SignalsInformation WHERE SignalType == ? AND RackID == ? AND Real == ?", (self.signalType, rackID, False))
        for signal in signals:
            if signal[1] is not None:
                simPanelCon = conn.execute("SELECT PanelConID, ePanelConnectorID, PanelID FROM SignalsInformation WHERE RackID == ? AND Real == ? AND ID == ?", (rackID, False, signal[0])).fetchone()
                if simPanelCon:
                    '''Check if there is a panel with real signals for that connector already'''
                    panelID = conn.execute("SELECT ID FROM Panels WHERE ReferencePanelID == ?", (simPanelCon[2],)).fetchone()
                    if panelID is None:
                        panelID = panels.insert_panel_into_rack(conn, rackID, ePanelTypeID, referencePanelID = simPanelCon[2])
                    else:
                        panelID = panelID[0]
                    matchingConnID = conn.execute("SELECT ID FROM PanelConnectors WHERE ePanelConnectorID == ? AND PanelID == ?", (simPanelCon[1], panelID)).fetchone()[0]
                    conn.execute("INSERT INTO SignalPanelConJunct (SignalID, PanelConID, Real) VALUES (?,?,?)", (signal[0], matchingConnID, True))
                    conn.commit()
                    '''Check if a cable is already connected to the real panel connector'''
                    realCableCon = conn.execute("SELECT ID FROM PanelCableConJunct WHERE PanelConID == ?", (matchingConnID,)).fetchone()
                    if realCableCon is None:
                        '''Connect the routing card if not already connected'''
                        '''Check if the SLSC card already has a cable connected on J2, if not, add one TODO fix hardcode'''
                        SLSCCardID = conn.execute("SELECT SLSCCardID FROM SignalsInformation WHERE PanelConID == ?", (simPanelCon[0],)).fetchone()[0]                 
                        J2ConnID = conn.execute("SELECT ID FROM SLSCConnectors WHERE SLSCCardID == ? AND eSLSCConnectorID == ?", (SLSCCardID,5)).fetchone()
                        if J2ConnID is None:
                            print("No routing card for Real Signal, using SLSC Card ID", SLSCCardID, "instead.")
                        else:
                            J2ConnID = J2ConnID[0]
                            realCableInfo = conn.execute("SELECT CableConID FROM SLSCCableConJunct WHERE SLSCConID == ?", (J2ConnID,)).fetchone()
                            '''Get the eID for the cable connector for the Sim cable and Reuse for Real'''
                            simCableID = conn.execute("SELECT CableID FROM SignalsInformation WHERE PanelConID == ?", (simPanelCon[0],)).fetchone()[0]
                            simCableConID = conn.execute("SELECT CableConID FROM SignalsInformation WHERE PanelConID == ?", (simPanelCon[0],)).fetchone()[0]
                            eSimCableConID = conn.execute("SELECT eCableConnectorID FROM CableConnectors WHERE ID == ?", (simCableConID,)).fetchone()[0]
                            if realCableInfo:                       
                                cableID = conn.execute("SELECT CableID FROM CableConnectors WHERE ID == ?", (realCableInfo[0],)).fetchone()[0]
                            else:
                                eSimCableTypeID = conn.execute("SELECT eCableTypeID FROM Cables WHERE ID == ?", (simCableID,)).fetchone()[0]                         
                                cableID = cables.add_new_cable(conn, eSimCableTypeID)
                                SLSCCableConID = conn.execute("SELECT ID FROM CableConnectorInformation WHERE ConnectorTypeName == ? AND CableID == ?", ('HD44', cableID)).fetchone()[0]                                                
                                conn.execute("INSERT INTO SLSCCableConJunct (SLSCConID, CableConID) VALUES (?,?)", (J2ConnID, SLSCCableConID))
                                conn.commit()                    
                            '''Connect the proper end of the cable to the panel if it isn't already connected'''
                            logger.debug("Real signal panel cableID %s, and eSimCableConID %s", cableID, eSimCableConID)
                            panelCableConID = conn.execute("SELECT ID FROM CableConnectors WHERE CableID == ? AND eCableConnectorID == ?", (cableID, eSimCableConID)).fetchone()[0]
                            conn.execute("INSERT INTO PanelCableConJunct (PanelConID, CableConID) VALUES (?,?)", (matchingConnID, panelCableConID))
                            conn.commit()           
        return 0
    
    def connectInstrumentRouting (self, conn, rackID):
        instrumentPanelCableTypeID = conn.execute("SELECT ID FROM eCableTypes WHERE Name == ?", (LRUconstants.HD44_HD44_CABLE_NAME,)).fetchone()[0]
        instrumentDaughterCardTypeID = conn.execute("SELECT ID FROM eSLSCDaughterCardTypes WHERE Model == ?", (LRUconstants.INSTRUMENT_DAUGHTER_CARD_NAME,)).fetchone()[0]
        
        '''Get a list of panel calibration connectors with signals assigned to them for the right signal type and that don't already have a cable'''
        panelList = conn.execute("SELECT ID FROM Panels WHERE RackID = ?", (rackID,)).fetchall()
        panelList = [x[0] for x in panelList]
        connectorsWithSignals = self.getPanelSignalConnectors(conn, panelList, cableCon=True, realOnly=False)
        calConnectors = []
        for signalConnector in connectorsWithSignals:
            '''Find the calConnector opposite the signalConnector'''
            eSignalConnector = conn.execute("SELECT ePanelConnectorID FROM PanelConnectorInformation WHERE ID == ?", (signalConnector,)).fetchone()[0]
            eSignalConnectorBank = conn.execute("SELECT Bank FROM ePanelPins WHERE ePanelConnectorID == ?", (eSignalConnector,)).fetchone()[0]
            eCalConnector = conn.execute("SELECT ePanelConnectorID FROM ePanelPins WHERE Bank == ? AND ePanelConnectorID IS NOT ?", (eSignalConnectorBank, eSignalConnector)).fetchone()[0]
            panelID = conn.execute("SELECT PanelID FROM PanelConnectorInformation WHERE ID == ?", (signalConnector,)).fetchone()[0]
            '''Assume signals on cal connector are either all input or all output'''
            output = conn.execute("SELECT Output FROM SignalsInformation WHERE PanelConID == ?", (signalConnector,)).fetchone()[0]
            calConnector = conn.execute("SELECT ID FROM PanelConnectorInformation WHERE PanelID == ? AND ePanelConnectorID == ?", (panelID, eCalConnector)).fetchone()[0]
            calConnector = (calConnector, output)
            if calConnector not in calConnectors:
                '''Add that connector to a list to assign if its not already there'''
                calConnectors.append(calConnector)
        '''Add PXI hardware if not already present'''
        '''Assign each connectors to a routing card J1/J2. First look for open J2. Then add a new card and assign. Add Cal daughter card.'''
        section = None
        for calConnector in calConnectors:
            '''Only assign connectors that aren't already connected to cables'''
            connected = conn.execute("SELECT ID FROM PanelCableConJunct WHERE PanelConID == ?", (calConnector[0],)).fetchone()
            if connected is None:
                SLSCConID = slsc.check_for_an_open_SLSC_connector(conn, self.calConnIDs, rackID, crossRacks = False)
                if SLSCConID is None:
                    logger.info("Adding new routing card for cal.")
                    if slsc.insert_SLSC_card_into_chassis(conn, self.routingCardTypeID, rackID) < 0:
                        return -1
                    '''Check again with the new routing card but now search for J1 instead because we just added a new card'''
                    SLSCConID = slsc.check_for_an_open_SLSC_connector(conn, self.routingConnIDs, rackID, crossRacks = False)
                    if SLSCConID is None:
                        logger.error("Calibration assignment failed")
                        return -1
                    else:
                        section = 0                    
                else:
                    section = 1
                cableID = cables.add_new_cable(conn, instrumentPanelCableTypeID)
                SLSCCableConID = conn.execute("SELECT ID FROM CableConnectorInformation WHERE ConnectorTypeName == ? AND CableID == ?", ('HD44', cableID)).fetchone()[0]
                conn.execute("INSERT INTO SLSCCableConJunct (SLSCConID, CableConID) VALUES (?,?)", (SLSCConID[0], SLSCCableConID))
                panelCableConID = cables.get_opposite_side_connector(conn, SLSCCableConID, 1)
                conn.execute("INSERT INTO PanelCableConJunct (PanelConID, CableConID) VALUES (?,?)", (calConnector[0], panelCableConID))
                conn.commit()
                '''Check if that section happens to have a daughter card assigned. If not, assign one'''
                daughterCardInfo = conn.execute("SELECT eSLSCDaughterCardTypeID FROM SLSCRoutingDaughterCards WHERE SLSCRoutingCardID == ? AND Section == ?", (SLSCConID[1], section)).fetchone()
                if daughterCardInfo:
                    if daughterCardInfo[0] == instrumentDaughterCardTypeID:
                        logger.error("Routing card already has a daughtercard assigned to that section and cannot be used for instrumentation")
                        return -1
                else:
                    conn.execute("INSERT INTO SLSCRoutingDaughterCards (eSLSCDaughterCardTypeID, SLSCRoutingCardID, Section) VALUES (?,?,?)", (instrumentDaughterCardTypeID, SLSCConID[1], section))
                    conn.commit()
                '''Assign pins to the instrument Bus if they aren't already'''
                '''Get the SLSC chassis ID that the card is in'''
                SLSCCardID = conn.execute("SELECT SLSCCardID FROM SLSCConnectorInformation WHERE ID == ?", (SLSCConID[0],)).fetchone()[0]
                XJ3ConnectorID = conn.execute("SELECT ID FROM SLSCConnectors WHERE SLSCCardID == ? and eSLSCConnectorID == ?", (SLSCCardID, 7)).fetchone()[0]
                SLSCChassisID = conn.execute("SELECT SLSCChassisID FROM SLSCCards WHERE ID == ?", (SLSCCardID,)).fetchone()[0]
                '''Check if there is a bus of the right direction created for that chassis, if not make one'''
                if calConnector[1]:
                    P1BuseID = conn.execute("SELECT ID FROM eBusTypes WHERE Name == ?", ("Instrument Response +",)).fetchone()[0]
                    P1BusPinID = conn.execute("SELECT ID FROM SLSCBusPins WHERE SLSCConnectorID == ? and eSLSCPinID == ?", (XJ3ConnectorID, 474)).fetchone()[0]                
                    P2BuseID = conn.execute("SELECT ID FROM eBusTypes WHERE Name == ?", ("Instrument Response -",)).fetchone()[0]
                    P2BusPinID = conn.execute("SELECT ID FROM SLSCBusPins WHERE SLSCConnectorID == ? and eSLSCPinID == ?", (XJ3ConnectorID, 475)).fetchone()[0]    
                    P3BuseID = conn.execute("SELECT ID FROM eBusTypes WHERE Name == ?", ("Instrument Res Return +",)).fetchone()[0]
                    P3BusPinID = conn.execute("SELECT ID FROM SLSCBusPins WHERE SLSCConnectorID == ? and eSLSCPinID == ?", (XJ3ConnectorID, 476)).fetchone()[0]                      
                    P4BuseID = conn.execute("SELECT ID FROM eBusTypes WHERE Name == ?", ("Instrument Res Return -",)).fetchone()[0]
                    P4BusPinID = conn.execute("SELECT ID FROM SLSCBusPins WHERE SLSCConnectorID == ? and eSLSCPinID == ?", (XJ3ConnectorID, 477)).fetchone()[0]                                          
                else:
                    P1BuseID = conn.execute("SELECT ID FROM eBusTypes WHERE Name == ?", ("Instrument Stimulus +",)).fetchone()[0]
                    P1BusPinID = conn.execute("SELECT ID FROM SLSCBusPins WHERE SLSCConnectorID == ? and eSLSCPinID == ?", (XJ3ConnectorID, 474)).fetchone()[0]                
                    P2BuseID = conn.execute("SELECT ID FROM eBusTypes WHERE Name == ?", ("Instrument Stimulus -",)).fetchone()[0]
                    P2BusPinID = conn.execute("SELECT ID FROM SLSCBusPins WHERE SLSCConnectorID == ? and eSLSCPinID == ?", (XJ3ConnectorID, 475)).fetchone()[0]    
                    P3BuseID = conn.execute("SELECT ID FROM eBusTypes WHERE Name == ?", ("Instrument Stim Return +",)).fetchone()[0]
                    P3BusPinID = conn.execute("SELECT ID FROM SLSCBusPins WHERE SLSCConnectorID == ? and eSLSCPinID == ?", (XJ3ConnectorID, 476)).fetchone()[0]                      
                    P4BuseID = conn.execute("SELECT ID FROM eBusTypes WHERE Name == ?", ("Instrument Stim Return -",)).fetchone()[0]
                    P4BusPinID = conn.execute("SELECT ID FROM SLSCBusPins WHERE SLSCConnectorID == ? and eSLSCPinID == ?", (XJ3ConnectorID, 477)).fetchone()[0]                                    
                P1BusID = conn.execute("SELECT ID FROM Buses WHERE eBusTypeID == ? AND SLSCChassisID == ?", (P1BuseID, SLSCChassisID)).fetchone()
                P2BusID = conn.execute("SELECT ID FROM Buses WHERE eBusTypeID == ? AND SLSCChassisID == ?", (P2BuseID, SLSCChassisID)).fetchone()
                P3BusID = conn.execute("SELECT ID FROM Buses WHERE eBusTypeID == ? AND SLSCChassisID == ?", (P3BuseID, SLSCChassisID)).fetchone()
                P4BusID = conn.execute("SELECT ID FROM Buses WHERE eBusTypeID == ? AND SLSCChassisID == ?", (P4BuseID, SLSCChassisID)).fetchone()                 
                '''Assume if positive exists than negative must too'''
                if P1BusID is None:
                    '''If no bus is found, add a bus and create an entry in the switchmatrixrow table'''
                    rowChannels = conn.execute("SELECT ChannelNumber FROM SwitchMatrixRows").fetchall()
                    largestRowChannel = -1
                    for channel in rowChannels:
                        if channel[0] > largestRowChannel:
                            largestRowChannel = channel[0]
                    '''Add one to the channel to make a new one'''
                    largestRowChannel += 1
                    '''Create the buses and add them to the matrix rows'''
                    P1BusID = conn.execute("INSERT INTO Buses (eBusTypeID, SLSCChassisID) VALUES (?,?)", (P1BuseID, SLSCChassisID)).lastrowid
                    conn.execute("INSERT INTO SwitchMatrixRows (ChannelNumber, Negative, BusID) VALUES (?,?,?)", (largestRowChannel, False, P1BusID))
                    P2BusID = conn.execute("INSERT INTO Buses (eBusTypeID, SLSCChassisID) VALUES (?,?)", (P2BuseID, SLSCChassisID)).lastrowid                    
                    conn.execute("INSERT INTO SwitchMatrixRows (ChannelNumber, Negative, BusID) VALUES (?,?,?)", (largestRowChannel, True, P2BusID))                    
                    largestRowChannel += 1
                    P3BusID = conn.execute("INSERT INTO Buses (eBusTypeID, SLSCChassisID) VALUES (?,?)", (P3BuseID, SLSCChassisID)).lastrowid
                    conn.execute("INSERT INTO SwitchMatrixRows (ChannelNumber, Negative, BusID) VALUES (?,?,?)", (largestRowChannel, False, P3BusID))                    
                    P4BusID = conn.execute("INSERT INTO Buses (eBusTypeID, SLSCChassisID) VALUES (?,?)", (P4BuseID, SLSCChassisID)).lastrowid                    
                    conn.execute("INSERT INTO SwitchMatrixRows (ChannelNumber, Negative, BusID) VALUES (?,?,?)", (largestRowChannel, True, P4BusID))                    
                    conn.commit()
                else:
                    P1BusID = P1BusID[0]
                    P2BusID = P2BusID[0]
                    P3BusID = P3BusID[0]
                    P4BusID = P4BusID[0]
                    conn.commit()                    
                '''Connect pins to the bus using the junction table'''                
                '''Again assume if positive exists than negative does too'''
                test = conn.execute("SELECT ID FROM SLSCBusPinJunct WHERE PinID == ?", (P1BusPinID,)).fetchone()
                if test is None:
                    conn.execute("INSERT INTO SLSCBusPinJunct (BusID, PinID) VALUES (?,?)", (P1BusID, P1BusPinID))
                    conn.execute("INSERT INTO SLSCBusPinJunct (BusID, PinID) VALUES (?,?)", (P2BusID, P2BusPinID))
                    conn.execute("INSERT INTO SLSCBusPinJunct (BusID, PinID) VALUES (?,?)", (P3BusID, P3BusPinID))
                    conn.execute("INSERT INTO SLSCBusPinJunct (BusID, PinID) VALUES (?,?)", (P4BusID, P4BusPinID))
                    conn.commit()                     
        return 0
    
    def addRTIToRoutingAndReturnConnectorIDsWithSignalType(self, conn, XJ2ID, rackID):
        '''Adds an RTI to a routing card and then returns a lit of connectors that have that signal type but that are not connected'''
        '''Assume a 4 bank RTI for this'''
        '''First check if that XJ2ID already has a 4 bank RTI connected'''
        RTIInfo = conn.execute("SELECT ID, eRTITypeID FROM RTIs WHERE SLSCXJ2ID == ?", (XJ2ID,)).fetchone()
        if (RTIInfo):
            if RTIInfo[1] is not self.eRTITypeID:
                logger.error("RTI is already connected but of the wrong type")
                return -1
            else:
                '''RTI was found, get its ID for later use'''
                RTIID = RTIInfo[0]
        else:
            '''No RTI is connected so add and connect one''' 
            RTIID = slsc.connect_RTI(conn, self.eRTITypeID, XJ2ID)
        
        '''Get all connectors for that RTI'''
        RTIConIDs = slsc.get_RTI_Con_IDs_From_RTIID(conn, RTIID)
        
        '''Check which of those connectors carry signals of the specified type'''
        '''If not a routing card, assume all 4 connector banks carry that signal type'''
        '''Figure out if it is a routing card'''
        XJ2IDInfo = conn.execute("SELECT eSLSCConnectorID, SLSCCardID FROM SLSCConnectors WHERE ID == ?", (XJ2ID,)).fetchone()
        '''If it is a routing card or small load card with a 4Bank RTI, figure out which connectors have signals of the right type attached'''
        if ((XJ2IDInfo[0] == 6 or XJ2IDInfo[0] == 26) and self.eRTITypeID == 2):
            '''Routing card. Find specific connectors'''
            if XJ2IDInfo[0] == 6:
                cableConIDs = conn.execute("SELECT DISTINCT CableConID FROM SignalsInformation WHERE SignalType == ? AND Real == ? AND SLSCCardID == ? ORDER BY CableConID", (self.signalType, 0, XJ2IDInfo[1])).fetchall()
            '''Load card. Just return two connectors from RTI'''
            if XJ2IDInfo[0] == 26:
                cableConIDs = conn.execute("SELECT DISTINCT CableConID FROM SignalsInformation WHERE Real == ? AND SLSCCardID == ? ORDER BY CableConID", (0, XJ2IDInfo[1])).fetchall()                
            '''Skipping a complicated lookup to use known id values. ePanelCableConIDs = 33,34,35,36 and eRTIConIDs = 3,4,5,6'''
            '''Create a dictionary for the RTIConIDs'''
            RTIConDict = {}
            for RTIConID in RTIConIDs:
                '''Use the RTI ID to get a list of connector types where no cables have been connected'''
                eRTIConID = conn.execute("SELECT eRTIConnectorTypeID FROM RTIConnectorInformation WHERE ID == ? AND CableConID IS NULL", (RTIConID,)).fetchone()
                if eRTIConID:
                    RTIConDict[eRTIConID[0]] = RTIConID
            '''Now rebuild the IDs to use'''
            RTIConIDs = []
            for cableConID in cableConIDs:
                ePanelCableConID = conn.execute("SELECT DISTINCT eCableConnectorID FROM CableConnectorInformation WHERE ID == ?", (cableConID[0],)).fetchone()[0]
                if ePanelCableConID == 33:
                    eRTIConID = 3
                elif ePanelCableConID == 34:
                    eRTIConID = 4
                elif ePanelCableConID == 35:
                    eRTIConID = 5
                elif ePanelCableConID == 36:
                    eRTIConID = 6
                else:
                    logger.error("Invalid cableconnectorID for routing card")
                    return -1
                RTIConIDs.append(RTIConDict[eRTIConID])
        logger.debug("RTIConIDs to assign %s", RTIConIDs) 
        return RTIConIDs       
    
    def addSignalConditionForRoutingSignals(self, conn, eSLSCCardTypeID, eRTITypeID, rackID, crossRacks, J1Only = False):
        '''Connect a RTI and signal conditioning card of the specified types to the XJ2 on the back of routing cards that match the signal type'''
        routingXJ2s = routing.get_XJ2_from_back_of_routing_for_signal_type(conn, self.signalType, rackID)
        eJ1ID = conn.execute("SELECT ID FROM eSLSCConnectorList WHERE eSLSCCardTypeID == ? AND ConnectorLabel == ?", (eSLSCCardTypeID, 'J1')).fetchone()[0]
        eJ2ID = conn.execute("SELECT ID FROM eSLSCConnectorList WHERE eSLSCCardTypeID == ? AND ConnectorLabel == ?", (eSLSCCardTypeID, 'J2')).fetchone()[0]
        eFourBankCableType = conn.execute("SELECT ID FROM eCableTypes WHERE Name == ?", (LRUconstants.HD44_NANOFIT_CABLE_NAME,)).fetchone()[0]
        if J1Only:
            eSCJ1J2 = [eJ1ID]
        else:
            eSCJ1J2 = [eJ1ID, eJ2ID]   
        '''check which type of RTI to use'''
        if eRTITypeID == 1:
            '''Use the HD44 RTI. This is a one to one connection with signal conditioning connectors'''
            while routingXJ2s:
                connInfo = slsc.check_for_an_open_SLSC_connector(conn, eSCJ1J2, rackID, crossRacks)
                if connInfo:
                    routingXJ2ID = routingXJ2s.pop(0)
                    self.addHD44CableAndConnectXJ2ToJ1J2(conn, routingXJ2ID, connInfo[0])
                else:
                    SLSCCardID = slsc.insert_SLSC_card_into_chassis(conn, eSLSCCardTypeID, rackID)
                    if (SLSCCardID < 0):
                        return SLSCCardID
                    else:
                        '''Assign two routing card RTIs and cables to the front connectors of the SignalConditioning card'''
                        routingXJ2ID = routingXJ2s.pop(0)
                        J1ConID = conn.execute("SELECT ID FROM SLSCConnectorInformation WHERE SLSCCardID == ? AND eSLSCConnectorID == ?", (SLSCCardID, eJ1ID)).fetchone()[0]
                        self.addHD44CableAndConnectXJ2ToJ1J2(conn, routingXJ2ID, J1ConID)
                        if (routingXJ2s and J1Only is not False):
                            routingXJ2ID = routingXJ2s.pop(0)    
                            J2ConID = conn.execute("SELECT ID FROM SLSCConnectorInformation WHERE SLSCCardID == ? AND eSLSCConnectorID == ?", (SLSCCardID, eJ2ID)).fetchone()[0]
                            self.addHD44CableAndConnectXJ2ToJ1J2(conn, routingXJ2ID, J2ConID)
                        logger.info('Added SLSC Card of type %s in rack %s', eSLSCCardTypeID, rackID)
        elif eRTITypeID == 2:
            '''Use a 4 bank RTI. Here we have to get the specific connectors on the RTI and check if a cable is already connected on the signal conditioning side'''
            RTIConIDs = []
            openCableConIDs = []
            while routingXJ2s:
                if RTIConIDs == []:
                    '''Get a list of open connectors on the RTI side'''
                    routingXJ2ID = routingXJ2s[0]
                    '''Get bank connectors on routing card RTI first'''
                    RTIConIDs = self.addRTIToRoutingAndReturnConnectorIDsWithSignalType(conn, routingXJ2ID, rackID)
                '''Get a list of open connectors on the Signal Conditioning side. If there are none, add cables/cards as needed.'''
                '''Check if there are any open cable connector ends already attached to the signal conditioning card'''
                SLSCConIDs = conn.execute("SELECT DISTINCT ID FROM SLSCConnectorInformation WHERE eCardTypeID == ? AND eSLSCConnectorID IN (%s)" % ','.join('?'*len(eSCJ1J2)), ([eSLSCCardTypeID] + eSCJ1J2)).fetchall()
                '''For each SLSC connector, get a list of disconnected cable connectors on the other side'''
                '''Check if there are any cables attached to those SLSC connectors'''
                SLSCCableConIDs = []
                for SLSCConID in SLSCConIDs:
                    SLSCCableConID = conn.execute("SELECT CableConID FROM SLSCCableConJunct WHERE SLSCConID == ?", (SLSCConID[0],)).fetchone()
                    if SLSCCableConID:
                        SLSCCableConIDs.append(SLSCCableConID[0])
                '''For each of those cables, check if there are any open connectors on the other end'''
                for SLSCCableConID in SLSCCableConIDs:
                    conIDs = cables.get_disconnected_opposite_side_connectors(conn, SLSCCableConID)
                    openCableConIDs = openCableConIDs + conIDs
                if openCableConIDs == []:
                    '''If not, check if there are any open connectors on a signal conditioning card without a cable attached'''
                    connInfo = slsc.check_for_an_open_SLSC_connector(conn, eSCJ1J2, rackID, crossRacks)
                    if connInfo is None:      
                        '''If not, add a card and get J1 as an open connector'''
                        SLSCCardID = slsc.insert_SLSC_card_into_chassis(conn, eSLSCCardTypeID, rackID)              
                        #J1ConID = conn.execute("SELECT ID FROM SLSCConnectorInformation WHERE SLSCCardID == ? AND eSLSCConnectorID == ?", (SLSCCardID, eJ1ID)).fetchone()[0]             
                        connInfo = slsc.check_for_an_open_SLSC_connector(conn, eSCJ1J2, rackID, crossRacks)
                    '''Connect a cable to that connector'''
                    cableID = cables.add_new_cable(conn, eFourBankCableType)
                    SLSCHD44CableConID = conn.execute("SELECT ID FROM CableConnectorInformation WHERE ConnectorTypeName == ? AND CableID == ?", ('HD44', cableID)).fetchone()[0]
                    conn.execute("INSERT INTO SLSCCableConJunct (SLSCConID, CableConID) VALUES (?,?)", (connInfo[0], SLSCHD44CableConID)) 
                    openCableConIDs = cables.get_disconnected_opposite_side_connectors(conn, SLSCHD44CableConID)
                while RTIConIDs:
                    '''Connect cables to the Nanofit side so long as there are connectors left'''
                    if openCableConIDs == []:
                        break
                    else:
                        RTIConID = RTIConIDs.pop(0)
                        cableConID = openCableConIDs.pop(0)
                        conn.execute("INSERT INTO RTICableConJunct (RTIConID, CableConID) VALUES (?,?)", (RTIConID, cableConID))
                if RTIConIDs == []:
                    '''All connectors on that RTI have been assigned. Remove the XJ2 connector on that SLSC card from the list'''
                    routingXJ2s.pop(0)
         
                conn.commit()
        else:
            logger.error("RTI Type not supported")
            return -1
        return 0
    
    def addHD44CableAndConnectXJ2ToJ1J2(self, conn, XJ2ID, JID):
        eRTITypeID = conn.execute("SELECT ID FROM eRTITypes WHERE Name == ?", ("HD44",)).fetchone()[0]
        eHD44ToHD44CableType = conn.execute("SELECT ID FROM eCableTypes WHERE Name == ?", ("HD44<->HD44",)).fetchone()[0]
        RTIID = slsc.connect_RTI(conn, eRTITypeID, XJ2ID)
        if RTIID < 0:
            return RTIID
        '''Assume only one ID is returned'''
        RTIConID = slsc.get_RTI_Con_IDs_From_RTIID(conn, RTIID)
        cableID = cables.add_new_cable(conn, eHD44ToHD44CableType)
        '''Connect cable to routing card RTI first'''
        SLSCRTICableConID = conn.execute("SELECT ID FROM CableConnectorInformation WHERE ConnectorTypeName == ? AND CableID == ?", ('HD44', cableID)).fetchone()[0]
        conn.execute("INSERT INTO RTICableConJunct (RTIConID, CableConID) VALUES (?,?)", (RTIConID[0], SLSCRTICableConID))
        '''Connect to the first HD44 connectors on the vDT card'''
        SLSCHD44CableConID = conn.execute("SELECT ID FROM CableConnectorInformation WHERE CableID == ? AND ID IS NOT ?", (cableID, SLSCRTICableConID)).fetchone()[0]               
        conn.execute("INSERT INTO SLSCCableConJunct (SLSCConID, CableConID) VALUES (?,?)", (JID, SLSCHD44CableConID))                    
        conn.commit()          
    
    def assignToHW(self, conn, rackID, crossRacks):
        pass

class NOOP (SignalAssignment):
    '''Placeholder algorithm useful for disabling a signal type'''
    def __init__(self, conn, signalType):
        pass
    def assignToPanel(self, conn, sortedPanelConnectors, signalListTuple):
        return sortedPanelConnectors

    def connectRouting(self, conn, rackID):
        return 0
    
    def connectPanelForRealSignals(self, conn, rackID, DUTConRackAssignment):
        return 0

    def connectInstrumentRouting (self, conn, rackID):
        return 0
    
    def assignToHW(self, conn, rackID, crossRacks):
        return 0   

class PanelAssignmentOnly(SignalAssignment):
    '''Use this to take up space on panel connectors and routing cards without assigning any other associated hardware'''
    def __init__(self, conn, signalType):
        '''Use the constructor of the parent class'''
        super(PanelAssignmentOnly,self).__init__(conn, signalType)


class DirectRTIToPXI(SignalAssignment):
    '''Class for assigning all types of signals requiring cable connections between a RTI and a PXI card connector.'''
    def __init__(self, conn, signalType):
        super(DirectRTIToPXI,self).__init__(conn, signalType)        
        PXICardModels = conn.execute("SELECT ID, Model FROM ePXIInsertTypes").fetchall()
        self.output = conn.execute("SELECT Output FROM eSignalTypes WHERE Name == ?", (self.signalType,)).fetchone()[0]
        '''Create a list of card types and banks supported'''
        self.signalType = signalType
        self.modelBanks = {}
        self.largestCardeID = -1
        self.eRTITypeID = conn.execute("SELECT ID FROM eRTITypes WHERE Name == ?", ("4Bank",)).fetchone()[0]
        self.eAccessoryID = -1
        if self.signalType == LRUconstants.DIO_DAQ_NAME:
            self.cableTypeID = conn.execute("SELECT ID FROM eCableTypes WHERE Name == ?", (LRUconstants.HUNDREDPIN_12NANOFIT_CABLE_NAME,)).fetchone()[0]
            self.PXISideCableConName = "100Pin"           
        elif self.signalType == LRUconstants.AI_10V_NAME:
            self.cableTypeID = conn.execute("SELECT ID FROM eCableTypes WHERE Name == ?", (LRUconstants.AO_VHDCI_NANOFIT_CABLE_NAME,)).fetchone()[0]
            self.PXISideCableConName = "VHDCI"
        elif self.signalType == LRUconstants.AO_10V_NAME:
            self.cableTypeID = conn.execute("SELECT ID FROM eCableTypes WHERE Name == ?", (LRUconstants.AI_VHDCI_NANOFIT_CABLE_NAME,)).fetchone()[0]
            self.PXISideCableConName = "VHDCI"            
        elif self.signalType == LRUconstants.AO_THERMOCOUPLE_NAME:
            self.cableTypeID = conn.execute("SELECT ID FROM eCableTypes WHERE Name == ?", (LRUconstants.AI_THERMOCOUPLE_CABLE_NAME,)).fetchone()[0]
            self.PXISideCableConName = "3Column96Pin"  
            self.eAccessoryID = conn.execute("SELECT ID FROM eAccessories WHERE Name == ?", ("TB-4353",)).fetchone()[0]  
        elif self.signalType == LRUconstants.AO_30V_NAME or self.signalType == LRUconstants.AO_60V_NAME:
            self.cableTypeID = conn.execute("SELECT ID FROM eCableTypes WHERE Name == ?", (LRUconstants.AI30V_CABLE_NAME,)).fetchone()[0]
            self.PXISideCableConName = "3Column96Pin"  
            self.eAccessoryID = conn.execute("SELECT ID FROM eAccessories WHERE Name == ?", ("TB-4300B",)).fetchone()[0] 
        elif self.signalType == LRUconstants.A0_20mA_NAME or self.signalType == LRUconstants.A0_XmA_NAME:
            self.cableTypeID = conn.execute("SELECT ID FROM eCableTypes WHERE Name == ?", (LRUconstants.AO20mA_CABLE_NAME,)).fetchone()[0]
            self.PXISideCableConName = "3Column96Pin"  
            self.eAccessoryID = conn.execute("SELECT ID FROM eAccessories WHERE Name == ?", ("TB-4300C",)).fetchone()[0]
            if self.signalType == LRUconstants.A0_XmA_NAME:
                logger.info("TODO: Add precision resitors to BOM for handling custom current measurement for '%s' signals.", LRUconstants.A0_XmA_NAME)           
        else:
            logger.error("Signal type not supported by this class.")
        '''Select a PXI card that supports the most banks of the specified signal type. It can be replaced with a smaller card later if there are unused connectors.'''
        for model in PXICardModels:
            banksOnCard = conn.execute("SELECT count(DISTINCT Bank) FROM ePXIPins WHERE ePinTypeID IN (SELECT ePinTypeID FROM ePinSignalTypeJunct WHERE SignalType == ?) AND ePXIConnectorID IN (SELECT ePXIConnectorID FROM ePXIConnectorInformation WHERE ePXIInsertTypeID == ?)", (signalType, model[0])).fetchone()[0] 
            if banksOnCard:
                self.modelBanks[model[0]] = banksOnCard
                if self.largestCardeID == -1:
                    self.largestCardeID = model[0]
                elif banksOnCard > self.modelBanks[self.largestCardeID]:
                    self.largestCardeID = model[0]              
        logger.debug("Init for signal type %s using largest card eID %s", signalType, self.largestCardeID)
    
    def connectToXJ2(self, conn, XJ2ID, rackID, crossRacks):
        '''Reusable function for assigning an RTI and cable between an XJ2 connector ID and the best PXI card match for this class's signal type'''
        RTIConIDs = self.addRTIToRoutingAndReturnConnectorIDsWithSignalType(conn, XJ2ID, rackID)
        RTISideCableConIDs = pxi.check_for_open_cable_connectors(conn, self.largestCardeID, rackID, crossRacks, self.cableTypeID)
        
        '''While there are still 4bank connectors to connect on the RTI, if no available connectors are found add a new cable or add a new card and cable, otherwise assign to open connectors'''
        while RTIConIDs:
            if RTISideCableConIDs == []:
                PXIConID = pxi.check_for_open_PXI_connector(conn, self.largestCardeID, rackID, crossRacks)
                if PXIConID is None:
                    newCardID = pxi.add_PXI_insert(conn, self.largestCardeID, rackID)
                    if (newCardID == -1):
                        return -1
                    if self.eAccessoryID > -1:
                        conn.execute("INSERT INTO Accessories (eAccessoryTypeID, RackID) VALUES (?,?)", (self.eAccessoryID, rackID))
                        conn.commit()                    
                    PXIConID = pxi.check_for_open_PXI_connector(conn, self.largestCardeID, rackID, crossRacks)   
                else:
                    logger.debug("Found open PXI connector")
                cableID = cables.add_new_cable(conn, self.cableTypeID)
                PXICableConID = conn.execute("SELECT ID FROM CableConnectorInformation WHERE ConnectorTypeName == ? AND CableID == ?", (self.PXISideCableConName, cableID)).fetchone()[0]
                conn.execute("INSERT INTO PXICableConJunct (PXIConID, CableConID) VALUES (?,?)", (PXIConID, PXICableConID))
                RTISideCableConIDs = conn.execute("SELECT ID FROM CableConnectorInformation WHERE ConnectorTypeName == ? AND CableID == ?", ('NanoFit', cableID)).fetchall()
                RTISideCableConIDs = [x[0] for x in RTISideCableConIDs]
            conn.execute("INSERT INTO RTICableConJunct (RTIConID, CableConID) VALUES (?,?)", (RTIConIDs[0], RTISideCableConIDs[0]))
            RTIConIDs.pop(0)
            RTISideCableConIDs.pop(0)
            conn.commit()
        else:
            return 0
    
    def assignToHW(self, conn, rackID, crossRacks):
        XJ2s = routing.get_XJ2_from_back_of_routing_for_signal_type(conn, self.signalType, rackID)                          
        while XJ2s:
            '''for each connector, check for existing cards with open connectors, if none, try to upgrade, if can't then add smallest, then connect'''
            XJ2ID = XJ2s.pop(0)  
            PXIConID = self.connectToXJ2(conn, XJ2ID, rackID, crossRacks)
            if PXIConID < 0:
                return PXIConID
            if XJ2s:
                XJ2ID = XJ2s.pop(0)  
                PXIConID = self.connectToXJ2(conn, XJ2ID, rackID, crossRacks)
                if PXIConID < 0:
                    return PXIConID               
        return 0

class SPI(SignalAssignment):
    '''SPI signals to PXI from XJ2'''
    def __init__(self, conn, signalType):
        '''First call the parent init function'''
        super(SPI,self).__init__(conn, signalType)
        self.eRTITypeID = conn.execute("SELECT ID FROM eRTITypes WHERE Name == ?", ("VHDCI",)).fetchone()[0]
        self.ePXICardTypeID = conn.execute("SELECT ID FROM ePXIInsertTypes WHERE Model == ?", ("PXIe-7821R", )).fetchone()[0]
        self.eCableTypeID = conn.execute("SELECT ID FROM eCableTypes WHERE Name == ?", ("VHDCI<->VHDCI RDIO",)).fetchone()[0]          
    
    def connectToXJ2 (self, conn, XJ2ID, rackID, crossRacks):
        '''Reusable function for assigning a single cable between an RTI and the best PXI card match for this class's signal type'''
        RTIID = slsc.connect_RTI(conn, self.eRTITypeID, XJ2ID)
        '''Only one of the 2 VHDC Connectors on the RTI is usable'''
        RTIConID = conn.execute("SELECT ID FROM RTIConnectorInformation WHERE RTIID == ? AND eRTIConnectorTypeID == ?", (RTIID, 2)).fetchone()[0]
        '''TODO support multiple card models'''
            #===================================================================
            # models = self.modelBanks.keys()    
            # for model in models:
            #     openPXIConnectorID = pxi.check_for_open_PXI_connector(conn, model, rackID, crossRacks)
            #     if openPXIConnectorID:
            #         break
            #===================================================================
        
        openPXIConnectorID = pxi.check_for_open_PXI_connector(conn, self.ePXICardTypeID, rackID, crossRacks)
        if (openPXIConnectorID is None):
            newCardID = pxi.add_PXI_insert(conn, self.ePXICardTypeID, rackID)
            if (newCardID == -1):
                return -1
            openPXIConnectorID = pxi.check_for_open_PXI_connector(conn, self.ePXICardTypeID, rackID, crossRacks)

        cableID = cables.add_new_cable(conn, self.eCableTypeID)
        SLSCRTICableConID = conn.execute("SELECT ID FROM CableConnectorInformation WHERE ConnectorTypeName == ? AND CableID == ?", ('VHDCI', cableID)).fetchone()[0]
        conn.execute("INSERT INTO RTICableConJunct (RTIConID, CableConID) VALUES (?,?)", (RTIConID, SLSCRTICableConID))
        PXICableConID = conn.execute("SELECT ID FROM CableConnectorInformation WHERE CableID == ? AND ID IS NOT ?", (cableID, SLSCRTICableConID)).fetchone()[0]
        conn.execute("INSERT INTO PXICableConJunct (PXIConID, CableConID) VALUES (?,?)", (openPXIConnectorID, PXICableConID))
        conn.commit()
        return 0

class DO(SignalAssignment):
    '''Catchall for any DO signals going through an SLSC card (excluding discrete inputs)'''
    def __init__(self, conn, signalType):
        super(DO,self).__init__(conn, signalType)
        self.DIOSLSCCard = conn.execute("SELECT ID FROM eSLSCCardTypes WHERE Model == ?", ("SLSC-12201",)).fetchone()[0]
        self.eJ1ID = conn.execute("SELECT ID FROM eSLSCConnectorList WHERE eSLSCCardTypeID == ? AND ConnectorLabel == ?", (self.DIOSLSCCard, 'J1')).fetchone()[0]
        self.eJ2ID = conn.execute("SELECT ID FROM eSLSCConnectorList WHERE eSLSCCardTypeID == ? AND ConnectorLabel == ?", (self.DIOSLSCCard, 'J2')).fetchone()[0]
        self.eXJ2ID = conn.execute("SELECT ID FROM eSLSCConnectorList WHERE eSLSCCardTypeID == ? AND ConnectorLabel == ?", (self.DIOSLSCCard, 'XJ2')).fetchone()[0]
        self.dioJ1J2 = [self.eJ1ID, self.eJ2ID]
        self.eRTITypeID = conn.execute("SELECT ID FROM eRTITypes WHERE Model == ?", (LRUconstants.FOURBANK_RTI_MODEL,)).fetchone()[0]    
        self.eCableTypeID = conn.execute("SELECT ID FROM eCableTypes WHERE Name == ?", (LRUconstants.HD44_DB9_CABLE_NAME,)).fetchone()[0]
        self.DIOCard = SPI(conn, LRUconstants.DIO_DAQ_NAME)
            
    def connectRouting(self, conn, rackID):
        '''DOs only need a routing card for Real/Sim'''
        real = conn.execute("SELECT ID FROM SignalsInformation WHERE RackID == ? AND DUTConnector IS NOT NULL", (rackID,)).fetchall()
        if real:
            print("TODO Assign Routing if using real signals for DO")
            #super(DO, self).connectRouting(conn, rackID)
        return 0
    
    def assignToHW(self, conn, rackID, crossRacks):
        #=======================================================================
        # SignalAssignment.assignToHW(self, conn, rackID, crossRacks)
        # error = DOO.addSignalConditionForRoutingSignals(self, conn, self.DIOPXICard, self.eRTITypeID, rackID, crossRacks)
        #=======================================================================
        panelIDsInRack = conn.execute("SELECT ID FROM Panels WHERE RackID = ?", (rackID,)).fetchall()
        panelList = [x[0] for x in panelIDsInRack]
        simConnIDs = self.getPanelSignalConnectors(conn, panelList, cableCon=None, realOnly=False)        
        while simConnIDs:
            SLSCConID = slsc.check_for_an_open_SLSC_connector(conn, self.dioJ1J2, rackID, crossRacks)
            if SLSCConID is None:            
                '''add a card, connect to J1, pop panel connector'''
                DOCardID = slsc.insert_SLSC_card_into_chassis(conn, self.DIOSLSCCard, rackID)
                SLSCConID = slsc.check_for_an_open_SLSC_connector(conn, self.dioJ1J2, rackID, crossRacks)
                if SLSCConID is None:
                    logger.debug("Failed to add DO card to SLSC Chassis")
                    return -1
            '''For each sim connector, add load card an connect the top two DB9s. If there is a real, connect the corresponing bottom DB9'''
            cableID = cables.add_new_cable(conn, self.eCableTypeID)
            '''Attach the SLSC end of the cable.'''
            SLSCCableConID = conn.execute("SELECT ID FROM CableConnectorInformation WHERE ConnectorTypeName == ? AND CableID == ?", ('HD44', cableID)).fetchone()[0]
            conn.execute("INSERT INTO SLSCCableConJunct (SLSCConID, CableConID) VALUES (?,?)", (SLSCConID[0], SLSCCableConID))             
            '''Attach the panel sides'''
            panelCableConIDs = conn.execute("SELECT ID FROM CableConnectorInformation WHERE ConnectorTypeName IS NOT ? AND CableID == ?", ('HD44', cableID)).fetchall()
            for panelCableConID in panelCableConIDs:
                if simConnIDs:
                    simConID = simConnIDs.pop(0)
                    conn.execute("INSERT INTO PanelCableConJunct (PanelConID, CableConID) VALUES (?,?)", (simConID, panelCableConID[0]))
            conn.commit()            
        '''Connect to PXI.'''
        doXJ2IDs = conn.execute("SELECT ID FROM SLSCConnectorInformation WHERE eSLSCConnectorID == ? AND eCardTypeID  == ? AND RackID == ?", (self.eXJ2ID, self.DIOSLSCCard, rackID)).fetchall()              
        for doXJ2ID in doXJ2IDs:
            '''Check if the card has already been connected'''
            if not conn.execute("SELECT ID FROM RTIs WHERE SLSCXJ2ID == ?", (doXJ2ID[0],)).fetchone():
                error = self.DIOCard.connectToXJ2(conn, doXJ2ID[0], rackID, crossRacks)
                if error < 0:
                    return error            
        return 0
     
class VDT(SignalAssignment):
    '''VDT simulation from the perspective of the DUT'''
    def __init__(self, conn, signalType):
        '''First call the parent init function'''
        super(VDT,self).__init__(conn, signalType)
        self.eRTITypeID = conn.execute("SELECT ID FROM eRTITypes WHERE Model == ?", (LRUconstants.FOURBANK_RTI_MODEL,)).fetchone()[0]
        if (self.signalType == LRUconstants.FOUR_WIRE_IVDT_NAME or self.signalType == LRUconstants.SIX_WIRE_IVDT_NAME):        
            self.AOCard = DirectRTIToPXI(conn, LRUconstants.AI_10V_NAME)
            self.cardTypeID = conn.execute("SELECT ID FROM eSLSCCardTypes WHERE Model == ?", ("8 Channel VDT/Resolver", )).fetchone()[0]
            self.eJ1ID = conn.execute("SELECT ID FROM eSLSCConnectorList WHERE eSLSCCardTypeID == ? AND ConnectorLabel == ?", (self.cardTypeID, 'J1')).fetchone()[0]
            self.eJ2ID = conn.execute("SELECT ID FROM eSLSCConnectorList WHERE eSLSCCardTypeID == ? AND ConnectorLabel == ?", (self.cardTypeID, 'J2')).fetchone()[0]
            self.eXJ2ID = conn.execute("SELECT ID FROM eSLSCConnectorList WHERE eSLSCCardTypeID == ? AND ConnectorLabel == ?", (self.cardTypeID, 'XJ2')).fetchone()[0]
            self.vdtJ1J2 = [self.eJ1ID, self.eJ2ID]

        elif (self.signalType == LRUconstants.SIX_WIRE_OVDT_NAME):
            self.pxiCardType = conn.execute("SELECT ID FROM ePXIInsertTypes WHERE Model == ?", ("PXIe-4340",)).fetchone()[0]
            self.cableType = conn.execute("SELECT ID FROM eCableTypes WHERE Name == ?", ("VDT<->4NanoFit",)).fetchone()[0]
            self.TB4340Type = conn.execute("SELECT ID FROM eAccessories WHERE Name == ?", ('TB-4340',)).fetchone()[0]
    
    def assignToPanel(self, conn, inputPanelConnectors, signalListTuple, commit=True):
        if (self.signalType == LRUconstants.FOUR_WIRE_IVDT_NAME):        
            '''Find how many of those signals fit into a Bank'''
            signalsPerBank = 2
        
        elif (self.signalType == LRUconstants.SIX_WIRE_IVDT_NAME or self.signalType == LRUconstants.SIX_WIRE_OVDT_NAME):
            signalsPerBank = 1
           
        if not inputPanelConnectors:
            return -1
        '''Only use connectors with no signals assigned'''
        signalDirection = conn.execute("SELECT Output FROM eSignalTypes WHERE Name == ?", (self.signalType,)).fetchone()[0]
        panelID = conn.execute("SELECT PanelID FROM PanelConnectors WHERE ID == ?", (inputPanelConnectors[0],)).fetchone()[0]
        compatiblePanelConnectors = panels.get_unassigned_connectors_with_direction(conn, panelID, signalDirection)
        assignablePanelConnectors = []
        for connector in compatiblePanelConnectors:
            if connector in inputPanelConnectors:
                assignablePanelConnectors.append(connector)
                
        '''Assign signals to panel connectors'''
        while (len(signalListTuple)):
            if (len(assignablePanelConnectors) == 0):
                '''Return -1 if no connectors left to assign to'''
                return -1
            selectedCon = assignablePanelConnectors.pop(0)
            inputPanelConnectors.remove(selectedCon)

            '''Get number of banks that connector supports'''
            banksOnCon = 1
            
            '''Assign the signals, this is legacy code from when there were DB25 connectors on the panels'''              
            bank = 0
            signalInBank = 0
            while bank < banksOnCon:
                if signalListTuple:
                    signalToAssign = signalListTuple.pop(0)[0]
                    if commit:
                        conn.execute("INSERT INTO SignalPanelConJunct (SignalID, PanelConID, Real) VALUES (?,?,?)", (signalToAssign,selectedCon,False))                        
                    if self.signalType == LRUconstants.FOUR_WIRE_IVDT_NAME:
                        '''4-wire VDTs share excitation signals on the panel'''
                        if signalInBank == 0:
                            bankPins = [1, 2, 7, 8]
                            for bankPin in bankPins:
                                if commit:
                                    conn.execute("INSERT INTO SignalPanelPinJunct (SignalID, PanelConID, ConnectorBank, BankPin) VALUES (?,?,?,?)", (signalToAssign,selectedCon, bank, bankPin))
                            signalInBank = 1
                        elif signalInBank == 1:
                            bankPins = [3, 4, 7, 8]
                            for bankPin in bankPins:
                                if commit:
                                    conn.execute("INSERT INTO SignalPanelPinJunct (SignalID, PanelConID, ConnectorBank, BankPin) VALUES (?,?,?,?)", (signalToAssign,selectedCon, bank, bankPin))
                            signalInBank = 0
                            bank += 1 
                    elif self.signalType == LRUconstants.SIX_WIRE_IVDT_NAME or self.signalType == LRUconstants.SIX_WIRE_OVDT_NAME:
                        bankPins = [1,2,3,4,7,8]
                        for bankPin in bankPins:
                            if commit:
                                conn.execute("INSERT INTO SignalPanelPinJunct (SignalID, PanelConID, ConnectorBank, BankPin) VALUES (?,?,?,?)", (signalToAssign,selectedCon, bank, bankPin))                      
                        bank += 1                 
                else:
                    break                 
            if commit:
                conn.commit()
        '''Return the original list minus those that were assigned'''
        return inputPanelConnectors
            
    def assignToHW(self, conn, rackID, crossRacks):
        '''Assign the back of the routing cards to the front of the signal conditioning cards'''
        if (self.signalType == LRUconstants.FOUR_WIRE_IVDT_NAME or self.signalType == LRUconstants.SIX_WIRE_IVDT_NAME):
            error = VDT.addSignalConditionForRoutingSignals(self, conn, self.cardTypeID, self.eRTITypeID, rackID, crossRacks)
            if error < 0:
                return error
            else:  
                vdtXJ2IDs = conn.execute("SELECT ID FROM SLSCConnectorInformation WHERE eSLSCConnectorID == ? AND eCardTypeID  == ? AND RackID == ?", (self.eXJ2ID, self.cardTypeID, rackID)).fetchall()              
                for vdtXJ2ID in vdtXJ2IDs:
                    error = self.AOCard.connectToXJ2(conn, vdtXJ2ID[0], rackID, crossRacks)
                    if error < 0:
                        return error
        elif (self.signalType == LRUconstants.SIX_WIRE_OVDT_NAME):
            '''Find every connector with signals assigned for every panel in that rack'''    
            XJ2s = routing.get_XJ2_from_back_of_routing_for_signal_type(conn, self.signalType, rackID)                          
            while XJ2s:
                XJ2ID = XJ2s.pop(0)
                RTIConIDs = self.addRTIToRoutingAndReturnConnectorIDsWithSignalType(conn, XJ2ID, rackID)                         
                while RTIConIDs: 
                    PXIcon = pxi.check_for_open_PXI_connector(conn, self.pxiCardType, rackID, crossRacks)
                    if PXIcon is None:                    
                        '''Add a card and the terminal block accessory'''
                        pxi.add_PXI_insert(conn, self.pxiCardType, rackID)
                        conn.execute("INSERT INTO Accessories (eAccessoryTypeID, RackID) VALUES (?, ?)",(self.TB4340Type, rackID))
                        conn.commit()
                        PXIcon = pxi.check_for_open_PXI_connector(conn, self.pxiCardType, rackID, crossRacks)
                    cableID = cables.add_new_cable(conn, self.cableType)
                    PXICableCon = conn.execute("SELECT ID FROM CableConnectorInformation WHERE CableID == ? AND eEndTypeID == ?", (cableID, 1)).fetchone()[0]
                    conn.execute("INSERT INTO PXICableConJunct (PXIConID, CableConID) VALUES (?,?)", (PXIcon, PXICableCon))
                    nanofitIDs = cables.get_disconnected_opposite_side_connectors(conn, PXICableCon)
                    for nanofitID in nanofitIDs:
                        if RTIConIDs:
                            RTIConID = RTIConIDs.pop(0)
                            conn.execute("INSERT INTO RTICableConJunct (RTIConID, CableConID) VALUES (?,?)", (RTIConID, nanofitID))
                    conn.commit()
        return 0

class DiscreteInputs(SignalAssignment):
    def __init__(self, conn, signalType):
        '''First call the parent init function'''
        super(DiscreteInputs,self).__init__(conn, signalType)
        self.cardTypeID = conn.execute("SELECT ID FROM eSLSCCardTypes WHERE Model == ?", ("Low Power Signal Routing", )).fetchone()[0]
        self.eJ1ID = conn.execute("SELECT ID FROM eSLSCConnectorList WHERE eSLSCCardTypeID == ? AND ConnectorLabel == ?", (self.cardTypeID, 'J1')).fetchone()[0]
        self.eJ2ID = conn.execute("SELECT ID FROM eSLSCConnectorList WHERE eSLSCCardTypeID == ? AND ConnectorLabel == ?", (self.cardTypeID, 'J2')).fetchone()[0]
        self.routingConnIDs = [self.eJ1ID, self.eJ2ID]
    
    def connectRouting(self, conn, rackID):
        '''Call the parent version of the routing, but use J1 and J2 as open connectors if possible'''
        '''Assume Discretes are called last for this to work'''
        super(DiscreteInputs, self).connectRouting(conn, rackID)
        logger.debug("Discrete HW assignment complete.")
        return 0
        
    def assignToHW(self, conn, rackID, crossRacks):
        '''For discretes the HW is already connected during routing. All that is required is to add the fault card to each of the routing cards used'''
        routingXJ2IDs = routing.get_XJ2_from_back_of_routing_for_signal_type(conn, self.signalType, rackID)
        for routingXJ2ID in routingXJ2IDs:
            SLSCCardIDs = conn.execute("SELECT SLSCCardID FROM SLSCConnectors WHERE ID == ?", (routingXJ2ID,)).fetchall()
            for SLSCCardID in SLSCCardIDs:
                routing.add_daughter_card_to_section(conn, SLSCCardID[0], eDaughterCardTypeID=1, section= 0)               
        logger.debug("HW assignment complete at routing for discretes")
        return 0

class SignalConditionedDigital (SignalAssignment):
    def __init__(self, conn, signalType):
        '''First call the parent init function'''
        super(SignalConditionedDigital,self).__init__(conn, signalType)
        self.SPI = SPI(conn, LRUconstants.SPI_NAME)
        if signalType == LRUconstants.ARINC_429_RX_NAME or signalType == LRUconstants.ARINC_429_TX_NAME:
            self.cardTypeID = conn.execute("SELECT ID FROM eSLSCCardTypes WHERE Model == ?", ("ARINC 429 32 Channel", )).fetchone()[0]
        elif signalType == LRUconstants.PWM_INPUT_32V_FPGA or signalType == LRUconstants.PWM_INPUT_32V:
            self.cardTypeID = conn.execute("SELECT ID FROM eSLSCCardTypes WHERE Model == ?", ("SLSC-12201",)).fetchone()[0]
        elif signalType == LRUconstants.ONE_WATT_RES_NAME:
            self.cardTypeID = conn.execute("SELECT ID FROM eSLSCCardTypes WHERE Model == ?", ("Resistor Simulator",)).fetchone()[0]
        self.eRTITypeID = conn.execute("SELECT ID FROM eRTITypes WHERE Model == ?", (LRUconstants.FOURBANK_RTI_MODEL,)).fetchone()[0]
        self.eJ1ID = conn.execute("SELECT ID FROM eSLSCConnectorList WHERE eSLSCCardTypeID == ? AND ConnectorLabel == ?", (self.cardTypeID, 'J1')).fetchone()[0]
        self.eJ2ID = conn.execute("SELECT ID FROM eSLSCConnectorList WHERE eSLSCCardTypeID == ? AND ConnectorLabel == ?", (self.cardTypeID, 'J2')).fetchone()[0]
        self.eXJ2ID = conn.execute("SELECT ID FROM eSLSCConnectorList WHERE eSLSCCardTypeID == ? AND ConnectorLabel == ?", (self.cardTypeID, 'XJ2')).fetchone()[0]
        self.arincJ1J2 = [self.eJ1ID, self.eJ2ID]
        #self.eFrontCableTypeID = conn.execute("SELECT ID FROM eCableTypes WHERE Name == ?", ("HD44<->HD44",)).fetchone()[0]
    
    def assignToHW(self, conn, rackID, crossRacks):        
        error = self.addSignalConditionForRoutingSignals(conn, self.cardTypeID, self.eRTITypeID, rackID, crossRacks)
        if error < 0:
            return error
        else:
            SCXJ2IDs = conn.execute("SELECT ID FROM SLSCConnectorInformation WHERE eSLSCConnectorID == ? AND eCardTypeID  == ? AND RackID == ? AND eRTITypeID is NULL", (self.eXJ2ID, self.cardTypeID, rackID)).fetchall()
            for SCXJ2ID in SCXJ2IDs:             
                self.SPI.connectToXJ2(conn, SCXJ2ID[0], rackID, crossRacks) 
        
class Serial(SignalAssignment):
    def __init__(self, conn, signalType):
        '''First call the parent init function'''
        super(Serial,self).__init__(conn, signalType)
        self.eCardTypeID = conn.execute("SELECT ID FROM ePXIInsertTypes WHERE Model == ?", ("PXI-8433/4",)).fetchone()[0]
        self.eCableTypeID = conn.execute("SELECT ID FROM eCableTypes WHERE Name == ?", ("NanoFit<->10P10C",)).fetchone()[0]
        self.eRTITypeID = conn.execute("SELECT ID FROM eRTITypes WHERE Model == ?", ("RTI-12303",)).fetchone()[0]
    
    def assignToHW(self, conn, rackID, crossRacks):
        routingXJ2IDs = routing.get_XJ2_from_back_of_routing_for_signal_type(conn, self.signalType, rackID)        
        for routingXJ2ID in routingXJ2IDs:
            RTIConIDs = self.addRTIToRoutingAndReturnConnectorIDsWithSignalType(conn, routingXJ2ID, rackID)
            for RTIConID in RTIConIDs:
                cableID = cables.add_new_cable(conn, self.eCableTypeID)
                '''Connect cable to routing card RTI Con first'''
                SLSCRTICableConID = conn.execute("SELECT ID FROM CableConnectorInformation WHERE ConnectorTypeName == ? AND CableID == ?", ('NanoFit', cableID)).fetchone()[0]
                conn.execute("INSERT INTO RTICableConJunct (RTIConID, CableConID) VALUES (?,?)", (RTIConID, SLSCRTICableConID))
                '''Connect to an open connector on the PXI card'''
                #===============================================================
                # models = self.modelBanks.keys()    
                # for model in models:
                #===============================================================
                openPXIConnectorID = pxi.check_for_open_PXI_connector(conn, self.eCardTypeID, rackID, crossRacks)
                
                if (openPXIConnectorID is None):
                    newCardID = pxi.add_PXI_insert(conn, self.eCardTypeID, rackID)
                    if (newCardID == -1):
                        return -1
                    openPXIConnectorID = pxi.check_for_open_PXI_connector(conn, self.eCardTypeID, rackID, crossRacks)               
                P10CCableConID = conn.execute("SELECT ID FROM CableConnectorInformation WHERE CableID == ? AND ID IS NOT ?", (cableID, SLSCRTICableConID)).fetchone()[0]               
                conn.execute("INSERT INTO PXICableConJunct (PXIConID, CableConID) VALUES (?,?)", (openPXIConnectorID, P10CCableConID))                    
                conn.commit()   

class AI16V(SignalAssignment):
    '''TODO revisit this with a better cabling strategy. Currently works for 16V, but not 32V. Combination 32 and 16 would also be really tough to support'''
    def __init__(self, conn, signalType):
        '''First call the parent init function'''
        super(AI16V,self).__init__(conn, signalType)
        self.eCardTypeID = conn.execute("SELECT ID FROM ePXIInsertTypes WHERE Model == ?", ("PXIe-4322",)).fetchone()[0]
        self.eCableTypeID = conn.execute("SELECT ID FROM eCableTypes WHERE Name == ?", ("NanoFit<->16V Breakout",)).fetchone()[0]
        self.eWireTypeID = conn.execute("SELECT ID FROM eCableTypes WHERE Name == ?", ("16V Wire",)).fetchone()[0]
        self.eRTITypeID = conn.execute("SELECT ID FROM eRTITypes WHERE Model == ?", ("RTI-12303",)).fetchone()[0]
        if self.signalType == LRUconstants.AI_16V_NAME or self.signalType == LRUconstants.AI_20mA_NAME:
            self.numChannels = 1
        elif self.signalType == LRUconstants.AI_32V_NAME or self.signalType == LRUconstants.AI_40mA_NAME:
            self.numChannels = 2
        
    def assignToHW(self, conn, rackID, crossRacks):
        '''TODO change this so that the PXI connectors wire to themselves for greater than 16V signals'''
        logger.debug("Assigning signal type %s with algorithm AI16V", self.signalType)
        routingXJ2IDs = routing.get_XJ2_from_back_of_routing_for_signal_type(conn, self.signalType, rackID)
        logger.debug("Routing XJ2IDs %s", routingXJ2IDs)
        numSignals = conn.execute("SELECT count(*) FROM SignalsInformation WHERE SignalType == ? AND RackID == ?", (self.signalType, rackID)).fetchone()[0]      
        for routingXJ2ID in routingXJ2IDs:
            RTIConIDs = self.addRTIToRoutingAndReturnConnectorIDsWithSignalType(conn, routingXJ2ID, rackID)
            while RTIConIDs:
                '''Iterate through 4 2-wire signals per bank'''
                for i in range(4):       
                    if numSignals < 1:
                        break
                    if i == 0:
                        '''For the first of the four signals, connect one end of the cable to the RTI'''
                        RTIConID = RTIConIDs.pop(0)
                        '''TODO need a different type of cable for 16V and 32V as they use different numbers of pins on the AI side'''
                        cableID = cables.add_new_cable(conn, self.eCableTypeID)
                        #===========================================================
                        # if self.numChannels == 2:
                        #     '''For 32V signals, double the number of cable connectors on the PXI side of things'''
                        #     cableConnectorsInfo = conn.execute("SELECT eCableConnectorID FROM CableConnectorInformation WHERE CableID == ? and eEndTypeID == ?", (cableID, 2)).fetchall()
                        #     for cableConnectorInfo in cableConnectorsInfo:
                        #         conn.execute("INSERT INTO CableConnectors (eCableConnectorID, CableID) VALUES (?,?)", (cableConnectorInfo[0], cableID))
                        #     conn.commit()
                        #===========================================================
                        RTICableConID = conn.execute("SELECT ID FROM CableConnectorInformation WHERE ConnectorTypeName == ? AND CableID == ?", ('NanoFit', cableID)).fetchone()[0]               
                        conn.execute("INSERT INTO RTICableConJunct (RTIConID, CableConID) VALUES (?,?)", (RTIConID, RTICableConID))
                    
                    openPXIConnectorIDs = conn.execute("SELECT ID, PXICardID FROM UnassignedPXIConnectors WHERE ePXIInsertTypeID == ? AND RackID == ? ORDER BY ID", (self.eCardTypeID,rackID)).fetchall()
                    #===============================================================
                    # PXICardIDs = {}
                    # for openPXIConnectorID in openPXIConnectorIDs:
                    #     if openPXIConnectorID[1] in PXICardIDs:
                    #         PXICardIDs[openPXIConnectorID[1]] += 1
                    #     else:
                    #         PXICardIDs[openPXIConnectorID[1]] = 1                        
                    # selectedCardID = -1
                    # for cardID, connectors in PXICardIDs:
                    #     if connectors > 3:
                    #         selectedCardID = cardID
                    #         break
                    #===============================================================
                    if len(openPXIConnectorIDs) >= (self.numChannels*2):
                        logger.info("resued 4322 card %s", len(openPXIConnectorIDs))
                        selectedCardID = openPXIConnectorIDs.pop()[1]
                    else:
                        selectedCardID = pxi.add_PXI_insert(conn, self.eCardTypeID, rackID)
                        logger.info("Added AI16 card")
                        if (selectedCardID == -1):
                            return -1
                    openPXIConnectorIDs = conn.execute("SELECT ID FROM UnassignedPXIConnectors WHERE PXICardID == ? ORDER BY ID", (selectedCardID,)).fetchall()
                    openPXIConnectorIDs = [x[0] for x in openPXIConnectorIDs]
                    PXICableConIDs = conn.execute("SELECT ID FROM CableConnectors WHERE CableID == ? AND eCableConnectorID IS NOT ?", (cableID, 20)).fetchall()
                    PXICableConIDs = [x[0] for x in PXICableConIDs]
                    openPXICableConIDs = []                
                    for PXICableConID in PXICableConIDs:
                        '''Check which cables aren't connected to anything yet'''
                        if not conn.execute("SELECT ID FROM PXICableConJunct WHERE CableConID == ?", (PXICableConID,)).fetchone():
                            openPXICableConIDs.append(PXICableConID)
                    if self.signalType == LRUconstants.AI_16V_NAME or self.signalType == LRUconstants.AI_20mA_NAME:    
                        pinCableConID = openPXICableConIDs.pop(0)
                        PXIConnectorID = openPXIConnectorIDs.pop(0)               
                        conn.execute("INSERT INTO PXICableConJunct (PXIConID, CableConID) VALUES (?,?)", (PXIConnectorID, pinCableConID))                                         
                        pinCableConID = openPXICableConIDs.pop(0)
                        PXIConnectorID = openPXIConnectorIDs.pop(0)               
                        conn.execute("INSERT INTO PXICableConJunct (PXIConID, CableConID) VALUES (?,?)", (PXIConnectorID, pinCableConID))                      
                    if self.signalType == LRUconstants.AI_32V_NAME or self.signalType == LRUconstants.AI_40mA_NAME:                    
                        pinCableConID = openPXICableConIDs.pop(0)
                        PXIConnectorID = openPXIConnectorIDs.pop(0)               
                        conn.execute("INSERT INTO PXICableConJunct (PXIConID, CableConID) VALUES (?,?)", (PXIConnectorID, pinCableConID))                                         
                        '''Add a wire between positive and ground'''
                        wireID = cables.add_new_cable(conn, self.eWireTypeID)
                        wirePinCons = conn.execute("SELECT ID FROM CableConnectors WHERE CableID == ?", (wireID,)).fetchall()                       
                        PXIConnectorID = openPXIConnectorIDs.pop(0)               
                        conn.execute("INSERT INTO PXICableConJunct (PXIConID, CableConID) VALUES (?,?)", (PXIConnectorID, wirePinCons[0][0]))                          
                        PXIConnectorID = openPXIConnectorIDs.pop(0)               
                        conn.execute("INSERT INTO PXICableConJunct (PXIConID, CableConID) VALUES (?,?)", (PXIConnectorID, wirePinCons[1][0]))                         
                        pinCableConID = openPXICableConIDs.pop(0)
                        PXIConnectorID = openPXIConnectorIDs.pop(0)               
                        conn.execute("INSERT INTO PXICableConJunct (PXIConID, CableConID) VALUES (?,?)", (PXIConnectorID, pinCableConID))                    
                    #===========================================================
                    # for j in range(2*self.numChannels):
                    #     '''connect signals to PXI connector'''
                    #     pinCableConID = openPXICableConIDs.pop(0)
                    #     PXIConnectorID = openPXIConnectorIDs.pop(0)               
                    #     conn.execute("INSERT INTO PXICableConJunct (PXIConID, CableConID) VALUES (?,?)", (PXIConnectorID, pinCableConID))                    
                    #===========================================================
                    numSignals -= 1
                    conn.commit()    
                
class MIL1553(SignalAssignment):
    def __init__(self, conn, signalType):
        '''First call the parent init function'''
        super(MIL1553,self).__init__(conn, signalType)
        self.FPGADIOCard = SPI(conn, LRUconstants.SPI_NAME)
        self.eCardTypeID = conn.execute("SELECT ID FROM eSLSCCardTypes WHERE Model == ?", ("MIL-STD 1553",)).fetchone()[0]
        self.eCableTypeID = conn.execute("SELECT ID FROM eCableTypes WHERE Name == ?", ("Twinax<->Twinax",)).fetchone()[0]
        self.eXJ2ID = conn.execute("SELECT ID FROM eSLSCConnectorList WHERE eSLSCCardTypeID == ? AND ConnectorLabel == ?", (self.eCardTypeID, 'XJ2')).fetchone()[0]
        self.eBulkheadPanelTypeID = conn.execute("SELECT ID FROM ePanelTypes WHERE ModelNumber == ?", (LRUconstants.BULKHEAD_PANEL_NAME,)).fetchone()[0]
        self.eBulkheadConnectorTypeID = conn.execute("SELECT ID FROM eConnectorTypes WHERE NAME == ?", ("Twinax",)).fetchone()[0]
        self.bulkheadRackUnits = conn.execute("SELECT RackUnits FROM ePanelTypes WHERE ID == ?", (self.eBulkheadPanelTypeID,)).fetchone()[0]
        self.eSLSCFrontConnectorIDs = conn.execute("SELECT ID FROM eSLSCConnectorList WHERE eSLSCCardTypeID == ? and ConnectorLabel IS NOT ?", (self.eCardTypeID, "XJ2")).fetchall()
        self.eDaughterCardID = conn.execute("SELECT ID FROM eSLSCDaughterCardTypes WHERE MODEL == ?", (LRUconstants.MIL_STD_1553_NAME,)).fetchone()[0]
        self.eSLSCFrontConnectorIDs = [x[0] for x in self.eSLSCFrontConnectorIDs]

    def assignToPanel(self, conn, sortedPanelConnectors, signalListTuple):
        '''First check if a bulkhead panel is availabe in any rack, if not add one'''
        bulkheadID = conn.execute("SELECT ID, RackID FROM Panels WHERE ePanelTypeID == ?", (self.eBulkheadPanelTypeID,)).fetchone()
        if bulkheadID is None:
            rackIDs = conn.execute("SELECT ID FROM Racks").fetchall()
            rackIDs = [x[0] for x in rackIDs]
            rackID = racks.get_rack_with_most_space(conn, rackIDs, racks.RackSpaceType.FRONT)
            bulkheadID = panels.insert_panel_into_rack(conn, rackID, self.eBulkheadPanelTypeID)
            if bulkheadID < 0:
                return bulkheadID
        else:
            rackID = bulkheadID[1]
            bulkheadID = bulkheadID[0]
        '''For each signal, add a connector to the bulkhead and assign the signal to the bulkead'''
        for signal in signalListTuple:
            conn.execute("INSERT INTO BulkheadConnectors (BulkheadPanelID, eConnectorTypeID, SignalID) VALUES (?,?,?)", (bulkheadID, self.eBulkheadConnectorTypeID, signal[0]))
        conn.commit()
    
    def connectRouting(self, conn, rackID):
        '''Skip routing for this signal type'''
        return 0
    
    def assignToHW(self, conn, rackID, crossRacks):
        '''Get a list of each unassigned connector on the bulkead'''
        unassignedBulkheadConnectorIDs = conn.execute("SELECT t1.ID FROM BulkheadConnectors t1 LEFT JOIN BulkheadCableConJunct t2 on t1.ID == t2.BulkheadConID WHERE t2.CableConID IS NULL AND t1.eConnectorTypeID == ?", (self.eBulkheadConnectorTypeID,)).fetchall()
        unassignedBulkheadConnectorIDs = [x[0] for x in unassignedBulkheadConnectorIDs]
        '''For each connector found, Check for an SLSC card with an open connector in the same rack as the bulkhead, add a new card if needed'''
        for bulkheadConID in unassignedBulkheadConnectorIDs:
            connInfo = slsc.check_for_an_open_SLSC_connector(conn, self.eSLSCFrontConnectorIDs, rackID, crossRacks = False)
            if connInfo is None:
                error = slsc.insert_SLSC_card_into_chassis(conn, self.eCardTypeID, rackID)
                if error < 0:
                    return error
                else:
                    connInfo = slsc.check_for_an_open_SLSC_connector(conn, self.eSLSCFrontConnectorIDs, rackID, crossRacks = False)                    
            '''Add a cable then connect both sides to the bulkhead connector and the SLSC card connector'''
            cableID = cables.add_new_cable(conn, self.eCableTypeID)
            cableConID = conn.execute("SELECT ID FROM CableConnectors WHERE CableID == ? AND eCableConnectorID == ?", (cableID, 30)).fetchone()[0]
            conn.execute("INSERT INTO BulkheadCableConJunct (BulkheadConID, CableConID) VALUES (?,?)", (bulkheadConID, cableConID))
            '''Get opposite side of cable, TODO fix hardcode'''
            cableConID = conn.execute("SELECT ID FROM CableConnectors WHERE CableID == ? AND eCableConnectorID IS NOT ?", (cableID, 30)).fetchone()[0]
            conn.execute("INSERT INTO SLSCCableConJunct (SLSCConID, CableConID) VALUES (?,?)", (connInfo[0], cableConID))
            "Also add the daughtercard"
            conn.execute("INSERT INTO SLSCMIL1553DaughterCards (eSLSCDaughterCardTypeID, AttachedChannelConID) VALUES (?,?)", (self.eDaughterCardID, connInfo[0]))
            conn.commit()      
        '''Assign the FPGA card connector'''
        SCXJ2IDs = conn.execute("SELECT ID FROM SLSCConnectorInformation WHERE eSLSCConnectorID == ? AND eCardTypeID  == ? AND RackID == ? AND eRTITypeID IS NULL", (self.eXJ2ID, self.eCardTypeID, rackID)).fetchall()
        for SCXJ2ID in SCXJ2IDs:             
            self.FPGADIOCard.connectToXJ2(conn, SCXJ2ID[0], rackID, crossRacks) 

class CUSTOMXWIRE(SignalAssignment):
    def __init__(self, conn, signalType):
        '''First call the parent init function'''
        super(CUSTOMXWIRE,self).__init__(conn, signalType)
        #self.eSLSCCardTypeID = conn.execute("SELECT ID FROM eSLSCCardTypes WHERE Model == ?", (signalType,)).fetchone()[0]
        self.eRTITypeID = conn.execute("SELECT ID FROM eRTITypes WHERE Model == ?", (LRUconstants.FOURBANK_RTI_MODEL,)).fetchone()[0]

    def assignToHW(self, conn, rackID, crossRacks):
        error = 0
        #error = self.addSignalConditionForRoutingSignals(conn, self.eSLSCCardTypeID, self.eRTITypeID, rackID, crossRacks)
        return error     

class Loads(SignalAssignment):
    '''Load simulation for small medium and large loads'''
    def __init__(self, conn, signalType):
        '''First call the parent init function'''
        super(Loads,self).__init__(conn, signalType)
        self.AICard = DirectRTIToPXI(conn, LRUconstants.AO_10V_NAME)
        self.cardTypeID = conn.execute("SELECT ID FROM eSLSCCardTypes WHERE Model == ?", ("8 Channel Load", )).fetchone()[0]
        self.eJ1ID = conn.execute("SELECT ID FROM eSLSCConnectorList WHERE eSLSCCardTypeID == ? AND ConnectorLabel == ?", (self.cardTypeID, 'J1')).fetchone()[0]
        self.eXJ2ID = conn.execute("SELECT ID FROM eSLSCConnectorList WHERE eSLSCCardTypeID == ? AND ConnectorLabel == ?", (self.cardTypeID, 'XJ2')).fetchone()[0]
        self.eCableTypeID = conn.execute("SELECT ID FROM eCableTypes WHERE Name == ?", (LRUconstants.HD44_DB9_CABLE_NAME,)).fetchone()[0]

    def assignToPanel(self, conn, inputPanelConnectors, signalListTuple, commit=True):
        '''TODO 2 signal types, one with real one without'''
        '''Assign real signals at the same time here. This is different than other signal types.'''
        if (self.signalType == LRUconstants.INPUT_SMALL_LOAD_NAME):        
            '''Find how many of those signals fit into a Bank'''
            signalsPerBank = 4
            if not inputPanelConnectors:
                return -1
            '''Only use connectors with no signals assigned'''
            signalDirection = conn.execute("SELECT Output FROM eSignalTypes WHERE Name == ?", (self.signalType,)).fetchone()[0]
            panelID = conn.execute("SELECT PanelID FROM PanelConnectors WHERE ID == ?", (inputPanelConnectors[0],)).fetchone()[0]
            compatiblePanelConnectors = panels.get_unassigned_connectors_with_direction(conn, panelID, signalDirection)
            assignablePanelConnectors = []
            for connector in compatiblePanelConnectors:
                if connector in inputPanelConnectors:
                    assignablePanelConnectors.append(connector)            
            '''Assign signals to panel connectors'''
            while (len(signalListTuple)):
                if (len(assignablePanelConnectors) == 0):
                    '''Return -1 if no connectors are left to assign to'''
                    return -1
                banksNeeded = int(math.ceil((len(signalListTuple))/signalsPerBank))
                logger.debug('%s banks are needed with number of signals %s and signals per bank %s', banksNeeded, (len(signalListTuple)), signalsPerBank)
                logger.debug('Panel cons to assign with number of banks %s', assignablePanelConnectors)
            
                '''If real is needed, assign to identical pins on seperate connector'''          
                selectedSimCon = assignablePanelConnectors.pop(0)
                inputPanelConnectors.remove(selectedSimCon)
                signalsAssigned = 0            
                bank = 0
                numPinsPerSignal = 2
                '''bankPins are 1-indexed'''
                bankPin = 1
                while (signalsAssigned < (signalsPerBank)):
                    if signalListTuple:
                        signalToAssign = signalListTuple.pop(0)[0]
                        if commit:
                            conn.execute("INSERT INTO SignalPanelConJunct (SignalID, PanelConID, Real) VALUES (?,?,?)", (signalToAssign, selectedSimCon, False))
                        for i in range (numPinsPerSignal):
                            if commit:
                                conn.execute("INSERT INTO SignalPanelPinJunct (SignalID, PanelConID, ConnectorBank, BankPin) VALUES (?,?,?,?)", (signalToAssign, selectedSimCon, bank, bankPin))
                            '''Only put sim signals in the panel pin junct table'''
                            #if real:
                                #conn.execute("INSERT INTO SignalPanelPinJunct (SignalID, PanelConID, ConnectorBank, BankPin) VALUES (?,?,?,?)", (signalToAssign, selectedRealCon[0], bank, bankPin))
                            if bankPin == LRUconstants.PINS_PER_BANK:
                                bankPin = 1
                                bank += 1  
                            bankPin += 1                    
                        signalsAssigned += 1
                    else:
                        break
                if commit:
                    conn.commit()
            '''Return the original list minus those that were removed'''
            return inputPanelConnectors

    def connectRouting(self, conn, rackID):
        '''This is an output and so doesn't need a routing card after panel'''
        return 0
            
    def assignToHW(self, conn, rackID, crossRacks):
        "TODO, make this signal type be assigned first"
        "Connect first two banks as sim signals and second two banks as real signals for every HD44 connector on the routing card"
        "Get connectors directly from panel because no routing card is needed"
        if (self.signalType == LRUconstants.INPUT_SMALL_LOAD_NAME):
            '''Assign the back of the routing cards to the front of the signal conditioning cards. The load card only allows signals on J1'''

            '''Find every connector with signals assigned for every panel in that rack'''    
            panelIDsInRack = conn.execute("SELECT ID FROM Panels WHERE RackID = ?", (rackID,)).fetchall()
            panelList = [x[0] for x in panelIDsInRack]
            simConnIDs = self.getPanelSignalConnectors(conn, panelList, cableCon=None, realOnly=False)
            while simConnIDs:
                '''add a card, connect to J1, pop panel connector'''
                loadCardID = slsc.insert_SLSC_card_into_chassis(conn, self.cardTypeID, rackID)
                SLSCConID = slsc.check_for_an_open_SLSC_connector(conn, [self.eJ1ID], rackID, crossRacks)
                '''For each sim connector, add load card an connect the top two DB9s. If there is a real, connect the corresponing bottom DB9'''
                cableID = cables.add_new_cable(conn, self.eCableTypeID)               
                '''Attach the SLSC end of the cable. TODO lookup the value for 4 instead of hardcoding'''
                SLSCCableConID = conn.execute("SELECT ID FROM CableConnectorInformation WHERE ConnectorTypeName == ? AND CableID == ?", ('HD44', cableID)).fetchone()[0]
                conn.execute("INSERT INTO SLSCCableConJunct (SLSCConID, CableConID) VALUES (?,?)", (SLSCConID[0], SLSCCableConID)) 
                '''Get the 4 ends of the cable. TODO Fix Hardcode. eIDs 33 and 34 are the sim banks. eIDs 35 and 36 are the real'''
                simPanelCableConID1 = conn.execute("SELECT ID FROM CableConnectorInformation WHERE ConnectorTypeName == ? AND CableID == ? AND eCableConnectorID == ?", ('DB9', cableID, 33)).fetchone()[0]
                simPanelCableConID2 = conn.execute("SELECT ID FROM CableConnectorInformation WHERE ConnectorTypeName == ? AND CableID == ? AND eCableConnectorID == ?", ('DB9', cableID, 34)).fetchone()[0]                                  
                
                '''First connect sim and real 1, then 2'''
                simConID = simConnIDs.pop(0)
                conn.execute("INSERT INTO PanelCableConJunct (PanelConID, CableConID) VALUES (?,?)", (simConID, simPanelCableConID1))
                if simConnIDs:
                    simConID = simConnIDs.pop(0)        
                    conn.execute("INSERT INTO PanelCableConJunct (PanelConID, CableConID) VALUES (?,?)", (simConID, simPanelCableConID2))
                else:
                    break
            conn.commit() 
            loadXJ2IDs = conn.execute("SELECT ID FROM SLSCConnectorInformation WHERE eSLSCConnectorID == ? AND eCardTypeID  == ? AND RackID == ?", (self.eXJ2ID, self.cardTypeID, rackID)).fetchall()              
            while loadXJ2IDs:
                '''for each connector connect to XJ2'''
                XJ2ID = loadXJ2IDs.pop(0)[0]  
                PXIConID = self.AICard.connectToXJ2(conn, XJ2ID, rackID, crossRacks)
                if PXIConID < 0:
                    return PXIConID
                if loadXJ2IDs:
                    XJ2ID = loadXJ2IDs.pop(0)[0]  
                    PXIConID = self.AICard.connectToXJ2(conn, XJ2ID, rackID, crossRacks)
                    if PXIConID < 0:
                        return PXIConID                  
            return 0
        else:
            return -1
    
    def connectPanelForRealSignals(self, conn, rackID, DUTConRackAssignment):
        '''Connect real signals to the small load card instead of using the routing card'''
        ePanelTypeID = conn.execute("SELECT ID FROM ePanelTypes WHERE ModelNumber == ?", (LRUconstants.SIGNAL_PANEL_NAME,)).fetchone()[0]
        signals = conn.execute("SELECT ID, RealConnector FROM Signals WHERE SignalType == ?", (self.signalType,))
        for signal in signals:
            '''Check if that signal has a real component'''
            if signal[1] is not None:
                simPanelCon = conn.execute("SELECT PanelConID, ePanelConnectorID, PanelID FROM SignalsInformation WHERE RackID == ? AND Real == ? AND ID == ?", (rackID, False, signal[0])).fetchone()
                if simPanelCon:
                    '''Check if there is a panel with real signals for that connector already'''
                    panelID = conn.execute("SELECT ID FROM Panels WHERE ReferencePanelID == ?", (simPanelCon[2],)).fetchone()
                    if panelID is None:
                        panelID = panels.insert_panel_into_rack(conn, rackID, ePanelTypeID, referencePanelID = simPanelCon[2])
                    else:
                        panelID = panelID[0]
                    matchingConnID = conn.execute("SELECT ID FROM PanelConnectors WHERE ePanelConnectorID == ? AND PanelID == ?", (simPanelCon[1], panelID)).fetchone()[0]
                    conn.execute("INSERT INTO SignalPanelConJunct (SignalID, PanelConID, Real) VALUES (?,?,?)", (signal[0], matchingConnID, True))                    
                    conn.commit()
                    '''Check if a cable is already connected to the real panel connector'''
                    realCableCon = conn.execute("SELECT ID FROM PanelCableConJunct WHERE PanelConID == ?", (matchingConnID,)).fetchone()
                    if realCableCon is None:
                        '''Connect to the load card using the same cable as the sim connector'''
                        loadCardID = conn.execute("SELECT SLSCCardID FROM SignalsInformation WHERE PanelConID == ?", (simPanelCon[0],)).fetchone()[0]                 
                        J1ConnID = conn.execute("SELECT ID FROM SLSCConnectors WHERE SLSCCardID == ? AND eSLSCConnectorID == ?", (loadCardID, 24)).fetchone()[0]
                        SLSCCableConID = conn.execute("SELECT CableConID FROM SLSCCableConJunct WHERE SLSCConID == ?", (J1ConnID,)).fetchone()[0]
                        cableID = conn.execute("SELECT CableID FROM CableConnectors WHERE ID == ?", (SLSCCableConID,)).fetchone()[0]
                        simCableConID = conn.execute("SELECT CableConID FROM PanelCableConJunct WHERE PanelConID == ?", (simPanelCon[0],)).fetchone()[0]
                        simCableConeID = conn.execute("SELECT eCableConnectorID FROM CableConnectors WHERE ID == ?", (simCableConID,)).fetchone()[0]
                        if simCableConeID == 33:
                            realPanelCableConID = conn.execute("SELECT ID FROM CableConnectorInformation WHERE ConnectorTypeName == ? AND CableID == ? AND eCableConnectorID == ?", ('DB9', cableID, 35)).fetchone()[0]  
                        elif simCableConeID == 34:
                            realPanelCableConID = conn.execute("SELECT ID FROM CableConnectorInformation WHERE ConnectorTypeName == ? AND CableID == ? AND eCableConnectorID == ?", ('DB9', cableID, 36)).fetchone()[0]                        
                        else:
                            logger.error("Unexpected connection to panel for connecting real small load")
                            return -1                   
                        conn.execute("INSERT INTO PanelCableConJunct (PanelConID, CableConID) VALUES (?,?)", (matchingConnID, realPanelCableConID))
                        conn.commit()                          
        return 0

class Power(SignalAssignment):
    '''Assign one power e-shelf for all power signals in a tester'''
    def __init__(self, conn, signalType):
        '''First call the parent init function'''
        self.signalType = signalType
        self.eShelfPanel = conn.execute("SELECT ID FROM ePanelTypes WHERE ModelNumber == ?", ("Power E-Shelf",)).fetchone()[0]
    
    def assignToPanel(self, conn, sortedPanelConnectors, signalListTuple):
        '''sortedPanelConnectors is empty and ignored for bulkhead signal types'''
        '''Add an e-Shelf to the rack and assign all signals to the e-shelf connector'''
        '''Get rack ID. There should only be one rack as all bulkhead signals go in the first rack system. May need to change this later'''
        racks = conn.execute("SELECT ID FROM Racks").fetchall()
        if racks:
            if len(racks) > 1:
                logger.error("More than one rack in system")
                return -1
            else:
                rackID = racks[0][0]
        else:
            logger.error("No racks found")
            return -1 
        '''Check if this rack already has a power shelf. It doesn't need more than one'''
        if (conn.execute("SELECT ID FROM Panels WHERE ePanelTypeID == ? AND RackID == ?", (self.eShelfPanel, rackID)).fetchone() is None):
            panelID = panels.insert_panel_into_rack(conn, rackID, self.eShelfPanel)
            '''Now assign all signals to the panel connector (assume one for now)'''
            panelConID = conn.execute("SELECT ID FROM PanelConnectors WHERE PanelID == ?", (panelID,)).fetchone()[0]
            for signal in signalListTuple:
                conn.execute("INSERT INTO SignalPanelConJunct (SignalID, PanelConID, Real) VALUES (?,?,?)", (signal[0], panelConID, False))
            conn.commit()
        return 0

    def connectRouting(self, conn, rackID):
        '''Power signals don't go through routing cards'''
        return 0
            
    def assignToHW(self, conn, rackID, crossRacks):
        '''No other HW is needed'''
        return 0
    
    def connectPanelForRealSignals(self, conn, rackID, DUTConRackAssignment):
        '''For the load card, this is done when assigning the Sim signal. Skip this step here'''
        return 0