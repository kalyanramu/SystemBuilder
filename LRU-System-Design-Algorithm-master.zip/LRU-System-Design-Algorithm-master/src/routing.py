'''
Created on Jul 26, 2017

@author: bsnover

Functions for assigning routing, faulting, and calibration features of the system.
'''
import logging
logger = logging.getLogger(__name__)

def get_XJ2_from_back_of_routing_for_signal_type (conn, signalType, rackID):
    '''Returns a list of RTI connector IDs at the back of all SLSC cards in the system associated with that signalType.'''
    '''TODO update this when going through multiple routing cards'''
    '''TODO replace the value 4 with a proper lookup'''
    cableIDs = conn.execute("SELECT DISTINCT CableID FROM SignalsInformation WHERE SignalType == ?", (signalType,)).fetchall()
    cableIDs = [x[0] for x in cableIDs]
    XJ2s = conn.execute("SELECT ID FROM SLSCConnectorInformation WHERE eConnectorTypeID == ? AND RackID == ? AND SLSCCardID IN (SELECT DISTINCT SLSCCardID FROM SLSCConnectorInformation WHERE CableID IN (%s))" % ','.join('?'*len(cableIDs)), ([4] + [rackID] + cableIDs)).fetchall()
    XJ2s = [x[0] for x in XJ2s]
#    XXX = conn.execute("SELECT CableID FROM CableConnectors WHERE ID IN (SELECT CableConID FROM SLSCCableConJunct WHERE SLSCConID IN (SELECT ID FROM SLSCConnectors WHERE eSLSCConnectorID == ? AND SLSCCardID IN (SELECT ID FROM SLSCCards WHERE eCardTypeID == ?)))", (4,2)).fetchall()
#    YYY = conn.execute("SELECT t7.SLSCCardID FROM SLSCConnectors t7 WHERE t7.ID IN (SELECT SLSCConID FROM SLSCCableConJunct WHERE CableConID IN (SELECT ID FROM CableConnectors WHERE CableID IN (%s)))" % ','.join('?'*len(cableIDs)), cableIDs).fetchall()
#    test = conn.execute("SELECT DISTINCT CableID FROM CableConnectors WHERE eCableConnectorID IN (?,?)", (4,5)).fetchall()
#    SLSCConnectorIDs = conn.execute("SELECT SLSCConID FROM SLSCCableConJunct WHERE CableConID IN (SELECT ID FROM CableConnectors WHERE eCableConnectorID IN (?,?))", (4,5)).fetchall()
#    print('CableIDs and SLSCConnectorIDs', cableIDs, SLSCConnectorIDs)
    #RTIConnIDs = conn.execute("SELECT DISTINCT t3.ID FROM S")   
    return XJ2s

def add_daughter_card_to_section(conn, routingCardID, eDaughterCardTypeID, section):
    '''Adds a daughter card of the specified type to the specified section of the specified routing card. If there is already a daughtercard on that section, return an error only if it is of the wrong type'''
    daughterCardsInfo = conn.execute("SELECT Section, eSLSCDaughterCardTypeID Section FROM SLSCRoutingDaughterCards WHERE SLSCRoutingCardID == ?", (routingCardID,)).fetchall()
    '''Check if there is a card on that section, if not, add one, if so, return an error if it is the wrong type'''
    found = False
    if daughterCardsInfo:
        for daughterCardInfo in daughterCardsInfo:
            if daughterCardInfo[0] == 0:
                if daughterCardInfo[1] is not 1:
                    logger.error("SLSC Card %s already has daughter card of wrong type", routingCardID)
                    return -1
                else:
                    found = True
    if found == False:
        conn.execute("INSERT INTO SLSCRoutingDaughterCards (eSLSCDaughterCardTypeID, SLSCRoutingCardID, Section) VALUES (?,?,?)", (eDaughterCardTypeID, routingCardID, section))                              
        conn.commit()   