'''
Created on Jun 19, 2017

@author: bsnover

This is the main module for the algorithm. The other modules do most of the work keeping this high-level.
A signal list is imported from a CSV file, and a test system is designed around that signal list.
TODO the algorithm can be modified and extended in the following places...
'''
#! /usr/bin/python

from shutil import copyfile
from random import randint
import LRUconstants, racks, slsc, panels, pxi, signals, cables, tools, softwareAndServices, sqlite3, os, logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

'''TODO Replace these as parameters to a function call when creating an optimizer that can try multiple solutions'''
TOP_SOURCE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATABASE_SOURCE = os.path.join(TOP_SOURCE_DIR, 'LRUTesterComponents.db')
DATABASE_RESULT = os.path.join(TOP_SOURCE_DIR, 'SystemConfig.db')
SIGNAL_LIST_PATH = os.path.join(TOP_SOURCE_DIR, 'SignalList.csv')

def signal_assignment_dictionary(conn):
    '''Associate an assignment algorithm class with each signal type'''
    algorithmDict = {}
    algorithmDict[LRUconstants.AI_10V_NAME] = signals.DirectRTIToPXI(conn, LRUconstants.AI_10V_NAME)
    algorithmDict[LRUconstants.AO_10V_NAME] = signals.DirectRTIToPXI(conn, LRUconstants.AO_10V_NAME)
    algorithmDict[LRUconstants.AO_30V_NAME] = signals.DirectRTIToPXI(conn, LRUconstants.AO_30V_NAME)
    algorithmDict[LRUconstants.AO_60V_NAME] = signals.DirectRTIToPXI(conn, LRUconstants.AO_60V_NAME)
    algorithmDict[LRUconstants.A0_20mA_NAME] = signals.DirectRTIToPXI(conn, LRUconstants.A0_20mA_NAME)
    algorithmDict[LRUconstants.A0_XmA_NAME] = signals.DirectRTIToPXI(conn, LRUconstants.A0_XmA_NAME)
    algorithmDict[LRUconstants.FOUR_WIRE_IVDT_NAME] = signals.VDT(conn, LRUconstants.FOUR_WIRE_IVDT_NAME)
    algorithmDict[LRUconstants.SIX_WIRE_IVDT_NAME] = signals.VDT(conn, LRUconstants.SIX_WIRE_IVDT_NAME)
    algorithmDict[LRUconstants.SIX_WIRE_OVDT_NAME] = signals.VDT(conn, LRUconstants.SIX_WIRE_OVDT_NAME)
    algorithmDict[LRUconstants.DI_28V_NAME] = signals.DiscreteInputs(conn, LRUconstants.DI_28V_NAME)
    algorithmDict[LRUconstants.DI_GND_OPEN_NAME] = signals.DiscreteInputs(conn, LRUconstants.DI_GND_OPEN_NAME)
    algorithmDict[LRUconstants.DI_OPEN_CLOSED_NAME] = signals.DiscreteInputs(conn, LRUconstants.DI_OPEN_CLOSED_NAME) 
    algorithmDict[LRUconstants.DI_TTL_NAME] = signals.PanelAssignmentOnly(conn, LRUconstants.DI_TTL_NAME)
    algorithmDict[LRUconstants.DO_GND_OPEN_NAME] = signals.DO(conn, LRUconstants.DO_GND_OPEN_NAME)
    algorithmDict[LRUconstants.DO_28V_OPEN_NAME] = signals.DO(conn, LRUconstants.DO_28V_OPEN_NAME)
    algorithmDict[LRUconstants.ARINC_429_RX_NAME] = signals.SignalConditionedDigital(conn, LRUconstants.ARINC_429_RX_NAME)
    algorithmDict[LRUconstants.ARINC_429_TX_NAME] = signals.SignalConditionedDigital(conn, LRUconstants.ARINC_429_TX_NAME)
    algorithmDict[LRUconstants.PWM_INPUT_32V_FPGA] = signals.SignalConditionedDigital(conn, LRUconstants.PWM_INPUT_32V_FPGA)
    algorithmDict[LRUconstants.PWM_INPUT_32V] = signals.SignalConditionedDigital(conn, LRUconstants.PWM_INPUT_32V)
    algorithmDict[LRUconstants.RS422_NAME] = signals.Serial(conn, LRUconstants.RS422_NAME)
    algorithmDict[LRUconstants.RS485_NAME] = signals.Serial(conn, LRUconstants.RS485_NAME)
    algorithmDict[LRUconstants.AI_16V_NAME] = signals.AI16V(conn, LRUconstants.AI_16V_NAME)
    algorithmDict[LRUconstants.AI_32V_NAME] = signals.AI16V(conn, LRUconstants.AI_32V_NAME)
    algorithmDict[LRUconstants.AI_20mA_NAME] = signals.AI16V(conn, LRUconstants.AI_20mA_NAME)
    algorithmDict[LRUconstants.AI_40mA_NAME] = signals.AI16V(conn, LRUconstants.AI_40mA_NAME)    
    algorithmDict[LRUconstants.MIL_STD_1553_NAME] = signals.MIL1553(conn, LRUconstants.MIL_STD_1553_NAME)
    algorithmDict[LRUconstants.INPUT_RTD_NAME] = signals.SignalAssignment(conn, LRUconstants.INPUT_RTD_NAME)    #This should be handled by R-Sim SET card. Why only 2 pins per signal?
    algorithmDict[LRUconstants.ONE_WATT_RES_NAME] = signals.SignalConditionedDigital(conn, LRUconstants.ONE_WATT_RES_NAME)
    algorithmDict[LRUconstants.AI_THERMOCOUPLE_NAME] = signals.SignalAssignment(conn, LRUconstants.AI_THERMOCOUPLE_NAME)
    algorithmDict[LRUconstants.AO_THERMOCOUPLE_NAME] = signals.DirectRTIToPXI(conn, LRUconstants.AO_THERMOCOUPLE_NAME)
    algorithmDict[LRUconstants.INPUT_SYNCHRO_NAME] = signals.SignalAssignment(conn, LRUconstants.INPUT_SYNCHRO_NAME)
    algorithmDict[LRUconstants.INPUT_SMALL_LOAD_NAME] = signals.Loads(conn, LRUconstants.INPUT_SMALL_LOAD_NAME)   
    algorithmDict[LRUconstants.INPUT_LARGE_LOAD_NAME] = signals.NOOP(conn, LRUconstants.INPUT_LARGE_LOAD_NAME)
    algorithmDict[LRUconstants.POWER_28V_NAME] = signals.Power(conn, LRUconstants.POWER_28V_NAME)        
    return algorithmDict

def LRUSystemDesigner (conn, resultDatabase, signalList, DUTConRackAssignment, crossRacks):    
    '''Foreign keys protect against invalid data entry and are heavily used in this database, the default is Off for some reason'''
    conn.execute('pragma foreign_keys = on')
    
    signalAlgorithmDict = signal_assignment_dictionary(conn)     
    signalAlgorithmDict = signals.import_signals_from_csv(signalList, conn, signalAlgorithmDict)
 
    print('Calculate signals of each type needed for each connector on the DUT(s)')
    sortedDUTCons = panels.get_DUTCon_panel_assignment_order(conn)
     
    print('Sorted list of DUT Connectors and required banks:', sortedDUTCons, 'to be assigned in the following order:', DUTConRackAssignment)
    
    eSignalPanelTypeID = conn.execute("SELECT ID FROM ePanelTypes WHERE ModelNumber == ?", (LRUconstants.SIGNAL_PANEL_NAME,)).fetchone()[0]
    error = 0
    numDUTConParameters = 0
    for item in DUTConRackAssignment:
        numDUTConParameters += len(item)
    if (numDUTConParameters < len(sortedDUTCons)):
        logger.error("DUTConRackAssignment doesn't have enough DUT connectors to match the signals in the file")
        return -1
    for DUTConRack in DUTConRackAssignment:
        '''Add a new rack for each element in DUTConRackAssignment'''
        currentRackID = racks.add_new_rack(conn)
        for Con in DUTConRack:
            '''Validate that the provided constraints match the DUTCon names in the provided file'''
            nextDUTCon = -1
            for DUTCon in sortedDUTCons:
                if DUTCon[0] == Con:
                    nextDUTCon = DUTCon
            if nextDUTCon == -1:
                logger.error('DUTCon %s used in parameter not found in file. Change DUTCon constraint input.', Con)
                error = -1
                return error
            print('Assigning panels for DUTConnector', nextDUTCon)
            print('Current Rack ID', currentRackID)
            '''For each connector, Assign signals to panels'''
            error = panels.assign_DUTConnector_signals_to_panels(conn, nextDUTCon, currentRackID, signalAlgorithmDict, eSignalPanelTypeID)
            if(error > -1):
                print('DUT Connector panel assignment was successfull')
            else:
                print('Failed to add that DUTconnector to selected racks')
                return error
            print ('Assigning signal path HW', nextDUTCon)
        '''Once all signals have been assigned to panels for that rack, assign the hardware signal paths'''
        if (signals.assign_signal_path_HW(conn, currentRackID, signalAlgorithmDict, DUTConRackAssignment, crossRacks) > -1):
            print ("Panel to PXI signal path assignment was successful for", nextDUTCon)
        else:
            print("Specified DUTCons can't be supported within a single rack:", DUTConRack)
            error = -1
            break  
    slsc.attach_missing_RTIs(conn)
    pxi.cleanup_extras(conn)
    #tools.visual_designer(conn)
    print(pxi.get_downsizeable_chassis(conn,1))
    softwareAndServices.add_software(conn)
    '''Close the database connection'''
    conn.close
    return error
    
if __name__ == '__main__':
    
    '''Array of tuples where each tuple in the array represents the DUTConnectors assigned to a rack. Two element array is two racks.'''
    #DUTConRackAssignment = [("J1","J1 - 2")]
    #DUTConRackAssignment = [("DCU",),("MISSYS","DAFCS","SCU")]
    DUTConRackAssignment = [("CP","CP-2","Hydro")]
    #DUTConRackAssignment = [("J7","J5","J3","J6")]
    #DUTConRackAssignment = [("ASCU1", "AMS SIM", "ASCU2", "RIO 1", "RIO 2", "RIO 3")]    
    #DUTConRackAssignment = [("J1",)]
    #DUTConRackAssignment = [("SIU1-ECL","SIU1-FCP","SIU1-CPT","SIU2-ECL","SIU2-FCP","SIU2-CPT","SIU1-SILIO1","SIU2-SILIO1","SIU1-PL1-Mon","SIU2-PL1-Mon","SIU1-PL3-Mon","SIU2-PL3-Mon","USER1")]
    #DUTConRackAssignment = [("Conn",)]
    '''copy the original database seed file so it can be reused without change'''
    copyfile(DATABASE_SOURCE, DATABASE_RESULT)
    conn = sqlite3.connect(DATABASE_RESULT)    
    
    error = LRUSystemDesigner (conn, DATABASE_RESULT, SIGNAL_LIST_PATH, DUTConRackAssignment, crossRacks=True)          
    if error < 0:
        print("Failed to design system")    
    else:
        print("System design completed successfully!")
        conn = sqlite3.connect(DATABASE_RESULT)
        cables.check_all_cable_connections(conn)        
        rackIDs = conn.execute("SELECT ID FROM Racks").fetchall()
        tools.print_system(conn)
        tools.generate_signal_assignment_report(conn, printReal = True)
        tools.generate_line_item_BOM_report(conn)
        print('')
        print('Printing signal traces...')
        print('')
        '''Randomly select one signal of each signal type to print'''
        signalTypeNames = []
        for signalType in signalTypeNames:
            print("Printing signal type ", signalType)
            signalIDs = conn.execute("SELECT ID FROM Signals WHERE SignalType == ?", (signalType,)).fetchall()
            for signalID in signalIDs:
                tools.print_full_signal_trace(conn, signalID[0], includeCal=True, includeReal=False)           
        allSignalTypeNames = conn.execute("SELECT DISTINCT SignalType FROM Signals").fetchall()
        for signalType in allSignalTypeNames:
            if signalType not in signalTypeNames:
                signalIDs = conn.execute("SELECT ID FROM Signals WHERE SignalType == ?", (signalType[0],)).fetchall()
                randomIndex = randint(0, (len(signalIDs)-1))
                print("Printing signal", randomIndex+1, "of", len(signalIDs), "signals")
                tools.print_full_signal_trace(conn, signalIDs[randomIndex][0], includeCal=True, includeReal=False)      
        for rackID in rackIDs:
            print("Printing details for rack ID", rackID[0])
            frontSpace = racks.get_available_rack_space(conn, rackID[0], racks.RackSpaceType.FRONT)
            print('Front RackSpace', frontSpace)
            internalSpace = racks.get_available_rack_space(conn, rackID[0], racks.RackSpaceType.INTERNAL)
            print('Internal RackSpace', internalSpace)
            tools.advisor_config(conn, rackID[0])    
        print ("Unused PXI connectors:", pxi.get_all_open_PXI_connectors(conn))
        print ("Unused SLSC front connectors:", slsc.get_all_open_SLSC_front_connectors(conn))
        conn.close()
