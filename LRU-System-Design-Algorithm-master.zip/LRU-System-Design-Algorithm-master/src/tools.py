'''
Created on Dec 1, 2017

@author: bsnover
'''
import cables, math, csv, logging, xlsxwriter, pxi
import tkinter as tk
from tkinter import *
from tkinter import ttk
from collections import Counter
from distutils.log import info
logger = logging.getLogger(__name__) 

def append_PN_to_query (query, pnTuple):
    '''Takes a tuple of part numbers from an SQL query and appends them to a URL query'''
    pnList = [x[0] for x in pnTuple]
    pnDict = Counter(pnList)
    for pn in pnDict:
        query += '&pn=' + pn + '&qty=' + str(pnDict[pn])
    return query

def append_PN_to_string (string, pnTuple):
    pnList = [x[0] for x in pnTuple]
    pnDict = Counter(pnList)
    for pn in pnDict:
        string += 'PN:' + pn + ' Qty:' + str(pnDict[pn]) + ' '
    return string    
    
def advisor_config(conn, rackID, oncePerSystemItems = True):
    '''Get the last PXI chassis first and add all the SLSC chassis and accessories to that quote. Then create URLs without accessories for all other PXI chassis'''
    print()
    print("Generating PXI Advisor URLs:")
    niManufacturerID = conn.execute("SELECT ID FROM eManufacturers WHERE Name == ?", ("National Instruments",)).fetchone()[0]
    pxiChassisIDs = conn.execute("SELECT ID FROM PXIChassis WHERE RackID == ? ORDER BY ID DESC", (rackID,)).fetchall()
    for pxiChassisID in pxiChassisIDs:
        query = 'http://venus.ni.com/advisors/pxi?&Defaults=no'
        '''Fetchall for compatibility with the 'append_PN_to_query' function even though we only expect one record to be returned'''
        chassisPN = conn.execute("SELECT t2.PartNumber FROM PXIChassis t1 LEFT JOIN ePXIChassisTypes t2 ON t1.ePXIChassisTypeID == t2.ID WHERE t1.ID == ?", (pxiChassisID[0],)).fetchall()
        query = append_PN_to_query(query, chassisPN)
        chassisInserts = conn.execute("SELECT t2.PartNumber FROM PXIChassisInserts t1 LEFT JOIN ePXIInsertTypes t2 ON t1.ePXIInsertTypeID == t2.ID WHERE PXIChassisID == ?", (pxiChassisID[0],)).fetchall()
        query = append_PN_to_query(query, chassisInserts)
        '''Add all extras to the first chassis'''
        if pxiChassisID == pxiChassisIDs[0]:
            '''Add accessories'''
            accessories = conn.execute("SELECT t2.PartNumber FROM Accessories t1 LEFT JOIN eAccessories t2 ON t1.eAccessoryTypeID == t2.ID WHERE t1.RackID == ?", (rackID,)).fetchall()
            query = append_PN_to_query(query, accessories)    
            '''Add software'''
            if oncePerSystemItems:
                softwarePN = conn.execute("SELECT t2.PartNumber FROM Software t1 LEFT JOIN eSoftwareTypes t2 ON t1.SoftwareTypeID == t2.ID WHERE t2.ManufacturerID == ?", (niManufacturerID,)).fetchall()
                query = append_PN_to_query(query, softwarePN)                
        print (query)
    '''Add SLSC Chassis to main quote'''
    slscChassisPNs = conn.execute("SELECT t2.PartNumber FROM SLSCChassis t1 LEFT JOIN eSLSCChassisTypes t2 ON t1.ChassisTypeID == t2.ID WHERE t1.RackID == ?", (rackID,)).fetchall()
    slscChassisPNs = [x[0] for x in slscChassisPNs]
    '''Print items that must be added to the quote outside of the advisor like SLSC cards, RMCs, and RTIs'''
    rtiPNs = conn.execute("SELECT t2.PartNumber FROM RTIs t1 LEFT JOIN eRTITypes t2 ON t1.eRTITypeID == t2.ID WHERE SLSCXJ2ID IN (SELECT ID FROM SLSCConnectorInformation WHERE RackID == ?)", (rackID,)).fetchall()
    slscCardPNs = conn.execute("SELECT t2.PartNumber FROM SLSCCards t1 LEFT JOIN eSLSCCardTypes t2 ON t1.eCardTypeID == t2.ID WHERE t2.ManufacturerID == ? AND t1.SLSCChassisID IN (SELECT ID FROM SLSCChassis WHERE RackID == ?)", (niManufacturerID, rackID)).fetchall()
    print()
    print("1. Open all provided links in a browser when logged in to the network and manually select 'Standard Services' for each.")
    print("2. Create the rack layout in the first link using the 'ATE Core Configuration' tab. Select the desired power type: Low, Medium, or High.")
    print("3. Import and assign all additional PXI Chassis configurations in their appropriate place in the rack using the PXIConfigID from the additional links.")
    print("4. Add the following SLSC chassis to the rack layout:", slscChassisPNs)
    print("5. Add the following additional part numbers (SLSC Cards, RMCs, RTIs, Filler Pannels, etc.) to the quote seperately as they are not supported by the advisor:")
    if rtiPNs:
        string = ''
        string = append_PN_to_string(string, rtiPNs)
        print("RTI PartNumbers:", string)
    if slscCardPNs:
        string = ''
        string = append_PN_to_string(string, slscCardPNs)
        print("SLSC Card PartNumbers:", string)        
    print("Add the RMC and filler panels") 

def get_HW_price_total (conn):
    HWPriceTotal = 0
    PXIChassisPriceTotal = conn.execute("SELECT sum (t2.Price) FROM PXIChassis t1 LEFT OUTER JOIN ePXIChassisTypes t2 ON t1.ePXIChassisTypeID == t2.ID").fetchone()[0]
    if PXIChassisPriceTotal:
        HWPriceTotal += PXIChassisPriceTotal
    PXIInsertPriceTotal = conn.execute("SELECT sum(t2.Price) FROM PXIChassisInserts t1 LEFT OUTER JOIN ePXIInsertTypes t2 ON t1.ePXIInsertTypeID == t2.ID").fetchone()[0]
    if PXIInsertPriceTotal:
        HWPriceTotal += PXIInsertPriceTotal    
    SLSCChassisPriceTotal = conn.execute("SELECT sum(t2.ListPrice) FROM SLSCChassis t1 LEFT OUTER JOIN eSLSCChassisTypes t2 ON t1.ChassisTypeID == t2.ID").fetchone()[0]
    if SLSCChassisPriceTotal:
        HWPriceTotal += SLSCChassisPriceTotal
    SLSCCardPriceTotal = conn.execute("SELECT sum(t2.ListPrice) FROM SLSCCards t1 LEFT OUTER JOIN eSLSCCardTypes t2 ON t1.eCardTypeID == t2.ID").fetchone()[0]
    if SLSCCardPriceTotal:
        HWPriceTotal += SLSCCardPriceTotal
    SLSCRoutingDaughterCardPriceTotal = conn.execute("SELECT sum(t2.Price) FROM SLSCRoutingDaughterCards t1 LEFT OUTER JOIN eSLSCDaughterCardTypes t2 ON t1.eSLSCDaughterCardTypeID == t2.ID").fetchone()[0]
    if SLSCRoutingDaughterCardPriceTotal:
        HWPriceTotal += SLSCRoutingDaughterCardPriceTotal
    SLSC1553DaughterCardPriceTotal = conn.execute("SELECT sum(t2.Price) FROM SLSCMIL1553DaughterCards t1 LEFT OUTER JOIN eSLSCDaughterCardTypes t2 ON t1.eSLSCDaughterCardTypeID == t2.ID").fetchone()[0]
    if SLSC1553DaughterCardPriceTotal:
        HWPriceTotal += SLSC1553DaughterCardPriceTotal    
    RTIPriceTotal = conn.execute("SELECT sum(t2.Price) FROM RTIs t1 LEFT OUTER JOIN eRTITypes t2 ON t1.eRTITypeID == t2.ID").fetchone()[0]
    if RTIPriceTotal:
        HWPriceTotal += RTIPriceTotal
    CablePriceTotal = conn.execute("SELECT sum(t2.Price) FROM Cables t1 LEFT OUTER JOIN eCableTypes t2 ON t1.eCableTypeID == t2.ID").fetchone()[0]
    if CablePriceTotal:
        HWPriceTotal += CablePriceTotal
    PanelPriceTotal = conn.execute("SELECT sum(ListPrice) FROM Panels LEFT OUTER JOIN ePanelTypes ON Panels.ePanelTypeID = ePanelTypes.ID").fetchone()[0]
    if PanelPriceTotal:
        HWPriceTotal += PanelPriceTotal
    RackPriceTotal = conn.execute("SELECT sum(Price) FROM RackInformation").fetchone()[0]
    if RackPriceTotal:
        HWPriceTotal += RackPriceTotal
    InternalRackHWPriceTotal = conn.execute("SELECT sum(t2.Price) FROM InternalRackHW t1 LEFT JOIN eInternalRackHW t2 ON t1.eInternalRackHWTypeID == t2.ID").fetchone()[0]
    if InternalRackHWPriceTotal:
        HWPriceTotal += InternalRackHWPriceTotal
    AccessoryPriceTotal = conn.execute("SELECT sum(t2.Price) FROM Accessories t1 LEFT JOIN eAccessories t2 ON t1.eAccessoryTypeID == t2.ID").fetchone()[0]
    if AccessoryPriceTotal:
        HWPriceTotal += AccessoryPriceTotal
    return HWPriceTotal

def print_system (conn):
    '''Prints out the final state of the system to the console as a sanity check, some queries can be reused in other tools, may not work with incomplete designs'''
    Racks = conn.execute('SELECT ID, ModelNumber, Price FROM RackInformation').fetchall()    
    for rack in Racks:
        print ('Rack ID', rack[0], 'Type', rack[1])
        Panels = conn.execute('SELECT ID, ePanelTypeID FROM Panels WHERE RackID == ?', (rack[0],)).fetchall()
        PanelInfo = []
        for Panel in Panels:
            panelType = conn.execute("SELECT ModelNumber FROM ePanelTypes WHERE ID == ?", (Panel[1],)).fetchone()[0]
            PanelInfo.append((panelType))     
        print ('    Panel ID/Model', PanelInfo)
        SLSCChassis = conn.execute("SELECT ID FROM SLSCChassis WHERE RackID = ?", (rack[0],)).fetchall()
        for chassis in SLSCChassis:
            print ('    SLSC Chassis ID', chassis[0])
            SLSCCards = conn.execute("SELECT t2.Model FROM SLSCCards t1 LEFT JOIN eSLSCCardTypes t2 on t1.eCardTypeID == t2.ID WHERE t1.SLSCChassisID == ?", (chassis[0],)).fetchall()
            SLSCCards = [x[0] for x in SLSCCards]
            print ('        SLSCCards', SLSCCards)
        PXIChassis = conn.execute("SELECT t1.ID, t2.Model FROM PXIChassis t1 LEFT JOIN ePXIChassisTypes t2 ON t1.ePXIChassisTypeID == t2.ID WHERE RackID = ?", (rack[0],)).fetchall()
        for chassis in PXIChassis:
            print ('    PXI Chassis ID', chassis[0], 'Model', chassis[1])
            PXIInserts = conn.execute("SELECT t2.Model FROM PXIChassisInserts t1 LEFT JOIN ePXIInsertTypes t2 ON t1.ePXIInsertTypeID == t2.ID WHERE t1.PXIChassisID == ?", (chassis[0],)).fetchall()
            PXIInserts = [x[0] for x in PXIInserts]
            print('        PXI Inserts', PXIInserts)
        InternalRackHW = conn.execute("SELECT t2.Name FROM InternalRackHW t1 LEFT JOIN eInternalRackHW t2 ON t1.eInternalRackHWTypeID == t2.ID WHERE t1.RackID == ?", (rack[0],)).fetchall()
        InternalRackHW = [x[0] for x in InternalRackHW]
        print("    Internal Rack HW:", InternalRackHW)
    #===========================================================================
    # Racks = conn.execute('SELECT ModelNumber, Price FROM RackInformation').fetchall()
    # print('Final Rack List:')
    # print(Racks)
    # 
    # PXIModels = conn.execute("SELECT t2.Model, t2.Price FROM PXIChassisInserts t1 LEFT OUTER JOIN ePXIInsertTypes t2 ON t1.ePXIInsertTypeID == t2.ID").fetchall()
    # print('PXI Hardware:', PXIModels)
    # 
    # Panels = conn.execute('SELECT ModelNumber, ListPrice FROM Panels LEFT OUTER JOIN ePanelTypes ON Panels.ePanelTypeID = ePanelTypes.ID').fetchall()
    # print('Final Panel List:')
    # print(Panels)
    # 
    # print("Final PXI hardware list:")
    # print("  Model   Price")
    # for row in PXIModels:
    #     print (row[0], row[1])
    #     
    # SLSCChassis = conn.execute('SELECT count(*) FROM SLSCChassis').fetchone()[0]
    # print('Number of SLSC Chassis', SLSCChassis)
    # 
    # SLSCCardTypeIDs = conn.execute('SELECT DISTINCT eCardTypeID FROM SLSCCards').fetchall()
    # cardTypeCount = ()
    # for SLSCCardTypeID in SLSCCardTypeIDs:
    #     count = conn.execute('SELECT count(*) FROM SLSCCards WHERE eCardTypeID == ?', (SLSCCardTypeID[0],)).fetchone()[0]
    #     cardType = conn.execute('SELECT Model FROM eSLSCCardTypes WHERE ID == ?', (SLSCCardTypeID[0],)).fetchone()[0]
    #     cardTypeCount = (cardTypeCount + (cardType, count))
    # print('Number of SLSC Cards', cardTypeCount)
    #===========================================================================
    Accessories = conn.execute("SELECT t2.Name FROM Accessories t1 LEFT JOIN eAccessories t2 ON t1.eAccessoryTypeID == t2.ID").fetchall()
    Accessories = [x[0] for x in Accessories]
    print('Accessory List:', Accessories)
    
    RTIs = conn.execute("SELECT count(*) FROM RTIs").fetchone()[0]
    print('Number of RTIs:', RTIs)    
    
    SLSCRoutingCards = conn.execute("SELECT count(*) FROM SLSCCards WHERE eCardTypeID == ?", (2,)).fetchone()[0]
    print ("Number of SLSC Routing Cards:", SLSCRoutingCards)
    
    SLSCRoutingDaughterCards = conn.execute("SELECT count(*) FROM SLSCRoutingDaughterCards").fetchone()[0]
    print ("Number of SLSC Routing Daughter Cards:", SLSCRoutingDaughterCards)
    
    SLSC1553DaughterCards = conn.execute("SELECT count(*) FROM SLSCMIL1553DaughterCards").fetchone()[0]
    print ("Number of SLSC 1553 Daughter Cards:", SLSC1553DaughterCards)
    
    Cables = conn.execute("SELECT count(*) FROM Cables").fetchone()[0]
    print('Number of Cables:', Cables)
    
    Software = conn.execute("SELECT Name, Price FROM SoftwareInformation").fetchall()
    print('Final Software List:')
    print (Software)
    
    ServicesPriceTotal = 0
    BaseAssemblyCost = conn.execute("SELECT sum(Rate) FROM eRates WHERE UnitTypeID == (SELECT ID FROM eRateUnitTypes WHERE Name == ?)", ("Base Price",)).fetchone()[0]
    ServicesPriceTotal += BaseAssemblyCost
    print('Base assembly cost:', BaseAssemblyCost)
    numRacks = len(conn.execute("SELECT ID FROM Racks").fetchall())
    RackAssemblyCost = conn.execute("SELECT sum(Rate) FROM eRates WHERE UnitTypeID == (SELECT ID FROM eRateUnitTypes WHERE Name == ?)", ("Price per 1st Rack",)).fetchone()[0] + (numRacks - 1)*conn.execute("SELECT sum(Rate) FROM eRates WHERE UnitTypeID == (SELECT ID FROM eRateUnitTypes WHERE Name == ?)", ("Price per 2+ Racks",)).fetchone()[0]
    ServicesPriceTotal += RackAssemblyCost
    print('Rack assembly cost:', RackAssemblyCost)
    FTPCost = conn.execute("SELECT sum(Rate) FROM eRates WHERE UnitTypeID == (SELECT ID FROM eRateUnitTypes WHERE Name == ?)", ("Price per Pin",)).fetchone()[0]*conn.execute("SELECT sum(NumPins) FROM SignalsInformation").fetchone()[0]
    ServicesPriceTotal += FTPCost
    print('FTP cost:', FTPCost)
    #Services = conn.execute("SELECT Rate FROM eRates WHERE Name == ?", (""))

    SoftwarePriceTotal = conn.execute("SELECT sum(Price) FROM SoftwareInformation").fetchone()[0]
    
    HWPriceTotal = get_HW_price_total(conn)
    print('Hardware price total:', HWPriceTotal)
    SSP = conn.execute("SELECT Rate FROM eRates WHERE Name == ?", ("SSP",)).fetchone()[0] * HWPriceTotal
    print('SSP price:', round(SSP,2))
    Shipping = conn.execute("SELECT Rate FROM eRates WHERE Name == ?", ("Shipping",)).fetchone()[0] * HWPriceTotal
    print('Shipping cost:', round(Shipping, 2))
    print('Total:', round((HWPriceTotal + SoftwarePriceTotal + ServicesPriceTotal + SSP + Shipping),2))
    return

def print_full_signal_trace(conn, signalID, includeCal, includeReal):
    '''Prints out the full signal path of the provided signal ID. Starting with the panel, then through routing, signal conditioning, and PXI, with cabling along the way.'''
    signalInfo = conn.execute("SELECT SignalsPerBank, PanelConID, NumPins, ePanelConnectorID, CableID, SLSCCardID, PanelID, Connector, SignalName, DUTConnector, CableConID, RealConnector, SignalType, Bulkhead FROM SignalsInformation WHERE ID == ? AND Real IS NOT ?", (signalID, True)).fetchone()
    bulkhead = signalInfo[13]
    '''Get bank number on panel, also get pin number(s) within bank on panel connector'''
    print('Signal ID:', signalID, 'Signal Name:', signalInfo[8], 'SignalType:', signalInfo[12], 'DUTConnector:', signalInfo[9])    
    '''Check if it is a bulkead signal'''
    if bulkhead:
        '''Check if the signal is on the bulkhead or if its a custom panel type'''
        panelConID = conn.execute("SELECT PanelConID FROM SignalPanelConJunct WHERE SignalID == ?", (signalID,)).fetchone()

        if panelConID:
            '''We know its a custom panel'''
            panelConInfo = conn.execute("SELECT ID, PanelID FROM PanelConnectors WHERE ID == ?", (panelConID[0],)).fetchone()
            cableConID = conn.execute("SELECT CableConID FROM PanelCableConJunct WHERE PanelConID == ?", (panelConInfo[0],)).fetchone()
        else:
            panelConInfo = conn.execute("SELECT ID, BulkheadPanelID FROM BulkheadConnectors WHERE SignalID == ?", (signalID,)).fetchone()
            if panelConInfo:
                cableConID = conn.execute("SELECT CableConID FROM BulkheadCableConJunct WHERE BulkheadConID == ?", (panelConInfo[0],)).fetchone()
            else:
                logger.debug("No panel found for bulkhead signal")
                print()
                return
        eBulkheadPanelID = conn.execute("SELECT ePanelTypeID FROM Panels WHERE ID == ?", (panelConInfo[1],)).fetchone()[0]
        panelModel = conn.execute("SELECT ModelNumber FROM ePanelTypes WHERE ID == ?", (eBulkheadPanelID,)).fetchone()[0]
        rackID = conn.execute("SELECT RackID FROM Panels WHERE ePanelTypeID == ?", (eBulkheadPanelID,)).fetchone()[0]
        print("Rack ID:", rackID, "PanelModel:", panelModel, "BulkheadPanelID:", panelConInfo[1], "BulkheadConnectorID:", panelConInfo[0])
        if cableConID:
            cableConID = cableConID[0]
        else:
            print()
            return      
    else:
        panelPinNumbers = []
        panelConnectorInfo = conn.execute("SELECT ConnectorBank, BankPin FROM SignalPanelPinJunct WHERE SignalID == ?", (signalID,)).fetchone()
        if panelConnectorInfo == None:
            logger.error("Signal ID not found on a panel.")
            print()
            return
        connectorBankOffset = panelConnectorInfo[0]
        panelConnectorBank = conn.execute("SELECT Bank FROM ePanelPins WHERE BankPin == ? AND ePanelConnectorID == ?", (panelConnectorInfo[1], signalInfo[3])).fetchone()[0] + connectorBankOffset
        '''Get pin information for panel connector'''
        bankPins = conn.execute("SELECT BankPin FROM SignalPanelPinJunct WHERE SignalID == ?", (signalID,)).fetchall()
        bankPinList = []
        for pin in bankPins:
            bankPinList.append(pin[0])
            panelPinNumbers.append(conn.execute("SELECT Number FROM ePanelPins WHERE ePanelConnectorID == ? AND Bank == ? AND BankPin == ?", (signalInfo[3], panelConnectorBank, pin[0])).fetchone()[0])
        print('PanelID:', signalInfo[6], 'Panel Connector:', signalInfo[7], 'Panel Bank#:', panelConnectorBank, 'Connector Pins:', panelPinNumbers)
        cableConID = signalInfo[10]
    while True:
        '''Go from cable to thing it is connected to until the trail runs cold'''
        cableInformation = conn.execute("SELECT CableID, Name, eCableConnectorID, eEndTypeID, eCableTypeID, ConnectorTypeName FROM CableConnectorInformation WHERE ID == ?", (cableConID,)).fetchone()
        if bulkhead:
            oppositeSideConID = -1
        else:
            '''Get the right connector on the opposite side of the cable'''            
            oppositeSideConID = cables.get_opposite_side_connector_with_pin(conn, cableConID, connectorBankOffset, bankPinList[0])[0]
        '''Check if there are cable pins for that cable type'''
        if oppositeSideConID > -1:
            backConnectorType = conn.execute("SELECT ConnectorTypeName FROM CableConnectorInformation WHERE ID == ?", (oppositeSideConID,)).fetchone()[0]            
            eCableBank = cables.get_cable_bank(conn, cableConID, connectorBankOffset)
            print("CableType:", cableInformation[1], "CableID:", cableInformation[0], "CableBank:", eCableBank, "FrontConnectorType:", cableInformation[5], "and ID:",  cableConID, "BackConnectorType:", backConnectorType, "and ID:", oppositeSideConID)
            '''Find the SLSC card connector the cable is connected to if it exisits'''
            SLSCCardConID = conn.execute("SELECT SLSCConID FROM SLSCCableConJunct WHERE CableConID == ?", (oppositeSideConID,)).fetchone()
            if SLSCCardConID:
                '''Print the SLSC card information and the bank at the front of the card'''
                SLSCCardInfo = conn.execute("SELECT SLSCCardID, eCardTypeID, ConnectorLabel, eSLSCConnectorID FROM SLSCConnectorInformation WHERE ID == ?", (SLSCCardConID[0],)).fetchone()
                SLSCCardName = conn.execute("SELECT Model FROM eSLSCCardTypes WHERE ID == ?", (SLSCCardInfo[1],)).fetchone()[0]
                frontConnectorStartingBank = conn.execute("SELECT Bank FROM eSLSCPins WHERE eSLSCConnector == ?", (SLSCCardInfo[3],)).fetchone()[0]
                frontSLSCCardBank = frontConnectorStartingBank + eCableBank - 1   
                print("Connected to:", SLSCCardName, "ConnectorLabel:", SLSCCardInfo[2], "CardID:", SLSCCardInfo[0], "CardBank:", frontSLSCCardBank)
                '''Check if anything is connected to XJ2'''
                '''eRTIConnectorID IN (%s)" % ','.join('?'*len(eRTIConnectorIDs)), ([eBackSLSCPinName[0]] + eRTIConnectorIDs)).fetchone()'''
                frontSLSCPineIDs = conn.execute("SELECT ID, XJ2Pin FROM eSLSCPins WHERE eSLSCConnector == ? AND Bank == ? AND BankPin IN (%s)" % ','.join('?'*len(bankPinList)), ([SLSCCardInfo[3]] + [frontSLSCCardBank] + bankPinList)).fetchall()
                XJ2PineIDs = []
                for pin in frontSLSCPineIDs:
                    if pin[1]:
                        '''Make sure that pin exists, if so add it'''
                        test = conn.execute("SELECT Pin FROM eSLSCPinInformation WHERE eSLSCCardTypeID == ? AND Pin == ?", (SLSCCardInfo[1], pin[1])).fetchone()
                        if test:
                            XJ2PineIDs.append(pin[1])
                        else:
                            print("SLSC XJ2Pin", pin[1], "not found in database")
                if XJ2PineIDs == []:
                    logger.debug("No pins found for XJ2")
                    break
                frontSLSCPineIDs = [x[0] for x in frontSLSCPineIDs]
                eXJ2ID = conn.execute("SELECT ID FROM eSLSCConnectorList WHERE eSLSCCardTypeID == ? AND ConnectorLabel == ?", (SLSCCardInfo[1], "XJ2")).fetchone()
                if eXJ2ID is None:
                    '''This case happens for any discretes assigned to J2 on a routing card. They don't have a signal path to XJ2.'''
                    logger.debug("No definition for XJ2")
                    break
                else:
                    eXJ2ID = eXJ2ID[0]
                XJ2ID = conn.execute("SELECT ID FROM SLSCConnectorInformation WHERE SLSCCardID == ? AND eSLSCConnectorID == ?", (SLSCCardInfo[0], eXJ2ID)).fetchone()[0]               
                
                '''Find the connected RTI'''
                RTIInfo = conn.execute("SELECT ID, eRTITypeID FROM RTIs WHERE SLSCXJ2ID == ?", (XJ2ID,)).fetchone()
                if RTIInfo:
                    RTIID = RTIInfo[0]
                    eRTITypeID = RTIInfo[1]
                    eRTIConnectorIDs = conn.execute("SELECT ID FROM eRTIConnectorTypes WHERE eRTITypeID == ?", (eRTITypeID,)).fetchall()
                    eRTIConnectorIDs = [x[0] for x in eRTIConnectorIDs]
                    '''Update the pin list and SLSCCardBnk in case it gets transformed by the SLSC card'''
                    newBankPinList = []
                    for pin in XJ2PineIDs:             
                        '''Find the eRTIConnectorType for the eXJ2ID connector'''
                        eRTIConnectorInfo = conn.execute("SELECT DISTINCT eRTIConnectorID, Bank FROM eRTIConnectorPins WHERE RTIPin == ? AND eRTIConnectorID IN (%s)" % ','.join('?'*len(eRTIConnectorIDs)), ([pin] + eRTIConnectorIDs)).fetchone()
                        #eRTIPin = conn.execute("SELECT Pin FROM eSLSCPins WHERE eSLSCConnector == ? AND Bank == ? AND BankPin = ?", (eXJ2ID, frontSLSCCardBank, pin)).fetchone()
                        if eRTIConnectorInfo:
                            newBankPin = conn.execute("SELECT BankPin FROM eRTIConnectorPins WHERE eRTIConnectorID == ? AND RTIPin == ?", (eRTIConnectorInfo[0], pin)).fetchone()
                            if newBankPin:
                                newBankPinList.append(newBankPin[0])
                    if not newBankPinList:
                        logger.error("No path found to connector on RTI of type %s", eRTITypeID)
                        break
                    eRTIConnectorID = eRTIConnectorInfo[0]
                    bankPinList = newBankPinList
                    backSLSCCardBank = eRTIConnectorInfo[1]                                  
                    RTIConnectorID = conn.execute("SELECT ID FROM RTIConnectorInformation WHERE RTIID == ? AND eRTIConnectorTypeID == ?", (RTIID, eRTIConnectorID)).fetchone()[0]
                    numBanksOnCon = conn.execute("SELECT COUNT(DISTINCT Bank) FROM eRTIConnectorPins WHERE eRTIConnectorID == ?", (eRTIConnectorID,)).fetchone()[0]
                    '''This is a bit confusing. First 0-index the bank and mod it by the number of banks on the connector, then add one to 1-index the answer'''
                    backRTIConnectorBank = int(math.fmod((backSLSCCardBank - 1),(numBanksOnCon)))+1 
                    print("Connected to RTI:", RTIID, "Of type:", eRTITypeID, "Connector#:", RTIConnectorID, "Bank#:", backSLSCCardBank, "BankPin#s:", bankPinList)
                else:
                    '''If RTI was not found then the signal path is over'''
                    logger.debug("No connected RTI found")
                    break
                cableConID = conn.execute("SELECT CableConID FROM RTICableConJunct WHERE RTIConID == ?", (RTIConnectorID,)).fetchone()
                '''If there is no cable attached to the SLSC back connector than the signal path ends here'''
                if cableConID:
                    cableConID = cableConID[0]
                else:
                    logger.debug("No cable attached to the RTI connector: RTIConID = %s", RTIConnectorID)
                    break
                connectorBankOffset = backRTIConnectorBank - 1
            else:
                PXICardConID = conn.execute("SELECT PXIConID FROM PXICableConJunct WHERE CableConID == ?", (oppositeSideConID,)).fetchone()
                if PXICardConID:
                    ePXIConnector = conn.execute("SELECT eConnectorID FROM PXIConnectorInformation WHERE ID == ?", (PXICardConID[0],)).fetchone()[0]                 
                    '''Get the smallest bank on that connector, then add the cable bank to get the PXI Bank'''
                    PXIBank = conn.execute("SELECT Bank FROM ePXIPins WHERE ePXIConnectorID == ? ORDER BY Bank", (ePXIConnector,)).fetchone()[0]  + eCableBank - 1              
                    PXICardConInfo = conn.execute("SELECT PXICardID, ePXIInsertTypeID, ConnectorLabel, eConnectorTypeID FROM PXIConnectorInformation WHERE ID == ?", (PXICardConID[0],)).fetchone()
                    PXIModel = conn.execute("SELECT Model FROM ePXIInsertTypes WHERE ID == ?", (PXICardConInfo[1],)).fetchone()[0]
                    PXIStartingPin = conn.execute("SELECT Number, Name FROM ePXIPins WHERE ePXIConnectorID == ? AND Bank == ? AND BankPin IN (%s)" % ','.join('?'*len(bankPinList)), ([ePXIConnector] + [PXIBank] + bankPinList)).fetchall()
                    print("Connected to:", PXIModel, 'CardID:', PXICardConInfo[0], 'Connector:', PXICardConInfo[2], 'CardBank:', PXIBank, 'Pin_Number/Name:', PXIStartingPin)
                    break
                break        
        else:
            '''There is no pin information for the cable, so do a connector trace instead of a pin trace'''
            cableInfo = conn.execute("SELECT CableID, eEndTypeID, Name FROM CableConnectorInformation WHERE ID == ?", (cableConID,)).fetchone()
            oppositeSideConID = conn.execute("SELECT ID FROM CableConnectorInformation WHERE CableID == ? AND eEndTypeID IS NOT ?", (cableInfo[0], cableInfo[1])).fetchall()
            if len(oppositeSideConID) > 1:
                print("Missing Info: Cable type has", len(oppositeSideConID), "connectors on the opposite end with no bank information to trace. Selecting the first even though this may be wrong.")
            print("Cable Type:", cableInfo[2], "Cable Conn ID:", cableConID, "Cable ID:", cableInfo[0], "Other side ID:", oppositeSideConID[0][0])
            '''Find the SLSC card connector the cable is connected to if it exisits'''
            SLSCCardConID = conn.execute("SELECT SLSCConID FROM SLSCCableConJunct WHERE CableConID == ?", (oppositeSideConID[0][0],)).fetchone()
            if SLSCCardConID:
                '''Print the SLSC card information'''
                SLSCCardInfo = conn.execute("SELECT SLSCCardID, eCardTypeID, ConnectorLabel, eSLSCConnectorID FROM SLSCConnectorInformation WHERE ID == ?", (SLSCCardConID[0],)).fetchone()
                SLSCCardName = conn.execute("SELECT Model FROM eSLSCCardTypes WHERE ID == ?", (SLSCCardInfo[1],)).fetchone()[0]  
                print("Connected to:", SLSCCardName, "ConnectorLabel:", SLSCCardInfo[2], "CardID:", SLSCCardInfo[0])
                '''Check if anything is connected to XJ2'''
                eXJ2ID = conn.execute("SELECT ID FROM eSLSCConnectorList WHERE eSLSCCardTypeID == ? AND eConnectorTypeID == ?", (SLSCCardInfo[1], 4)).fetchone()[0]
                XJ2ID = conn.execute("SELECT ID FROM SLSCConnectorInformation WHERE SLSCCardID == ? AND eSLSCConnectorID == ?", (SLSCCardInfo[0], eXJ2ID)).fetchone()[0]
                '''See if an RTI is connected'''
                RTIInfo = conn.execute("SELECT ID, eRTITypeID FROM RTIs WHERE SLSCXJ2ID == ?", (XJ2ID,)).fetchone()
                if RTIInfo:
                    RTIID = RTIInfo[0]
                    eRTITypeID = RTIInfo[1]
                    '''Assume only one RTIconnectorID for now'''
                    RTIConnectorIDs = conn.execute("SELECT ID FROM RTIConnectorInformation WHERE RTIID == ? ORDER BY ID", (RTIID, )).fetchall()
                    if len(RTIConnectorIDs) > 1:
                        '''Select a connector at random because there is no way to pick the right one'''
                        numConnected = 0
                        RTIConnectorID = None
                        for connectorID in RTIConnectorIDs:
                            if conn.execute("SELECT ID FROM RTICableConJunct WHERE RTIConID == ?", (connectorID[0],)).fetchone():
                                numConnected+=1
                                if RTIConnectorID is None:
                                    RTIConnectorID = connectorID[0]
                        if RTIConnectorID is None:
                            print("Missing Info:", len(RTIConnectorIDs), "found with none connected to cables.")
                            print()
                            return
                        else:
                            print ("Missing Info:", len(RTIConnectorIDs), "connectors on RTI with", numConnected,"connected but with no bank information to trace. Selecting the first with a cable attached even though this may be wrong.")
                    RTIConnectorID = RTIConnectorIDs[0][0]
                    print("Connected to RTI:", RTIID, "Of type:", eRTITypeID, "and RTI Connector ID:", RTIConnectorID)
                    '''TODO, See if the signal flows from J1 to J2 here instead'''
                else:
                    '''If RTI was not found then the signal path is over'''
                    logger.debug("RTI was not found for this card")
                    break
                cableConID = conn.execute("SELECT CableConID FROM RTICableConJunct WHERE RTIConID == ?", (RTIConnectorID,)).fetchone()
                '''If there is no cable attached to the SLSC back connector than the signal path ends here'''
                if cableConID:
                    cableConID = cableConID[0]
                else:
                    logger.debug("No cable attached to the RTI connector, conID %s", RTIConnectorID[0])
                    break
            else:
                PXICardConID = conn.execute("SELECT PXIConID FROM PXICableConJunct WHERE CableConID == ?", (oppositeSideConID[0][0],)).fetchone()
                if PXICardConID:
                    ePXIConnector = conn.execute("SELECT eConnectorID FROM PXIConnectorInformation WHERE ID == ?", (PXICardConID[0],)).fetchone()[0]            
                    PXICardConInfo = conn.execute("SELECT PXICardID, ePXIInsertTypeID, ConnectorLabel, eConnectorTypeID FROM PXIConnectorInformation WHERE ID == ?", (PXICardConID[0],)).fetchone()
                    PXIModel = conn.execute("SELECT Model FROM ePXIInsertTypes WHERE ID == ?", (PXICardConInfo[1],)).fetchone()[0]
                    print("Connected to:", PXIModel, 'Connector:', PXICardConInfo[2])
                    break
                break    
    if includeCal and not bulkhead:
        eSignalConnector = signalInfo[3]
        eSignalConnectorBank = conn.execute("SELECT Bank FROM ePanelPins WHERE ePanelConnectorID == ?", (eSignalConnector,)).fetchone()[0]
        eCalConnector = conn.execute("SELECT ePanelConnectorID FROM ePanelPins WHERE Bank == ? AND ePanelConnectorID IS NOT ?", (eSignalConnectorBank, signalInfo[3])).fetchone()[0]
        calConnector = conn.execute("SELECT ID, Connector FROM PanelConnectorInformation WHERE PanelID == ? AND ePanelConnectorID == ?", (signalInfo[6], eCalConnector)).fetchone()
        '''Get Cal cable'''
        panelCableConnector = conn.execute("SELECT CableConID FROM PanelCableConJunct WHERE PanelConID == ?", (calConnector[0],)).fetchone()[0]
        '''Get other side connector TODO add bank info here'''   
        cableID = conn.execute("SELECT CableID FROM CableConnectors WHERE ID == ?", (panelCableConnector,)).fetchone()[0]
        SLSCCableConnector = cables.get_opposite_side_connector(conn, panelCableConnector, 0)
        '''Get routing card connector information'''
        SLSCConnectorID = conn.execute("SELECT SLSCConID FROM SLSCCableConJunct WHERE CableConID == ?", (SLSCCableConnector,)).fetchone()[0]
        SLSCConnectorInfo = conn.execute("SELECT SLSCCardID, ConnectorLabel FROM SLSCConnectorInformation WHERE ID == ?", (SLSCConnectorID,)).fetchone()
        print("Cal trace...PanelCalConnectorID:", calConnector[0], "Connector:", calConnector[1], "PanelCableConID:", panelCableConnector, "CableID:", cableID)
        print("SLSCCableConID:", SLSCCableConnector, "SLSCConnectorID:", SLSCConnectorID,"ConnectorLabel:", SLSCConnectorInfo[1], "SLSCCardID:", SLSCConnectorInfo[0]) 
    if signalInfo[11] and includeReal:
        '''Print out the trace from the signal to the panel for the real signal'''
        signalInfo = conn.execute("SELECT SignalsPerBank, PanelConID, NumPins, ePanelConnectorID, CableID, SLSCCardID, PanelID, Connector, SignalName, DUTConnector, CableConID, RealConnector FROM SignalsInformation WHERE ID == ? AND Real == ?", (signalID, True)).fetchone()
        '''Get bank number on panel, also get pin number(s) within bank on panel connector'''
        panelPinNumbers = []
        connectorBankOffset = conn.execute("SELECT ConnectorBank FROM SignalPanelPinJunct WHERE SignalID == ?", (signalID,)).fetchone()[0]
        panelConnectorBank = conn.execute("SELECT Bank FROM ePanelPins WHERE BankPin == ? AND ePanelConnectorID == ?", (1, signalInfo[3])).fetchone()[0] + connectorBankOffset
        '''Get pin information for panel connector'''
        bankPins = conn.execute("SELECT BankPin FROM SignalPanelPinJunct WHERE SignalID == ?", (signalID,)).fetchall()
        bankPinList = []
        for pin in bankPins:
            bankPinList.append(pin[0])
            panelPinNumbers.append(conn.execute("SELECT Number FROM ePanelPins WHERE Bank == ? AND BankPin == ?", (panelConnectorBank, pin[0])).fetchone()[0])        
        print('  Real Signal Info: ID:', signalID, 'Signal Name:', signalInfo[8], 'DUTConnector:', signalInfo[9])
        print('PanelID:', signalInfo[6], 'Panel Connector:', signalInfo[7], 'Panel Bank#:', panelConnectorBank, 'Connector Pins:', panelPinNumbers)
        '''Go from cable to thing it is connected to until the trail runs cold'''
        cableConID = signalInfo[10]
        cableInformation = conn.execute("SELECT CableID, Name, eCableConnectorID, eEndTypeID, eCableTypeID, ConnectorTypeName FROM CableConnectorInformation WHERE ID == ?", (cableConID,)).fetchone()
        '''Get the right connector on the opposite side of the cable'''          
        oppositeSideConID = cables.get_opposite_side_connector(conn, cableConID, connectorBankOffset)
        eCableBank = cables.get_cable_bank(conn, cableConID, connectorBankOffset)
        print("CableType:", cableInformation[1], "CableID:", cableInformation[0], "CableBank:", eCableBank, "FrontConnectorType:", cableInformation[5], "and ID:",  cableConID, "BackConnectorType:", oppositeSideConID[1], "and ID:", oppositeSideConID[0])
        '''Find the SLSC card connector the cable is connected to if it exisits'''
        SLSCCardConID = conn.execute("SELECT SLSCConID FROM SLSCCableConJunct WHERE CableConID == ?", (oppositeSideConID[0],)).fetchone()
        if SLSCCardConID:
            '''Print the SLSC card information and the bank at the front of the card'''
            SLSCCardInfo = conn.execute("SELECT SLSCCardID, eCardTypeID, ConnectorLabel, eSLSCConnectorID FROM SLSCConnectorInformation WHERE ID == ?", (SLSCCardConID[0],)).fetchone()
            SLSCCardName = conn.execute("SELECT Model FROM eSLSCCardTypes WHERE ID == ?", (SLSCCardInfo[1],)).fetchone()[0]
            frontConnectorStartingBank = conn.execute("SELECT Bank FROM eSLSCPins WHERE eSLSCConnector == ?", (SLSCCardInfo[3],)).fetchone()[0]
            frontSLSCCardBank = frontConnectorStartingBank + eCableBank - 1   
            print("Connected to:", SLSCCardName, "ConnectorLabel:", SLSCCardInfo[2], "CardID:", SLSCCardInfo[0], "Card Bank:", frontSLSCCardBank)           
    print()
    return

def generate_signal_assignment_report (conn, printReal = False):
    ofile  = open('connectorReport.csv', "w", newline='')
    writer = csv.writer(ofile, delimiter=',', quotechar='"', quoting=csv.QUOTE_ALL)
    writer.writerow(["Signal Name","Signal Type","DUTConnector","PanelConnector", "PanelID", "RackID", "Faulting?"])
    '''First print Bulkhead signal info'''
    signals = conn.execute("SELECT SignalID, BulkheadPanelID, ID, eConnectorTypeID FROM BulkheadConnectors").fetchall()
    if signals:
        bulkheadRackID = conn.execute("SELECT RackID FROM Panels WHERE ID == ?", (signals[0][1],)).fetchone()[0]
        for signal in signals:
            signalInfo = conn.execute("SELECT SignalName, SignalType, DUTConnector, LineFault FROM Signals WHERE ID == ?", (signal[0],)).fetchone()
            #print (signalInfo[0], signalInfo[1], signalInfo[2], panelConnector[1], panelID[0], rackID[0], signalInfo[3])
            writer.writerow([signalInfo[0], signalInfo[1], signalInfo[2], signal[2], signal[1], bulkheadRackID, signalInfo[3]])    
    '''for each rack'''
    rackIDs = conn.execute("SELECT ID FROM Racks").fetchall()
    for rackID in rackIDs:
        '''for each panel'''
        panelIDs = conn.execute("SELECT ID FROM Panels WHERE RackID == ?", rackID).fetchall()
        for panelID in panelIDs:
            '''for each connector'''
            panelConnectors = conn.execute("SELECT ID, ePanelConnectorID, Connector FROM PanelConnectorInformation WHERE PanelID == ?", panelID).fetchall()
            for panelConnector in panelConnectors:
                '''for each signal assigned to that connector'''
                if printReal:
                    signals = conn.execute("SELECT ID FROM SignalsInformation WHERE PanelConID == ?", (panelConnector[0],)).fetchall()
                else:
                    signals = conn.execute("SELECT ID FROM SignalsInformation WHERE PanelConID == ? AND Real == ?", (panelConnector[0], False)).fetchall()                                 
                for signal in signals:
                    signalInfo = conn.execute("SELECT SignalName, SignalType, DUTConnector, LineFault, Real, RealConnector FROM SignalsInformation WHERE ID == ? AND PanelConID == ?", (signal[0], panelConnector[0])).fetchone()
                    #print (signalInfo[0], signalInfo[1], signalInfo[2], panelConnector[1], panelID[0], rackID[0], signalInfo[3])
                    if (signalInfo[4] == 1):
                        writer.writerow([signalInfo[0], signalInfo[1], signalInfo[5], panelConnector[2], panelID[0], rackID[0], signalInfo[3]])
                    else:                    
                        writer.writerow([signalInfo[0], signalInfo[1], signalInfo[2], panelConnector[2], panelID[0], rackID[0], signalInfo[3]])
                '''print Signal Name, Signal Type, Connector Label, Panel #, Rack #, Faulting, Real/Sim''' 
    ofile.close()

def visual_designer(conn):
    visual_select_PXIChassis(conn)
    visual_change_SLSC_cards(conn)

def visual_select_PXIChassis(conn):
    PXIChassisIDs = conn.execute("SELECT ID FROM PXIChassis").fetchall()
    PXIChassisIDs = [x[0] for x in PXIChassisIDs]
    for chassis in PXIChassisIDs:
        replacementOptions = pxi.get_downsizeable_chassis(conn, chassis)
        print(replacementOptions)
        if replacementOptions:
            root = Tk()
            root.title("Change Chassis Type")
            # Add a grid
            mainframe = Frame(root)
            mainframe.grid(column=0,row=0, sticky=(N,W,E,S) )
            mainframe.columnconfigure(0, weight = 1)
            mainframe.rowconfigure(0, weight = 1)
            mainframe.pack(pady = 100, padx = 100)
            # Create a Tkinter variable
            tkvar = StringVar(root)
             
            # Dictionary with options
            choices = []
            chassiseID = conn.execute("SELECT ePXIChassisTypeID FROM PXIChassis WHERE ID == ?", (chassis,)).fetchone()[0]
            model = conn.execute("SELECT Model FROM ePXIChassisTypes WHERE ID == ?", (chassiseID,)).fetchone()[0]
            choices.append(model)
            for option in replacementOptions:
                choices.append(option[1])
            tkvar.set(model) # set the default option
            popupMenu = OptionMenu(mainframe, tkvar, *choices)
            Label(mainframe, text="Choose a dish").grid(row = 1, column = 1)
            popupMenu.grid(row = 2, column =1)
             
            # on change dropdown value
            selection = model
            def change_dropdown(*args):
                nonlocal selection 
                selection = tkvar.get()
             
            # link function to change dropdown
            tkvar.trace('w', change_dropdown)
             
            root.mainloop()
            if selection != model:
                print("Chassis type changed from", model ,"to", selection)
                neweID = conn.execute("SELECT ID FROM ePXIChassisTypes WHERE Model == ?", (selection,)).fetchone()[0]
                conn.execute("UPDATE PXIChassis SET ePXIChassisTypeID = ? WHERE ID == ?", (neweID, chassis))
    conn.commit()

def visual_change_SLSC_cards(conn):
    class ExampleApp(tk.Tk):
        def __init__(self):
            tk.Tk.__init__(self)
            values = ((1,2),(3,4))
            t = SimpleTable(self, values)
            #t.pack(side="top", fill="x")
            #t.set(0,0,"Hello, world")
    
    class SimpleTable(tk.Frame):
        def __init__(self, parent, values):
            # use black background so it "peeks through" to 
            # form grid lines
            #use a tuple of tuples
            tk.Frame.__init__(self, parent, background="black")
            row = 0
            self._widgets = []
            for item in values:
                current_row = []
                label = tk.Label(parent, text="TEST", 
                                 borderwidth=0, width=10)
                label.grid(row = row, column=0, sticky="nsew", padx=1, pady=1)
                current_row.append(label)
                tkvar = tk.StringVar()
                options = ["test", "Test2"]
                popupMenu = OptionMenu(parent, tkvar, *options)
                popupMenu.grid(row = row, column=1, sticky="nsew", padx=1, pady=1)
                current_row.append(popupMenu)
                self._widgets.append(current_row)
                row+=1
            self.grid_columnconfigure(0, weight=1)
            self.grid_columnconfigure(1, weight=1)

    
    
        def set(self, row, column, value):
            widget = self._widgets[row][column]
            widget.configure(text=value)
            
    app = ExampleApp()
    app.mainloop()
    
def generate_line_item_BOM_report (conn):
    workbook = xlsxwriter.Workbook('lineItemBOM.xlsx')
    worksheet = workbook.add_worksheet()
    data = []
    rackTypes = conn.execute("SELECT DISTINCT ModelNumber FROM RackInformation").fetchall()
    #Item Name, Part Number, Manufacturer, Quantity, Price, Table Type
    for rack in rackTypes:
        count = conn.execute("SELECT COUNT(*) FROM RackInformation WHERE ModelNumber == ?", (rack[0],)).fetchone()[0]
        info = conn.execute("SELECT Price FROM RackInformation WHERE ModelNumber == ?", (rack[0],)).fetchone()[0]
        data.append([rack[0], '', 'National Instruments', count, info,'','Rack'])
    internalRackHW = conn.execute("SELECT DISTINCT eInternalRackHWTypeID FROM InternalRackHW").fetchall()
    for HW in internalRackHW:
        count = conn.execute("SELECT COUNT(*) FROM InternalRackHW WHERE eInternalRackHWTypeID == ?", (HW[0],)).fetchone()[0]
        info = conn.execute("SELECT t1.Name, t2.Name, t1.Price FROM eInternalRackHW t1 LEFT JOIN eManufacturers t2 on t1.ManufacturerID == t2.ID WHERE t1.ID == ?", (HW[0],)).fetchone()
        data.append([info[0], '', info[1], count, info[2], '','InternalRackHW'])                
    panels = conn.execute("SELECT DISTINCT ePanelTypeID FROM Panels").fetchall()
    for panel in panels:
        count = conn.execute("SELECT COUNT(*) FROM Panels WHERE ePanelTypeID == ?", (panel[0],)).fetchone()[0]  
        info = conn.execute("SELECT t1.ModelNumber, t1.PartNumber, t2.Name, t1.ListPrice FROM ePanelTypes t1 LEFT JOIN eManufacturers t2 on t1.ManufacturerID == t2.ID WHERE t1.ID == ?", (panel[0],)).fetchone()              
        data.append([info[0], info[1], info[2], count, info[3],'', 'Panels'])        
    SLSCChassis = conn.execute("SELECT DISTINCT ChassisTypeID FROM SLSCChassis").fetchall()
    for chassis in SLSCChassis:
        count = conn.execute("SELECT COUNT(*) FROM SLSCChassis WHERE ChassisTypeID == ?", (chassis[0],)).fetchone()[0]
        info = conn.execute("SELECT ModelNumber, PartNumber, ListPrice FROM eSLSCChassisTypes WHERE ID == ?", (chassis[0],)).fetchone()    
        data.append([info[0], info[1], 'National Instruments', count, info[2],'', 'SLSCChassis'])       
    SLSCCards = conn.execute("SELECT DISTINCT eCardTypeID FROM SLSCCards").fetchall()
    for card in SLSCCards:
        count = conn.execute("SELECT COUNT(*) FROM SLSCCards WHERE eCardTypeID == ?", (card[0],)).fetchone()[0]
        info = conn.execute("SELECT t1.Model, t1.PartNumber, t2.Name, t1.ListPrice FROM eSLSCCardTypes t1 LEFT JOIN eManufacturers t2 on t1.ManufacturerID == t2.ID WHERE t1.ID == ?", (card[0],)).fetchone()                
        data.append([info[0], info[1], info[2], count, info[3], '','SLSCCards'])     
    SLSCRoutingDaughterCards = conn.execute("SELECT DISTINCT eSLSCDaughterCardTypeID FROM SLSCRoutingDaughterCards").fetchall()
    for daughterCard in SLSCRoutingDaughterCards:
        count = conn.execute("SELECT COUNT(*) FROM SLSCRoutingDaughterCards WHERE eSLSCDaughterCardTypeID == ?", (daughterCard[0],)).fetchone()[0]
        info = conn.execute("SELECT t1.Model, t1.PartNumber, t2.Name, t1.Price FROM eSLSCDaughterCardTypes t1 LEFT JOIN eManufacturers t2 on t1.ManufacturerID == t2.ID WHERE t1.ID == ?", (daughterCard[0],)).fetchone()    
        data.append([info[0], info[1], info[2], count, info[3], '','SLSCDaughterCards'])       
    SLSCMIL1553DaughterCards = conn.execute("SELECT DISTINCT eSLSCDaughterCardTypeID FROM SLSCMIL1553DaughterCards").fetchall()
    for daughterCard in SLSCMIL1553DaughterCards:
        count = conn.execute("SELECT COUNT(*) FROM SLSCRoutingDaughterCards WHERE eSLSCDaughterCardTypeID == ?", (daughterCard[0],)).fetchone()[0]
        info = conn.execute("SELECT t1.Model, t1.PartNumber, t2.Name, t1.Price FROM eSLSCDaughterCardTypes t1 LEFT JOIN eManufacturers t2 on t1.ManufacturerID == t2.ID WHERE t1.ID == ?", (daughterCard[0],)).fetchone()    
        data.append([info[0], info[1], info[2], count, info[3], '','SLSCDaughterCards'])       
    RTIs = conn.execute("SELECT DISTINCT eRTITypeID FROM RTIs").fetchall()
    for RTI in RTIs:
        count = conn.execute("SELECT COUNT(*) FROM RTIs WHERE eRTITypeID == ?", (RTI[0],)).fetchone()[0]
        info = conn.execute("SELECT t1.Model, t1.PartNumber, t2.Name, t1.Price FROM eRTITypes t1 LEFT JOIN eManufacturers t2 on t1.ManufacturerID == t2.ID WHERE t1.ID == ?", (RTI[0],)).fetchone()             
        data.append([info[0], info[1], info[2], count, info[3], '','RTIs'])       
    PXIChassis = conn.execute("SELECT DISTINCT ePXIChassisTypeID FROM PXIChassis").fetchall()
    for chassis in PXIChassis:
        count = conn.execute("SELECT COUNT(*) FROM PXIChassis WHERE ePXIChassisTypeID == ?", (chassis[0],)).fetchone()[0]
        info = conn.execute("SELECT Model, PartNumber, Price FROM ePXIChassisTypes WHERE ID == ?", (chassis[0],)).fetchone()
        data.append([info[0], info[1], 'National Instruments', count, info[2], '','PXIChassis'])              
    pxiInsertTypes = conn.execute("SELECT DISTINCT ePXIInsertTypeID FROM PXIChassisInserts").fetchall()
    for insert in pxiInsertTypes:
        count = conn.execute("SELECT COUNT(*) FROM PXIChassisInserts WHERE ePXIInsertTypeID == ?", (insert[0],)).fetchone()[0]
        info = conn.execute("SELECT Model, PartNumber, Price FROM ePXIInsertTypes WHERE ID == ?", (insert[0],)).fetchone()
        data.append([info[0], info[1], 'National Instruments', count, info[2], '','PXIInserts'])
    cables = conn.execute("SELECT DISTINCT eCableTypeID FROM Cables").fetchall()
    for cable in cables:
        count = conn.execute("SELECT COUNT(*) FROM Cables WHERE eCableTypeID == ?", (cable[0],)).fetchone()[0]        
        info = conn.execute("SELECT t1.Name, t1.PartNumber, t2.Name, t1.Price FROM eCableTypes t1 LEFT JOIN eManufacturers t2 on t1.ManufacturerID == t2.ID WHERE t1.ID == ?", (cable[0],)).fetchone()             
        data.append([info[0], info[1], info[2], count, info[3], '','Cables'])      
    accessories = conn.execute("SELECT DISTINCT eAccessoryTypeID FROM Accessories").fetchall()
    for accessory in accessories:
        count = conn.execute("SELECT COUNT(*) FROM Accessories WHERE eAccessoryTypeID == ?", (accessory[0],)).fetchone()[0]
        info = conn.execute("SELECT t1.Name, t1.PartNumber, t2.Name, t1.Price FROM eAccessories t1 LEFT JOIN eManufacturers t2 on t1.eManufacturerID == t2.ID WHERE t1.ID == ?", (accessory[0],)).fetchone()             
        data.append([info[0], info[1], info[2], count, info[3], '','Accessories'])                 
    software = conn.execute("SELECT DISTINCT SoftwareTypeID FROM Software").fetchall()
    for swType in software:
        count = conn.execute("SELECT COUNT(*) FROM Software WHERE SoftwareTypeID == ?", (swType[0],)).fetchone()[0]
        info = conn.execute("SELECT t1.Name, t1.PartNumber, t2.Name, t1.Price FROM eSoftwareTypes t1 LEFT JOIN eManufacturers t2 on t1.ManufacturerID == t2.ID WHERE t1.ID == ?", (swType[0],)).fetchone()             
        data.append([info[0], info[1], info[2], count, info[3], '','Software'])         
    BaseAssemblyCost = conn.execute("SELECT sum(Rate) FROM eRates WHERE UnitTypeID == (SELECT ID FROM eRateUnitTypes WHERE Name == ?)", ("Base Price",)).fetchone()[0]
    data.append(['BaseAssemblyCost', '', 'Integrator', 1, BaseAssemblyCost, '', 'Services'])
    numRacks = len(conn.execute("SELECT ID FROM Racks").fetchall())
    RackAssemblyCost = conn.execute("SELECT sum(Rate) FROM eRates WHERE UnitTypeID == (SELECT ID FROM eRateUnitTypes WHERE Name == ?)", ("Price per 1st Rack",)).fetchone()[0] + (numRacks - 1)*conn.execute("SELECT sum(Rate) FROM eRates WHERE UnitTypeID == (SELECT ID FROM eRateUnitTypes WHERE Name == ?)", ("Price per 2+ Racks",)).fetchone()[0]
    data.append(['RackAssemblyCost', '', 'Integrator', 1, RackAssemblyCost, '', 'Services'])    
    FTPCost = conn.execute("SELECT sum(Rate) FROM eRates WHERE UnitTypeID == (SELECT ID FROM eRateUnitTypes WHERE Name == ?)", ("Price per Pin",)).fetchone()[0]*conn.execute("SELECT sum(NumPins) FROM SignalsInformation").fetchone()[0]  
    data.append(['FTPCost', '', 'Integrator', 1, FTPCost, '', 'Services'])    
    HWPriceTotal = get_HW_price_total(conn)
    SSP = conn.execute("SELECT Rate FROM eRates WHERE Name == ?", ("SSP",)).fetchone()[0] * HWPriceTotal
    data.append(['SSP', '', 'National Instruments', 1, SSP, '', 'SSP'])    
    Shipping = conn.execute("SELECT Rate FROM eRates WHERE Name == ?", ("Shipping",)).fetchone()[0] * HWPriceTotal    
    data.append(['Shipping', '', 'National Instruments', 1, Shipping, '', 'Shipping'])    
    worksheet.add_table(0, 0, (len(data)), 6, {'data': data, 'columns': [{'header':'Item Name'},{'header':'Part Number'},{'header':'Manufacturer'},{'header':'Quantity'},{'header':'Item Price'},{'header':'Total Price'},{'header':'Table Type'}]})
    row = 2
    for item in data:
        formula = '=D'+str(row)+'*E'+str(row)
        worksheet.write_formula(row-1,5,formula)
        row+=1
