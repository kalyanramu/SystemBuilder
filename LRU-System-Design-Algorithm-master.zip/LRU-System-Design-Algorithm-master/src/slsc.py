'''
Created on Jul 26, 2017

@author: bsnover

Functions relating to SLSC chassis and cards that are generic to all signal types.
'''
import racks, logging
logger = logging.getLogger(__name__)

def add_SLSC_chassis_to_rack(conn, rackID):
    '''Adds a new SLSC chassis to the rack specified by rackID'''
    '''TODO select type of SLSC chassis to add (for now use the only panel supported)'''
    chassisTypeID = conn.execute("SELECT ID From eSLSCChassisTypes").fetchone()[0]          
    '''Ensure there is room in rack'''
    chassisRackUnits = conn.execute('''SELECT RackUnits FROM eRackUnits WHERE ItemType == ?''', ('SLSC Chassis',)).fetchone()[0]
    if (racks.upgrade_rack_if_needed(conn, rackID, chassisRackUnits, racks.RackSpaceType.INTERNAL) > -1):  
        insertChassisID = conn.execute("INSERT INTO SLSCChassis (ChassisTypeID, RackID) VALUES (?, ?)", (chassisTypeID, rackID)).lastrowid
        logger.info('Added new SLSC Chassis %s', insertChassisID)
        conn.commit()    
        return insertChassisID
    else:
        return -1

def delete_chassis(conn, chassisID):
    if(conn.execute("SELECT ID FROM SLSCCards WHERE SLSCChassisID == ?", (chassisID,)).fetchall()):
        logger.error("Chassis must be empty to be deleted.")
        return -1
    conn.execute("DELETE FROM SLSCChassis WHERE ID == ?", (chassisID,))
    conn.commit()
    return 0
    
def insert_SLSC_card_into_chassis(conn, cardTypeID, rackID, chassisID=None):
    '''Adds a card of the type specified by cardTypeID into any chassis available in the rack specified by rackID'''
    '''Add a new chassis if one is missing'''
    if chassisID is None:
        SLSCChassisInRack = conn.execute("SELECT ID, ChassisTypeID FROM SLSCChassis WHERE RackID == ?", (rackID,)).fetchall()
        chassisID = -1
        for chassis in SLSCChassisInRack:
            slotsAvailable = conn.execute("SELECT SlotCount FROM eSLSCChassisTypes WHERE ID == ?", (chassis[1],)).fetchone()[0] - conn.execute("SELECT count(*) FROM SLSCCards WHERE SLSCChassisID == ?", (chassis[0],)).fetchone()[0]
            logger.debug("Empty slots in SLSC chassis %s: %s", chassis[0], slotsAvailable)
            if slotsAvailable > 0:
                chassisID = chassis[0]
                break
        if chassisID < 0:
            chassisID = add_SLSC_chassis_to_rack(conn, rackID)
    
    if chassisID < 0:
        logger.error("Current SLSC chassis full and failed to add a new chassis to the rack")
        return chassisID
    else:
        '''Insert into chassis and ignore the slot number for now'''
        cardID = conn.execute("INSERT INTO SLSCCards (eCardTypeID) VALUES (?)",(cardTypeID,)).lastrowid
        conn.commit()
        if (move_card(conn, cardID, chassisID) > -1):        
            '''Add SLSC connectors for that card'''
            eSLSCConnectors = conn.execute("SELECT ID FROM eSLSCConnectorList WHERE eSLSCCardTypeID == ?", (cardTypeID,)) 
            for eSLSCConnector in eSLSCConnectors:
                SLSCConnectorID = conn.execute("INSERT INTO SLSCConnectors (eSLSCConnectorID, SLSCCardID) VALUES (?,?)", (eSLSCConnector[0],cardID)).lastrowid
                eSLSCPins = conn.execute("SELECT ID FROM eSLSCPins WHERE eSLSCConnector == ?", (eSLSCConnector[0],)).fetchall()
                if conn.execute("SELECT ConnectorLabel FROM eSLSCConnectorList WHERE ID == ?", (eSLSCConnector[0],)).fetchone()[0] == "XJ3" and eSLSCPins:
                    for eSLSCPin in eSLSCPins:
                        conn.execute("INSERT INTO SLSCBusPins (SLSCConnectorID, eSLSCPinID) VALUES (?,?)", (SLSCConnectorID, eSLSCPin[0]))
                    conn.commit()
            conn.commit() 
            logger.info('Added SLSC card type %s with ID %s in rack %s', cardTypeID, cardID, rackID)      
            '''Add bus pins'''
            print("TODO add bus pins")
            return cardID
        else:
            conn.execute("DELETE FROM SLSCCards WHERE ID == ?", (cardID,))
            conn.commit()
            return -1            

def update_card_chassis_bus(conn, cardID, chassisID):
    XJ3ID = conn.execute("SELECT ID FROM SLSCConnectorInformation WHERE SLSCCardID == ? AND ConnectorLabel == ?", (cardID, 'XJ3')).fetchone()
    if XJ3ID:
        busPinInformation = conn.execute("SELECT ID, BusID, eBusTypeID, SLSCChassisID  FROM SLSCBusPinInformation WHERE SLSCConnectorID == ?", (XJ3ID[0],)).fetchall()
        if busPinInformation:
            for busPinInfo in busPinInformation:
                pinID = busPinInfo[0]
                eBusTypeID = busPinInfo[2]
                if (busPinInfo[3] is not None) and (eBusTypeID is not None) and (chassisID is not busPinInfo[3]):
                    '''Check if that bus type already exists for the new chassis, if not, add it'''
                    busID = conn.execute("SELECT ID FROM Buses WHERE eBusTypeID == ? AND SLSCChassisID == ?", (eBusTypeID, busPinInfo[3])).fetchone()
                    if busID:
                        busID = busID[0]
                    else:
                        '''Create a new bus'''
                        busID = conn.execute("INSERT INTO Buses (eBusTypeID, SLSCChassisID) VALUES (?,?)", (eBusTypeID, busPinInfo[3])).lastrowid
                        conn.commit()
                    '''Move all pins from the old chassis to the new'''
                    conn.execute("UPDATE SLSCBusPinJunct SET BusID == ? WHERE PinID == ?", (busID,pinID))
                    conn.commit()
    else:
        return 0
    
def move_card (conn, cardID, chassisID, slotNumber = None):    
    '''Calculate the slot number to add it if needed. Start from slot 12 and work backwards.'''
    if slotNumber is None:
        slots = conn.execute("SELECT SlotNumber FROM SLSCCards WHERE SLSCChassisID == ? ORDER BY SlotNumber", (chassisID,)).fetchall()
        slotNumber = 1
        for slot in slots:
            if slot[0] is not None:
                '''Break on first available slot in chassis'''
                if slot[0] is not slotNumber:
                    break
                slotNumber += 1
    if slotNumber > 12:
        logger.error("SLSC Chassis is out of room.")
        return -1
    
    '''Make sure nothing is in that slot already'''
    if (conn.execute("SELECT ID FROM SLSCCards WHERE SLSCChassisID == ? AND SlotNumber == ?", (chassisID, slotNumber)).fetchone()):
        logger.error("Already a card in chassis %s and slot %s", chassisID, slotNumber)
        return -1        
    '''Add the module to the right location'''
    conn.execute('''UPDATE SLSCCards SET SLSCChassisID = ?, SlotNumber = ? WHERE ID == ?''', (chassisID, slotNumber, cardID)).lastrowid
    conn.commit()
    update_card_chassis_bus(conn, cardID, chassisID)
    return 0    

def delete_card(conn, cardID):
    '''Get a list of connectors associated with that ID'''
    connectors = conn.execute("SELECT ID FROM SLSCConnectors WHERE SLSCCardID == ?", (cardID,)).fetchall()
    '''Disconnect all cables associated with those connectors'''
    for connector in connectors:
        cableJunctionIDs = conn.execute("SELECT ID FROM SLSCCableConJunct WHERE SLSCConID == ?", (connector[0],)).fetchall()
        for junctID in cableJunctionIDs:
            conn.execute("DELETE FROM SLSCCableConJunct WHERE ID == ?", (junctID[0],))
        '''Remove that connector'''
        conn.execute("DELETE FROM SLSCConnectors WHERE ID == ?", (connector[0],))
    '''Remove the card'''
    conn.execute("DELETE FROM SLSCCards WHERE ID == ?", (cardID,))
    conn.commit()    

def find_unused_SLSCcardID (conn, cardTypeID):
    '''Returns an ID to a specific type of SLSC card that has no cables connected to it'''
    allCardsOfType = conn.execute("SELECT ID FROM SLSCCards WHERE eCardTypeID == ?", (cardTypeID,)).fetchall()
    if(allCardsOfType):
        allCardsOfType = [x[0] for x in allCardsOfType]
        usedCardsOfType = conn.execute("SELECT DISTINCT t2.SLSCCardID FROM SLSCCableConJunct t1 LEFT JOIN SLSCConnectors t2 ON t1.SLSCConID == t2.ID LEFT JOIN eSLSCConnectorList t3 ON t2.eSLSCConnectorID == t3.ID WHERE t3.eSLSCCardTypeID == ?", (cardTypeID,)).fetchall()
        usedCardsOfType = [x[0] for x in usedCardsOfType]
        for card in allCardsOfType:
            if card not in usedCardsOfType:
                logger.debug("Found card of type %s with ID %s free for use", cardTypeID, card)
                return card
        return -1
    else:
        return -1

def connect_RTI(conn, eRTITypeID, SLSCXJ2ID):
    '''Adds a new RTI to a specific SLSC card'''
    RTIID = conn.execute("INSERT INTO RTIs (eRTITypeID, SLSCXJ2ID) VALUES (?,?)", (eRTITypeID, SLSCXJ2ID)).lastrowid
    conn.commit()
    eRTIConnectorTypeIDs = conn.execute("SELECT ID FROM eRTIConnectorTypes WHERE eRTITypeID == ?", (eRTITypeID,)).fetchall()
    for connectorTypeID in eRTIConnectorTypeIDs:
        conn.execute("INSERT INTO RTIConnectors (RTIID, eRTIConnectorTypeID) VALUES (?,?)", (RTIID, connectorTypeID[0]))
    conn.commit()
    return RTIID

def get_RTI_Con_IDs_From_RTIID (conn, RTIID):
    RTIIDs = conn.execute("SELECT ID FROM RTIConnectors WHERE RTIID == ?", (RTIID,)).fetchall()
    RTIIDs = [x[0] for x in RTIIDs]
    return RTIIDs

def check_for_an_open_SLSC_connector(conn, eSLSCConnectorIDs, rackID, crossRacks):
    '''Checks for a card with a connector of that type without a cable connected. If found, returns that card's ID. If not, returns -1. crossRacks is used to broaden the search'''
    for eSLSCConnectorID in eSLSCConnectorIDs:
        connInfo = conn.execute("SELECT ID, SLSCCardID FROM UnassignedSLSCConnectors WHERE eSLSCConnectorID == ? AND RackID == ?", (eSLSCConnectorID, rackID)).fetchone()
        if connInfo:
            logger.debug("Found open connector")
            return connInfo
    if crossRacks:
        for eSLSCConnectorID in eSLSCConnectorIDs:
            connInfo = conn.execute("SELECT ID, SLSCCardID FROM UnassignedSLSCConnectors WHERE eSLSCConnectorID == ?", (eSLSCConnectorID,)).fetchone()
            if connInfo:
                print("SLSC CrossRacks Found!")
                logger.debug("Found open connector in a different rack")
                return connInfo    
    '''Return None if no connector was found at this point'''
    return None

def get_all_open_SLSC_front_connectors (conn):
    return conn.execute("SELECT ID, ConnectorLabel, SLSCCardID, eSLSCCardTypeID FROM UnassignedSLSCConnectors WHERE ConnectorLabel == ? OR ConnectorLabel == ?", ('J1', 'J2')).fetchall()

def attach_missing_RTIs (conn):
    '''Attach a 4-Bank RTI to all SLSC cards that don't have an RTI'''
    eRTITypeID = conn.execute("SELECT ID FROM eRTITypes WHERE Model == ?", ('RTI-12303',)).fetchone()[0]
    '''Get a list of cards without RTIs'''
    allCardIDs = conn.execute("SELECT ID FROM SLSCCards").fetchall()
    allCardIDs = [x[0] for x in allCardIDs]
    attachedCardIDs = conn.execute("SELECT t2.SLSCCardID FROM RTIs t1 LEFT JOIN SLSCConnectors t2 ON t1.SLSCXJ2ID == t2.ID").fetchall()
    attachedCardIDs = [x[0] for x in attachedCardIDs]
    missingCardIDs = []
    for cardID in allCardIDs:
        if cardID not in attachedCardIDs:
            missingCardIDs.append(cardID)
    for missingCardID in missingCardIDs:
        SLSCXJ2ID = conn.execute("SELECT ID FROM SLSCConnectorInformation WHERE ConnectorLabel == ? AND SLSCCardID == ?", ('XJ2', missingCardID)).fetchone()[0]
        connect_RTI(conn, eRTITypeID, SLSCXJ2ID)
        logger.info("Attached a missing RTI to SLSCCardID %s", missingCardID)
    return