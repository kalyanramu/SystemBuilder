'''
Created on Dec 1, 2017

@author: bsnover
'''
import LRUconstants

def add_software (conn):
    if not (LRUconstants.CUSTOMER_PROVIDED_SOFTWARE):
        conn.execute("INSERT INTO Software (SoftwareTypeID) SELECT ID FROM eSoftwareTypes WHERE Name == ?", ("Base EFT Software License",))
        conn.execute("INSERT INTO Software (SoftwareTypeID) SELECT ID FROM eSoftwareTypes WHERE Name == ?", ("NI Software Suite",))
        conn.commit()
    return
    
def add_services (conn):
    #TODO
    return