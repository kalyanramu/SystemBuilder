'''
Created on Jul 26, 2017

@author: bsnover
All functions related to cabling in the system.
'''
import logging
logger = logging.getLogger(__name__)

def add_new_cable(conn, cableTypeID):
    '''Adds a new cable to the cable list and returns the cable's ID'''
    cableID = conn.execute("INSERT INTO Cables (eCableTypeID) VALUES (?)", (cableTypeID,)).lastrowid
    logger.debug('Added new cable %s', cableID)
    cableConnectorsToAdd = conn.execute("SELECT ID FROM eCableConnectors WHERE eCableTypeID == ?", (cableTypeID,)).fetchall()
    for connector in cableConnectorsToAdd:
        conn.execute("INSERT INTO CableConnectors (eCableConnectorID, CableID) VALUES (?,?)", (connector[0], cableID)).lastrowid
    conn.commit()
    return cableID

def get_cable_bank(conn, cableConID, connectorBankOffset):
    eCableConnectorID = conn.execute("SELECT eCableConnectorID FROM CableConnectorInformation WHERE ID == ?", (cableConID,)).fetchone()[0]
    eCableBank = conn.execute("SELECT Bank FROM eCablePinInformation WHERE eCableConnectorID == ?", (eCableConnectorID,)).fetchone()
    if eCableBank:
        return eCableBank[0] + connectorBankOffset
    else:
        return -1

def get_opposite_side_connector(conn, cableConID, connectorBankOffset):
    '''Given a connector on a cable, this function returns the ID of the connector on the other end of the cable that uses the same bank'''
    cableInformation = conn.execute("SELECT CableID, Name, eCableConnectorID, eEndTypeID, eCableTypeID, ConnectorTypeName FROM CableConnectorInformation WHERE ID == ?", (cableConID,)).fetchone()
    eCableBank = get_cable_bank(conn, cableConID, connectorBankOffset)
    if eCableBank > -1:
        if cableInformation[3] == 1:
            oppositeEnd = 2
        else:
            oppositeEnd = 1 
        oppositeSideeConnectorID = conn.execute("SELECT eCableConnectorID FROM eCablePinInformation WHERE eCableTypeID == ? AND Bank == ? AND eEndTypeID == ?", (cableInformation[4], eCableBank, oppositeEnd)).fetchone()[0]
        oppositeSideConID = conn.execute("SELECT ID FROM CableConnectorInformation WHERE CableID == ? AND eCableConnectorID == ?", (cableInformation[0], oppositeSideeConnectorID)).fetchone()[0]
        return oppositeSideConID
    else:
        return eCableBank

def get_disconnected_opposite_side_connectors(conn, cableConID):
    '''Use this for 1 to N cables. Pass in the ID for the connector on the 1 side and this returns available connectors on the N side'''
    cableID = conn.execute("SELECT CableID FROM CableConnectorInformation WHERE ID == ?", (cableConID,)).fetchone()[0]
    oppositeSideConIDs = conn.execute("SELECT ID FROM CableConnectorInformation WHERE CableID == ? and ID IS NOT ?", (cableID, cableConID)).fetchall()
    cableConIDs = []
    for oppositeSideConID in oppositeSideConIDs:
        '''Check if those connectors are in any of the junction tables, if not add them to the list to return'''
        if (conn.execute("SELECT ID FROM RTICableConJunct WHERE CableConID == ?", (oppositeSideConID[0],)).fetchone() is None and conn.execute("SELECT ID FROM PXICableConJunct WHERE CableConID == ?", (oppositeSideConID[0],)).fetchone() is None and conn.execute("SELECT ID FROM SLSCCableConJunct WHERE CableConID == ?", (oppositeSideConID[0],)).fetchone() is None and conn.execute("SELECT ID FROM PanelCableConJunct WHERE CableConID == ?", (oppositeSideConID[0],)).fetchone() is None and conn.execute("SELECT ID FROM BulkheadCableConJunct WHERE CableConID == ?", (oppositeSideConID[0],)).fetchone() is None):
            cableConIDs.append(oppositeSideConID[0])
    return cableConIDs

def get_opposite_side_connector_with_pin(conn, cableConID, connectorBankOffset, bankPin):
    '''Given a connector on a cable and its bank offset and bank pin, this function returns the ID of the connector on the other end of the cable that uses the same bank and the physical pin at that end of the cable'''
    cableInformation = conn.execute("SELECT CableID, Name, eCableConnectorID, eEndTypeID, eCableTypeID, ConnectorTypeName FROM CableConnectorInformation WHERE ID == ?", (cableConID,)).fetchone()
    eCableBank = get_cable_bank(conn, cableConID, connectorBankOffset)
    if cableInformation[3] == 1:
        oppositeEnd = 2
    else:
        oppositeEnd = 1 
    oppositeSideeConnectorID = conn.execute("SELECT eCableConnectorID, Number FROM eCablePinInformation WHERE eCableTypeID == ? AND Bank == ? AND eEndTypeID == ? AND bankPin == ?", (cableInformation[4], eCableBank, oppositeEnd, bankPin)).fetchone()
    oppositeSideConID = conn.execute("SELECT ID, ConnectorTypeName FROM CableConnectorInformation WHERE CableID == ? AND eCableConnectorID == ?", (cableInformation[0], oppositeSideeConnectorID[0])).fetchone()
    '''Return (Connector ID, Connector Pin) '''
    return (oppositeSideConID[0], oppositeSideeConnectorID[1])

def get_physical_pin(conn, cableConID, connectorBankOffset, bankPin):
    '''Given a connector on a cable and its bank offset and bank pin, obtain the physical pin '''
    cableInformation = conn.execute("SELECT CableID, Name, eCableConnectorID, eEndTypeID, eCableTypeID, ConnectorTypeName FROM CableConnectorInformation WHERE ID == ?", (cableConID,)).fetchone()
    eCableBank = get_cable_bank(conn, cableConID, connectorBankOffset)
    physicalPin = conn.execute("SELECT Number FROM eCablePinInformation WHERE eCableTypeID == ? AND Bank == ? AND eEndTypeID == ? AND bankPin == ?", (cableInformation[4], eCableBank, cableInformation[3], bankPin)).fetchone()[0]
    return physicalPin

def check_all_cable_connections(conn):
    cableCons = conn.execute("SELECT ID, eConnectorTypeID FROM CableConnectorInformation").fetchall()
    for cableCon in cableCons:
        numInstances = 0
        connectorTypeName = conn.execute("SELECT Name FROM eConnectorTypes WHERE ID == ?", (cableCon[1],)).fetchone()[0] 
        panelConID = conn.execute("SELECT PanelConID FROM PanelCableConJunct WHERE CableConID == ?", (cableCon[0],)).fetchone()
        if panelConID:
            numInstances += 1
            '''Check for compatibility'''
            ePanelConnectorID = conn.execute("SELECT ePanelConnectorID FROM PanelConnectors WHERE ID == ?", (panelConID[0],)).fetchone()[0]
            panelConnectorType = conn.execute("SELECT ConnectorType FROM ePanelConnectorList WHERE ID == ?", (ePanelConnectorID,)).fetchone()[0]
            if panelConnectorType != connectorTypeName:
                print(panelConnectorType, connectorTypeName)
                logger.error("CableConID %s is of wrong type connected to panel connector ID %s", cableCon[0], panelConID[0])
        bulkheadConID = conn.execute("SELECT BulkheadConID FROM BulkheadCableConJunct WHERE CableConID == ?", (cableCon[0],)).fetchone()
        if bulkheadConID:
            numInstances += 1
            '''Check for compatibility'''
            eBulkheadConnectorTypeID = conn.execute("SELECT eConnectorTypeID FROM BulkheadConnectors WHERE ID == ?", (bulkheadConID[0],)).fetchone()[0]
            if eBulkheadConnectorTypeID != cableCon[1]:
                logger.error("CableConID %s is of wrong type connected to PXI connector ID %s", cableCon[0], bulkheadConID[0])        
        PXIConID = conn.execute("SELECT PXIConID FROM PXICableConJunct WHERE CableConID == ?", (cableCon[0],)).fetchone()
        if PXIConID:
            numInstances += 1
            '''Check for compatibility'''
            eConnectorID = conn.execute("SELECT eConnectorID FROM PXIConnectors WHERE ID == ?", (PXIConID[0],)).fetchone()[0]
            ePXIConnectorTypeID = conn.execute("SELECT eConnectorTypeID FROM ePXIConnectorList WHERE ID == ?", (eConnectorID,)).fetchone()[0]
            if ePXIConnectorTypeID != cableCon[1]:
                logger.error("CableConID %s is of wrong type connected to PXI connector ID %s", cableCon[0], PXIConID[0])
        SLSCConID = conn.execute("SELECT SLSCConID FROM SLSCCableConJunct WHERE CableConID == ?", (cableCon[0],)).fetchone()
        if SLSCConID:
            numInstances += 1
            '''Check for compatibility'''
            eConnectorID = conn.execute("SELECT eSLSCConnectorID FROM SLSCConnectors WHERE ID == ?", (SLSCConID[0],)).fetchone()[0]
            eSLSCConnectorTypeID = conn.execute("SELECT eConnectorTypeID FROM eSLSCConnectorList WHERE ID == ?", (eConnectorID,)).fetchone()[0]
            if eSLSCConnectorTypeID != cableCon[1]:
                logger.error("CableConID %s is of wrong type connected to PXI connector ID %s", cableCon[0], SLSCConID[0])
        RTIConID = conn.execute("SELECT RTIConID FROM RTICableConJunct WHERE CableConID == ?", (cableCon[0],)).fetchone()
        if RTIConID:
            numInstances += 1
            '''Check for compatibility'''
            eConnectorID = conn.execute("SELECT eRTIConnectorTypeID FROM RTIConnectors WHERE ID == ?", (RTIConID[0],)).fetchone()[0]
            eRTIConnectorTypeID = conn.execute("SELECT eConnectorTypeID FROM eRTIConnectorTypes WHERE ID == ?", (eConnectorID,)).fetchone()[0]
            if eRTIConnectorTypeID != cableCon[1]:
                logger.error("CableConID %s is of wrong type connected to PXI connector ID %s", cableCon[0], RTIConID[0])
        if numInstances == 0:
            cableID = conn.execute("SELECT CableID FROM CableConnectorInformation WHERE ID == ?", (cableCon[0],)).fetchone()[0]
            eCableTypeID = conn.execute("SELECT eCableTypeID FROM Cables WHERE ID == ?", (cableID,)).fetchone()[0]
            cableName = conn.execute("SELECT Name FROM eCableTypes WHERE ID == ?", (eCableTypeID,)).fetchone()[0]
            logger.info("CableConID %s of cable name %s and cableID %s is disconnected", cableCon[0], cableName, cableID)
        elif numInstances > 1:
            logger.error("CableConID %s is connected in more than one place", cableCon[0])    
        