'''
Created on Jul 26, 2017

@author: bsnover

This module handles all functionality related to racks. 
'''
from operator import itemgetter
from enum import IntEnum
import LRUconstants, logging, pxi
logger = logging.getLogger(__name__)

class RackSpaceType(IntEnum):
    FRONT = 1
    INTERNAL = 2

def add_new_rack(conn):
    '''Adds a new rack to the system. Always assume a 40U rack for now.'''
    #smallestRackTypeID = sorted(conn.execute('''SELECT ID, RackUnits FROM eRackTypes''').fetchall(), key = itemgetter(1)).pop(0)[0]
    rackTypeID = conn.execute("SELECT ID FROM eRackTypes WHERE ModelNumber == ?", ("40U",)).fetchone()[0]
    insertedRackID = conn.execute('''INSERT INTO Racks (RackTypeID) VALUES (?)''', (rackTypeID,)).lastrowid
    conn.commit()
    logger.info('Added new rack with ID %s', insertedRackID)
    ethernetSwitcheID = conn.execute("SELECT ID FROM eInternalRackHW WHERE Name == ?", ("Ethernet Switch",)).fetchone()[0]
    conn.execute("INSERT INTO InternalRackHW (eInternalRackHWTypeID, RackID) VALUES (?,?)", (ethernetSwitcheID, insertedRackID))
    PDUeID = conn.execute("SELECT ID FROM eInternalRackHW WHERE Name == ?", ("PDU",)).fetchone()[0]
    conn.execute("INSERT INTO InternalRackHW (eInternalRackHWTypeID, RackID) VALUES (?,?)", (PDUeID, insertedRackID))    
    '''Check if this is the first rack in the system. If so, add extra stuff that goes in the first rack.'''
    if len(conn.execute("SELECT ID FROM Racks").fetchall()) == 1:
        DCSupplyeID = conn.execute("SELECT ID FROM eInternalRackHW WHERE Name == ?", ("DC Power Supply",)).fetchone()[0]
        conn.execute("INSERT INTO InternalRackHW (eInternalRackHWTypeID, RackID) VALUES (?,?)", (DCSupplyeID, insertedRackID))
        RackMountPCID = conn.execute("SELECT ID FROM ePanelTypes WHERE ModelNumber == ?", ('RMC-8356',)).fetchone()[0]
        conn.execute("INSERT INTO Panels (ePanelTypeID, RackID) VALUES (?,?)", (RackMountPCID, insertedRackID))
        '''Add the instrument chassis with all of its additional hardware'''
        instrumentChassiseID = conn.execute("SELECT ID FROM ePXIChassisTypes WHERE Model == ?", (LRUconstants.PXI_INSTRUMENT_CHASSIS_EID,)).fetchone()[0]
        pxiInstrumentChassisID = pxi.insert_pxi_chassis_into_rack(conn, insertedRackID, instrumentChassiseID)
        if pxiInstrumentChassisID < 0:
            return pxiInstrumentChassisID
        else:
            MXIExpressID = conn.execute("SELECT ID FROM ePXIInsertTypes WHERE Model == ?", ("PXIe-PCIe-8381",)).fetchone()[0]
            pxi.add_PXI_insert(conn, MXIExpressID, insertedRackID, pxiInstrumentChassisID)
            DMMeID = conn.execute("SELECT ID FROM ePXIInsertTypes WHERE Model == ?", ("PXIe-4082",)).fetchone()[0]
            pxi.add_PXI_insert(conn, DMMeID, insertedRackID, pxiInstrumentChassisID)
            SMUeID = conn.execute("SELECT ID FROM ePXIInsertTypes WHERE Model == ?", ("PXIe-4138",)).fetchone()[0]
            pxi.add_PXI_insert(conn, SMUeID, insertedRackID, pxiInstrumentChassisID)
            MatrixID = conn.execute("SELECT ID FROM ePXIInsertTypes WHERE Model == ?", ("PXIe-2739",)).fetchone()[0]
            pxi.add_PXI_insert(conn, MatrixID, insertedRackID, pxiInstrumentChassisID)
            '''Connect matrix rows to the DMM and SMU'''
            print("TODO: Add matrix, DMM, and SMU pins and connect DMM/SMU to matrix")
    return insertedRackID

def get_available_rack_space(conn, rackID, rackSpaceType):
    '''Returns the U space remaining in the rack specified by rackID, rackSpaceType is an enum of type RackSpaceType'''
    totalSpace = conn.execute('''SELECT RackUnits FROM RackInformation WHERE ID == ?''', (rackID,)).fetchone()[0]
    if (rackSpaceType == RackSpaceType.FRONT):
        panelRackUnits = conn.execute("SELECT SUM(t2.RackUnits) FROM Panels t1 LEFT OUTER JOIN ePanelTypes t2 ON t1.ePanelTypeID == t2.ID WHERE t1.RackID == ?", (rackID,)).fetchone()[0]
        if panelRackUnits == None:
            panelRackUnits = 0
        numPanels = conn.execute('''SELECT COUNT(*) FROM Panels WHERE RackID == ?''', (rackID,)).fetchone()[0]
        #usedPanelSpace = (numPanels * conn.execute('''SELECT RackUnits FROM eRackUnits WHERE ItemType == ?''', ('Panel',)).fetchone()[0])
        '''Leave 2U available between each panel'''
        panelSeperation = 2*(numPanels - 1)
        '''Remove an extra because 1 U is still needed between each'''
        return (totalSpace - panelRackUnits - panelSeperation - 2)
    if rackSpaceType == RackSpaceType.INTERNAL:
        shelfRackUnits = conn.execute("SELECT SUM(t2.RackUnits) FROM Panels t1 LEFT OUTER JOIN ePanelTypes t2 on t1.ePanelTypeID == t2.ID WHERE t1.RackID == ? AND t2.Shelf == ?", (rackID, True)).fetchone()[0]
        if shelfRackUnits is None:
            shelfRackUnits =  0
        numShelfs = conn.execute("SELECT COUNT(*) FROM Panels t1 LEFT OUTER JOIN ePanelTypes t2 on t1.ePanelTypeID == t2.ID WHERE t1.RackID == ? AND t2.Shelf == ?", (rackID, True)).fetchone()[0]
        numSLSCChassis = conn.execute('''SELECT COUNT(*) FROM SLSCChassis WHERE RackID == ?''', (rackID,)).fetchone()[0]
        usedSLSCChassisSpace = numSLSCChassis * (conn.execute('''SELECT RackUnits FROM eRackUnits WHERE ItemType == ?''', ('SLSC Chassis',)).fetchone()[0])
        numPXIChassis = conn.execute('''SELECT COUNT(*) FROM PXIChassis WHERE RackID == ?''', (rackID,)).fetchone()[0]
        usedPXIChassisSpace = numPXIChassis * (conn.execute('''SELECT RackUnits FROM eRackUnits WHERE ItemType == ?''', ('PXI Chassis',)).fetchone()[0])
        usedInternalRackHWSpace = conn.execute("SELECT SUM(t2.RackUnits) FROM InternalRackHW t1 LEFT JOIN eInternalRackHW t2 ON t1.eInternalRackHWTypeID == t2.ID WHERE t1.RackID == ?", (rackID,)).fetchone()[0]
        #Ensure at least 1U seperation between chassis
        chassisSeperation = numSLSCChassis + numPXIChassis
        return (totalSpace - LRUconstants.RACK_INTERNAL_HEADROOM - shelfRackUnits - usedSLSCChassisSpace - usedPXIChassisSpace - usedInternalRackHWSpace - chassisSeperation)
    else:
        return -1        

def get_rack_with_most_space(conn, rackIDsToSearchThrough, rackSpaceType):
    '''Returns the rack with the most free space available'''
    racks = conn.execute('''SELECT ID, RackUnits FROM RackInformation WHERE ID IN (%s)''' % ','.join('?'*len(rackIDsToSearchThrough)), rackIDsToSearchThrough).fetchall()
    selectedRackID = -1
    freeSpace = -1
    for rack in racks:
        rackSpace = get_available_rack_space(conn, rack[0], rackSpaceType) 
        if rackSpace > freeSpace:
            freeSpace = rackSpace
            selectedRackID = rack[0]
    return selectedRackID
              
def upgrade_rack_if_needed(conn, rackID, rackUnitsNeeded, rackSpaceType):
    '''Checks if the specified rack has enough space for rackUnitsNeeded. If not, it tries to upgrade the rack to a larger size. If that doesn't work it returns -1'''
    freeSpaceInCurrentRack = get_available_rack_space(conn, rackID, rackSpaceType)
    if (rackUnitsNeeded > freeSpaceInCurrentRack):
        sortedRackTypes = sorted(conn.execute('''SELECT ID, RackUnits, ModelNumber FROM eRackTypes''').fetchall(), key = itemgetter(1))
        currentRackInfo = conn.execute('''SELECT RackTypeID, RackUnits, ModelNumber FROM RackInformation WHERE ID == ?''', (rackID,)).fetchone()
        newRackType = currentRackInfo[0]
        for rack in sortedRackTypes:
            if ((freeSpaceInCurrentRack + rack[1] - currentRackInfo[1]) >= rackUnitsNeeded):
                '''Change the rack type to the new type'''
                conn.execute('''UPDATE Racks SET RackTypeID = ? WHERE ID = ?''', (rack[0], rackID))
                conn.commit()
                logger.info('Rack type updated from %s to %s and free Uspace available is now %s', currentRackInfo[2], rack[2], (freeSpaceInCurrentRack + rack[1] - currentRackInfo[1]))
                newRackType = rack[0]
                break
        if(newRackType == currentRackInfo[0]):
            '''we need to use a different rack and must return an error'''
            logger.debug("Not enough room for new panel in rack %s and upgrade was not possible", rackID)
            return -1    
    return 0

def disassemble_rack(conn, currentRackID):    
    '''Disassembles everything in a rack except for the rack infrastructure. This is essentially hitting the reset switch.'''
    '''TODO ignore items added to a rack as constraints'''
    PXIConnectorIDs = conn.execute("SELECT ID FROM PXIConnectorInformation WHERE RackID == ?", (currentRackID,)).fetchall()
    PXIConnectorIDs = [x[0] for x in PXIConnectorIDs]    
    PXICableConIDs = conn.execute("SELECT CableConID FROM PXICableConJunct WHERE PXIConID IN (%s)" % ','.join('?'*len(PXIConnectorIDs)), PXIConnectorIDs).fetchall()
    PXICableConIDs = [x[0] for x in PXICableConIDs]
    conn.execute("DELETE FROM PXICableConJunct WHERE PXIConID IN (%s)" % ','.join('?'*len(PXIConnectorIDs)), PXIConnectorIDs) 

    RTIConnectorIDs = conn.execute("SELECT ID FROM RTIConnectorInformation WHERE RackID == ?", (currentRackID,)).fetchall()
    RTIConnectorIDs = [x[0] for x in RTIConnectorIDs]
    RTICableConIDs = conn.execute("SELECT CableConID FROM RTICableConJunct WHERE RTIConID IN (%s)" % ','.join('?'*len(RTIConnectorIDs)), RTIConnectorIDs).fetchall()
    RTICableConIDs = [x[0] for x in RTICableConIDs]    
    conn.execute("DELETE FROM RTICableConJunct WHERE RTIConID IN (%s)" % ','.join('?'*len(RTIConnectorIDs)), RTIConnectorIDs).fetchall() 
   
    SLSCConnectorIDs = conn.execute("SELECT ID FROM SLSCConnectorInformation WHERE RackID == ?", (currentRackID,)).fetchall()
    SLSCConnectorIDs = [x[0] for x in SLSCConnectorIDs]
    SLSCCableConIDs = conn.execute("SELECT CableConID FROM SLSCCableConJunct WHERE SLSCConID IN (%s)" % ','.join('?'*len(SLSCConnectorIDs)), SLSCConnectorIDs).fetchall()
    SLSCCableConIDs = [x[0] for x in SLSCCableConIDs]    
    conn.execute("DELETE FROM SLSCCableConJunct WHERE SLSCConID IN (%s)" % ','.join('?'*len(SLSCConnectorIDs)), SLSCConnectorIDs)
    
    panelConnectorIDs = conn.execute("SELECT ID FROM PanelConnectorInformation WHERE RackID == ?", (currentRackID,)).fetchall()
    panelConnectorIDs = [x[0] for x in panelConnectorIDs]
    panelCableConIDs = conn.execute("SELECT CableConID FROM PanelCableConJunct WHERE PanelConID IN (%s)" % ','.join('?'*len(panelConnectorIDs)), panelConnectorIDs).fetchall()   
    panelCableConIDs = [x[0] for x in panelCableConIDs]    
    conn.execute("DELETE FROM PanelCableConJunct WHERE PanelConID IN (%s)" % ','.join('?'*len(panelConnectorIDs)), panelConnectorIDs).fetchall() 

    bulkheadConnectorIDs = conn.execute("SELECT t1.ID FROM BulkheadConnectors t1 LEFT JOIN Panels t2 ON t1.BulkheadPanelID == t2.ID WHERE RackID == ?", (currentRackID,)).fetchall()
    bulkheadConnectorIDs = [x[0] for x in bulkheadConnectorIDs]
    bulkheadCableConIDs = conn.execute("SELECT CableConID FROM BulkheadCableConJunct WHERE BulkheadConID IN (%s)" % ','.join('?'*len(panelConnectorIDs)), panelConnectorIDs).fetchall()   
    bulkheadCableConIDs = [x[0] for x in bulkheadCableConIDs]    
    conn.execute("DELETE FROM BulkheadCableConJunct WHERE BulkheadConID IN (%s)" % ','.join('?'*len(bulkheadConnectorIDs)), bulkheadConnectorIDs).fetchall()  

    cableConIDs = list(set(SLSCCableConIDs) | set(panelCableConIDs) | set(bulkheadCableConIDs) | set(PXICableConIDs) | set(RTICableConIDs))
    cableIDs = conn.execute("SELECT DISTINCT CableID FROM CableConnectorInformation WHERE ID IN (%s)" % ','.join('?'*len(cableConIDs)), cableConIDs).fetchall()
    cableIDs = [x[0] for x in cableIDs]
    conn.execute("DELETE FROM CableConnectors WHERE CableID IN (%s)" % ','.join('?'*len(cableIDs)), cableIDs)
    conn.commit() 
    conn.execute("DELETE FROM Cables WHERE ID IN (%s)" % ','.join('?'*len(cableIDs)), cableIDs)
    conn.commit()
    PXIChassis = conn.execute("SELECT ID FROM PXIChassis WHERE RackID == ?", (currentRackID,)).fetchall()
    PXIChassis = [x[0] for x in PXIChassis]
    PXIInserts = conn.execute("SELECT ID FROM PXIChassisInserts WHERE PXIChassisID IN (%s)" % ','.join('?'*len(PXIChassis)), PXIChassis).fetchall()
    PXIInserts = [x[0] for x in PXIInserts]
    conn.execute("DELETE FROM PXIConnectors WHERE PXICardID IN (%s)" % ','.join('?'*len(PXIInserts)), PXIInserts).fetchall()
    conn.commit()
    conn.execute("DELETE FROM PXIChassisInserts WHERE PXIChassisID IN (%s)" % ','.join('?'*len(PXIChassis)), PXIChassis).fetchall()
    conn.commit()
    conn.execute("DELETE FROM PXIChassis WHERE RackID == ?", (currentRackID,))
    conn.commit()    
    SLSCChassis = conn.execute("SELECT ID FROM SLSCChassis WHERE RackID == ?", (currentRackID,)).fetchall()
    SLSCChassis = [x[0] for x in SLSCChassis]
    SLSCCards = conn.execute("SELECT ID FROM SLSCCards WHERE SLSCChassisID IN (%s)" % ','.join('?'*len(SLSCChassis)), SLSCChassis).fetchall()
    SLSCCards = [x[0] for x in SLSCCards]
    RTIs = conn.execute("SELECT t1.ID FROM RTIs t1 LEFT JOIN SLSCConnectors t2 ON t1.SLSCXJ2ID == t2.ID WHERE t2.SLSCCardID IN (%s)" % ','.join('?'*len(SLSCCards)), SLSCCards).fetchall()
    RTIs = [x[0] for x in RTIs]
    if RTIs:
        conn.execute("DELETE FROM RTIConnectors WHERE RTIID IN (%s)" % ','.join('?'*len(RTIs)), RTIs)
        conn.commit()
        conn.execute("DELETE FROM RTIs WHERE ID IN (%s)" % ','.join('?'*len(RTIs)), RTIs)
        conn.commit()
    conn.execute("DELETE FROM SLSCRoutingDaughterCards WHERE SLSCRoutingCardID IN (%s)" % ','.join('?'*len(SLSCCards)), SLSCCards)
    conn.commit()
    conn.execute("DELETE FROM SLSCMIL1553DaughterCards WHERE AttachedChannelConID IN (SELECT ID FROM SLSCConnectors WHERE SLSCCardID IN (%s))" % ','.join('?'*len(SLSCCards)), SLSCCards)    
    conn.commit()    
    conn.execute("DELETE FROM SLSCConnectors WHERE SLSCCardID IN (%s)" % ','.join('?'*len(SLSCCards)), SLSCCards)
    conn.commit()
    conn.execute("DELETE FROM SLSCCards WHERE SLSCChassisID IN (%s)" % ','.join('?'*len(SLSCChassis)), SLSCChassis)
    conn.commit()
    conn.execute("DELETE FROM SLSCChassis WHERE RackID == ?", (currentRackID,))
    conn.commit()
    '''Remove panels but leave bulkhead panels alone'''
    eBulkheadPanelID = conn.execute("SELECT ID FROM ePanelTypes WHERE ModelNumber == ?", (LRUconstants.BULKHEAD_PANEL_NAME,)).fetchone()[0]
    panelIDs = conn.execute("SELECT ID FROM Panels WHERE RackID == ? AND ePanelTypeID IS NOT ?", (currentRackID, eBulkheadPanelID)).fetchall()
    panelIDs = [x[0] for x in panelIDs]
    panelsWithSimSignals = conn.execute("SELECT DISTINCT t2.PanelID FROM SignalPanelConJunct t1 LEFT JOIN PanelConnectors t2 ON t1.PanelConID == t2.ID LEFT JOIN Panels t3 ON t2.PanelID == t3.ID WHERE t1.Real IS NOT ? AND t3.RackID == ?", (True, currentRackID)).fetchall()
    panelsWithSimSignals = [x[0] for x in panelsWithSimSignals]
    for panel in panelsWithSimSignals:
        panelIDs.remove(panel)
    for panel in panelIDs:
        conn.execute("DELETE FROM SignalPanelConJunct WHERE ID IN (SELECT t1.ID FROM SignalPanelConJunct t1 LEFT JOIN PanelConnectors t2 ON t1.PanelConID == t2.ID WHERE t2.PanelID == ?)", (panel,))
        conn.commit()
        conn.execute("DELETE FROM PanelConnectors WHERE PanelID == ?",(panel,))
        conn.commit()
        conn.execute("DELETE FROM Panels WHERE ID == ?", (panel,))
        conn.commit()
    logger.info("Rack %s disassembled", currentRackID)
    return